import { afterEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase, type Database } from "../src/db/client";

import { testDatabaseUrl } from "./test-database";

const unreachableDatabaseUrl = "postgres://subtrack:subtrack@127.0.0.1:1/unreachable";

describe("GET /health", () => {
  let database: Database;

  afterEach(async () => {
    await database.close();
  });

  it("reports ok when the database is reachable", async () => {
    database = createDatabase(testDatabaseUrl);
    const app = await buildApp({ database });

    const response = await app.inject({ method: "GET", url: "/health" });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({ status: "ok", checks: { api: "ok", database: "ok" } });
  });

  it("reports degraded with 503 when the database is unreachable", async () => {
    database = createDatabase(unreachableDatabaseUrl);
    const app = await buildApp({ database });

    const response = await app.inject({ method: "GET", url: "/health" });

    expect(response.statusCode).toBe(503);
    expect(response.json()).toEqual({
      status: "degraded",
      checks: { api: "ok", database: "down" },
    });
  });
});
