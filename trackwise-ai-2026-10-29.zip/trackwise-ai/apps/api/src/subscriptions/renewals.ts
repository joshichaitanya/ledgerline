import { dueRenewals } from "@subtrack/contracts";
import { eq, lte } from "drizzle-orm";
import type { Database } from "../db/client";
import { payments, subscriptions } from "../db/schema";

/**
 * Records a payment for every renewal that has passed (up to and including `today`) and
 * advances each subscription's next renewal date. Idempotent and safe under concurrent
 * requests: due rows are locked, and payments are unique per subscription and date.
 * Runs before reads that show renewal dates or spending, so no background job is needed.
 */
export async function processDueRenewals({ db }: Database, today: string): Promise<number> {
  return db.transaction(async (tx) => {
    const due = await tx
      .select()
      .from(subscriptions)
      .where(lte(subscriptions.nextRenewalDate, today))
      .for("update");

    let recorded = 0;
    for (const subscription of due) {
      const anchor = subscription.renewalAnchorDate ?? subscription.nextRenewalDate;
      const { paymentDates, nextRenewalDate } = dueRenewals(
        anchor,
        subscription.nextRenewalDate,
        subscription.billingCycle,
        today,
      );
      if (paymentDates.length > 0) {
        const inserted = await tx
          .insert(payments)
          .values(
            paymentDates.map((paidOn) => ({
              subscriptionId: subscription.id,
              paidOn,
              amountMinor: subscription.amountMinor,
              currency: subscription.currency,
            })),
          )
          .onConflictDoNothing()
          .returning({ id: payments.id });
        recorded += inserted.length;
      }
      await tx
        .update(subscriptions)
        .set({ nextRenewalDate, renewalAnchorDate: anchor })
        .where(eq(subscriptions.id, subscription.id));
    }
    return recorded;
  });
}
