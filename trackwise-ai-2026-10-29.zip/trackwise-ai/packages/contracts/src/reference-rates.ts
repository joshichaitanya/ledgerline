import { type RateTable, roundRate } from "./settings";
import type { Currency } from "./subscription";

/** When the built-in rates were last updated. Shown next to every default in the UI. */
export const REFERENCE_RATES_AS_OF = "2026-10";

/**
 * Built-in approximate rates: US dollars per one unit of each currency. Used wherever the user
 * hasn't entered their own rate, so totals cover common currencies out of the box. They go stale
 * over time — the UI labels them as approximate defaults, and any custom rate overrides them.
 */
export const REFERENCE_USD_RATES: Readonly<Partial<Record<Currency, number>>> = {
  USD: 1,
  EUR: 1.16,
  GBP: 1.33,
  JPY: 0.0066,
  INR: 0.0114,
  CAD: 0.72,
  AUD: 0.66,
  CHF: 1.25,
  CNY: 0.14,
  HKD: 0.128,
  SGD: 0.77,
  NZD: 0.58,
  SEK: 0.105,
  NOK: 0.099,
  DKK: 0.155,
  PLN: 0.27,
  CZK: 0.047,
  HUF: 0.0029,
  MXN: 0.054,
  BRL: 0.185,
  ZAR: 0.057,
  KRW: 0.00072,
  AED: 0.2723,
  SAR: 0.2667,
  ILS: 0.3,
  TRY: 0.024,
};

/** "1 {currency} = ? {primary}" from the built-in table (a cross rate via USD), if both are known. */
export function referenceRate(currency: Currency, primary: Currency): number | undefined {
  if (currency === primary) return 1;
  const currencyInUsd = REFERENCE_USD_RATES[currency];
  const primaryInUsd = REFERENCE_USD_RATES[primary];
  if (currencyInUsd === undefined || primaryInUsd === undefined) return undefined;
  return roundRate(currencyInUsd / primaryInUsd);
}

/** Built-in rates expressed in the primary currency (every known currency except the primary). */
export function defaultRates(primary: Currency): Map<Currency, number> {
  const defaults = new Map<Currency, number>();
  for (const currency of Object.keys(REFERENCE_USD_RATES) as Currency[]) {
    const rate = currency === primary ? undefined : referenceRate(currency, primary);
    if (rate !== undefined) defaults.set(currency, rate);
  }
  return defaults;
}

/** The rates conversions actually use: built-in defaults, overridden by the user's own rates. */
export function effectiveRates(primary: Currency, custom: RateTable): Map<Currency, number> {
  return new Map([...defaultRates(primary), ...custom]);
}
