import { useQuery } from "@tanstack/react-query";
import { api } from "./client";

export function useHealth() {
  return useQuery({
    queryKey: ["health"],
    queryFn: async () => {
      const { data, error, response } = await api.GET("/health");
      // 503 is a valid answer ("degraded") and still carries a health body.
      if (response.status === 200 || response.status === 503) {
        const body = data ?? error;
        if (body) return body;
      }
      throw new Error(`Health check failed with HTTP ${response.status}`);
    },
    refetchInterval: 10_000,
  });
}
