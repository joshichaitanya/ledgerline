import type { ReactNode } from "react";

interface PageHeaderProps {
  title: string;
  description?: string;
  /** e.g. a primary action button, shown on the right. */
  actions?: ReactNode;
}

export function PageHeader({ title, description, actions }: PageHeaderProps) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <h2 className="text-2xl font-bold tracking-tight md:text-3xl">{title}</h2>
        {description && <p className="mt-1 text-ink-subtle">{description}</p>}
      </div>
      {actions}
    </div>
  );
}
