# TrackWise-AI

Track subscriptions, spending and renewals. A portfolio project for learning modern AI application engineering. See [`todo.md`](todo.md) for the plan.

## Stack

| Layer     | Tech                                                                 |
| --------- | -------------------------------------------------------------------- |
| Web       | React 19, Vite, Tailwind CSS v4, TanStack Query, `openapi-fetch`     |
| API       | Node 24, Fastify 5, Zod 4 (`fastify-type-provider-zod`), Drizzle ORM |
| Database  | PostgreSQL 18 (Docker Compose)                                       |
| Contracts | `packages/contracts`: shared Zod schemas                             |
| Tooling   | pnpm workspaces, TypeScript (strict), Biome, Vitest, Playwright      |

## Layout

```
apps/api            Fastify REST API (openapi.json generated from route schemas)
apps/web            React SPA (src/api/schema.gen.ts generated from openapi.json)
packages/contracts  Zod schemas shared by API and web
e2e                 Playwright tests against the real API + production web bundle
docker/             Postgres init scripts (creates dev, test and e2e databases)
```

## Prerequisites

- Node 24 (`nvm use`)
- pnpm 11 (`corepack enable` or `npm i -g pnpm`)
- Docker Desktop (running)

## Getting started

```sh
pnpm install
cp apps/api/.env.example apps/api/.env   # local config; not committed
pnpm db:up                               # Postgres on localhost:5433
pnpm db:migrate                          # create/update tables
pnpm db:seed                             # sample data (only if the table is empty)
pnpm dev                                 # API on :3000, web on :5173
```

Open http://localhost:5173. The header shows the API and database status.

## Commands

| Command                                    | What it does                                                                                |
| ------------------------------------------ | ------------------------------------------------------------------------------------------- |
| `pnpm dev`                                 | Run API (watch mode) and web (HMR) together                                                 |
| `pnpm db:up` / `pnpm db:down`              | Start / stop Postgres (data persists in a Docker volume)                                    |
| `pnpm db:generate`                         | Create a new SQL migration in `apps/api/drizzle/` after editing `apps/api/src/db/schema.ts` |
| `pnpm db:migrate`                          | Apply pending migrations to the dev database (tests migrate their own DB automatically)     |
| `pnpm db:seed`                             | Insert sample subscriptions if the table is empty; `pnpm db:seed --reset` replaces all rows |
| `pnpm check` / `pnpm fix`                  | Biome + TypeScript in every package / apply Biome fixes                                     |
| `pnpm test` / `pnpm test:coverage`         | Unit, component and API integration tests (needs Postgres) / with coverage thresholds       |
| `pnpm e2e` / `pnpm e2e:all`                | Playwright on Chromium / on Chromium, Firefox, WebKit and mobile                            |
| `pnpm openapi:generate`                    | Regenerate `openapi.json` and the typed web + E2E clients after changing API schemas        |
| `pnpm openapi:check` / `pnpm openapi:lint` | Contract drift check / OpenAPI lint (Redocly)                                               |
| `pnpm openapi:breaking <base.json>`        | Breaking changes between a base spec and the current one (oasdiff, Docker)                  |
| `pnpm contract:fuzz`                       | Fuzz the running API against its spec (Schemathesis, Docker)                                |
| `pnpm lint:workflows`                      | Lint `.github/workflows` (actionlint, Docker)                                               |
| `pnpm verify`                              | The local Definition of Done (see below)                                                    |

First E2E run only: `pnpm --filter @subtrack/e2e exec playwright install chromium` (add `firefox webkit` for `e2e:all`).
After a failed E2E run, `pnpm --filter @subtrack/e2e report` opens the HTML report with traces and screenshots.

## Quality gates

Each gate catches a different class of mistake. `pnpm verify` runs the first five locally; CI runs all of them.

| Gate                                          | Catches                                                                                                                                                                                | Run locally                         |
| --------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------- |
| **Biome** (format + lint + import boundaries) | Style drift, unused code, `console` in app code, non-null assertions, and architecture violations: web importing API/DB code, contracts importing frameworks, E2E importing app source | `pnpm check`                        |
| **TypeScript** (strict, every package)        | Type errors, including web/E2E test fixtures that no longer match the API contract                                                                                                     | `pnpm check`                        |
| **OpenAPI drift**                             | API schemas changed but `openapi.json` or a generated client wasn't regenerated                                                                                                        | `pnpm openapi:check`                |
| **OpenAPI lint**                              | Incomplete spec: missing operationIds, summaries, tags, servers, response descriptions                                                                                                 | `pnpm openapi:lint`                 |
| **Unit + integration + coverage**             | Logic bugs (Vitest, real Postgres), coverage dropping below per-package thresholds                                                                                                     | `pnpm test:coverage`                |
| **E2E** (4 browser projects)                  | Broken user journeys, cross-browser/mobile layout bugs, accessibility violations (axe, WCAG 2.1 AA), unhandled failure states                                                          | `pnpm e2e:all`                      |
| **Breaking changes** (PRs)                    | Removing/narrowing anything clients rely on, e.g. a response field or enum value                                                                                                       | `pnpm openapi:breaking <base.json>` |
| **Contract fuzzing**                          | Server errors and spec/behaviour mismatches on unexpected-but-valid input                                                                                                              | `pnpm contract:fuzz`                |
| **Workflow lint**                             | Typos and mistakes in CI config                                                                                                                                                        | `pnpm lint:workflows`               |

CI (`.github/workflows/ci.yml`) runs four parallel jobs: **static** (Biome, types, drift, OpenAPI lint), **test** (coverage table in the job summary), **e2e** (one job per browser project, cached browsers, report + traces uploaded on failure) and **contract** (breaking changes vs the target branch, then fuzzing).

## How the frontend/backend contract stays in sync

1. Zod schemas in `packages/contracts` define request/response shapes, including user-facing validation messages.
2. Fastify validates requests _and responses_ with those schemas, then derives `apps/api/openapi.json`.
3. `openapi-typescript` turns the spec into a typed client for each consumer: `apps/web/src/api/schema.gen.ts` and `e2e/tests/support/schema.gen.ts`. Test doubles are typed from it too, so a contract change breaks stale fixtures at compile time.
4. CI fails if a generated file is stale (drift), if the spec is incomplete (lint), if a change breaks existing clients (oasdiff), or if the running API disagrees with its spec (Schemathesis).

## Databases

| Database        | Used by                                     |
| --------------- | ------------------------------------------- |
| `subtrack`      | `pnpm dev`                                  |
| `subtrack_test` | `pnpm test`                                 |
| `subtrack_e2e`  | `pnpm e2e` (migrated + re-seeded every run) |
| `subtrack_fuzz` | `pnpm contract:fuzz` (recreated every run)  |

Connect with `docker compose exec postgres psql -U subtrack -d subtrack`. To reset everything: `docker compose down -v`.
