// Prints the Vitest coverage summary as a Markdown table (for the CI job summary).
import { readFileSync } from "node:fs";

const summary = JSON.parse(readFileSync("reports/coverage/coverage-summary.json", "utf8"));
const metrics = ["lines", "statements", "branches", "functions"];
const groups = { Contracts: "/packages/contracts/", API: "/apps/api/", Web: "/apps/web/" };

const rows = Object.entries(groups).map(([label, fragment]) => {
  const files = Object.entries(summary).filter(([file]) => file.includes(fragment));
  const cells = metrics.map((metric) => {
    const total = files.reduce((sum, [, file]) => sum + file[metric].total, 0);
    const covered = files.reduce((sum, [, file]) => sum + file[metric].covered, 0);
    return total === 0 ? "–" : `${((100 * covered) / total).toFixed(1)}%`;
  });
  return `| ${label} | ${cells.join(" | ")} |`;
});
const totals = metrics.map((metric) => `**${summary.total[metric].pct}%**`);

process.stdout.write(
  [
    "### Coverage",
    "",
    `| Package | ${metrics.join(" | ")} |`,
    `|---|${metrics.map(() => "---").join("|")}|`,
    ...rows,
    `| **Total** | ${totals.join(" | ")} |`,
    "",
  ].join("\n"),
);
