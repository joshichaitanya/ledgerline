import { SummaryResponseSchema } from "@subtrack/contracts";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";
import { type NewSubscriptionRow, subscriptions } from "../src/db/schema";
import { sampleSubscriptions } from "../src/db/seed";
import { testDatabaseUrl } from "./test-database";

const database = createDatabase(testDatabaseUrl);
// Pinned so renewal dates in assertions are stable.
const today = "2026-10-28";
const app = await buildApp({ database, now: () => new Date(`${today}T12:00:00Z`) });

const base: NewSubscriptionRow = {
  name: "Netflix",
  amountMinor: 1599,
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "2026-11-15",
};

async function getSummary(url = "/summary") {
  const response = await app.inject({ method: "GET", url });
  expect(response.statusCode).toBe(200);
  return SummaryResponseSchema.parse(response.json());
}

beforeEach(async () => {
  await database.db.delete(subscriptions);
});

afterAll(async () => {
  await app.close();
  await database.close();
});

describe("GET /summary", () => {
  it("returns zero totals when there are no subscriptions", async () => {
    expect(await getSummary()).toEqual({
      subscriptionCount: 0,
      spendByCurrency: [],
      converted: {
        currency: "USD",
        subscriptionCount: 0,
        monthlyMinor: 0,
        yearlyMinor: 0,
        averageMonthlyMinor: 0,
        byCategory: [],
        unconvertedCurrencies: [],
      },
      upcomingRenewals: { asOf: today, windowDays: 30, items: [] },
    });
  });

  it("totals stored subscriptions per currency and category", async () => {
    await database.db
      .insert(subscriptions)
      .values([
        base,
        { ...base, name: "Economist", amountMinor: 699, billingCycle: "weekly", category: "news" },
        { ...base, name: "Disney+", amountMinor: 999, currency: "EUR" },
      ]);

    const summary = await getSummary();

    expect(summary.subscriptionCount).toBe(3);
    expect(summary.spendByCurrency).toStrictEqual([
      {
        currency: "USD",
        subscriptionCount: 2,
        yearlyMinor: 19_188 + 36_348,
        monthlyMinor: 4628,
        byCategory: [
          { category: "news", subscriptionCount: 1, yearlyMinor: 36_348, monthlyMinor: 3029 },
          { category: "streaming", subscriptionCount: 1, yearlyMinor: 19_188, monthlyMinor: 1599 },
        ],
      },
      {
        currency: "EUR",
        subscriptionCount: 1,
        yearlyMinor: 11_988,
        monthlyMinor: 999,
        byCategory: [
          { category: "streaming", subscriptionCount: 1, yearlyMinor: 11_988, monthlyMinor: 999 },
        ],
      },
    ]);
  });

  it("matches the documented totals for the seed data", async () => {
    await database.db.insert(subscriptions).values(sampleSubscriptions());

    const totals = (await getSummary()).spendByCurrency.map(
      ({ currency, monthlyMinor, yearlyMinor }) => ({ currency, monthlyMinor, yearlyMinor }),
    );

    // Hand-calculated; the E2E dashboard test relies on the same numbers.
    expect(totals).toEqual([
      { currency: "USD", monthlyMinor: 9625, yearlyMinor: 115_499 },
      // Airtel ₹799/mo + Prime ₹1,499 + Hotstar ₹899 + SonyLIV ₹999 + PS Plus ₹2,999 per year
      { currency: "INR", monthlyMinor: 133_200, yearlyMinor: 1_598_400 },
      { currency: "EUR", monthlyMinor: 999, yearlyMinor: 11_988 },
      { currency: "JPY", monthlyMinor: 200, yearlyMinor: 2400 },
    ]);
  });
});

describe("GET /summary upcoming renewals", () => {
  it("lists renewals in the next 30 days by default, soonest first", async () => {
    await database.db.insert(subscriptions).values([
      { ...base, name: "Later", nextRenewalDate: "2026-11-27" },
      { ...base, name: "Tomorrow", nextRenewalDate: "2026-10-29", amountMinor: 699 },
      { ...base, name: "Outside window", nextRenewalDate: "2026-11-28" },
    ]);

    const { upcomingRenewals } = await getSummary();

    expect(upcomingRenewals.asOf).toBe(today);
    expect(upcomingRenewals.windowDays).toBe(30);
    expect(upcomingRenewals.items).toEqual([
      {
        subscriptionId: expect.any(String),
        name: "Tomorrow",
        amountMinor: 699,
        currency: "USD",
        billingCycle: "monthly",
        renewalDate: "2026-10-29",
        daysUntil: 1,
      },
      expect.objectContaining({ name: "Later", renewalDate: "2026-11-27", daysUntil: 30 }),
    ]);
  });

  it("rolls past-due stored dates forward by billing cycle", async () => {
    await database.db.insert(subscriptions).values({ ...base, nextRenewalDate: "2026-08-31" });

    const { upcomingRenewals } = await getSummary();

    // Aug 31 → Sep 30 → Oct 31 (keeps the 31st where the month has one)
    expect(upcomingRenewals.items[0]).toMatchObject({ renewalDate: "2026-10-31", daysUntil: 3 });
  });

  it("accepts a custom window", async () => {
    await database.db.insert(subscriptions).values([
      { ...base, name: "In a week", nextRenewalDate: "2026-11-04" },
      { ...base, name: "In two weeks", nextRenewalDate: "2026-11-11" },
    ]);

    const { upcomingRenewals } = await getSummary("/summary?renewalWindowDays=7");

    expect(upcomingRenewals.windowDays).toBe(7);
    expect(upcomingRenewals.items.map((item) => item.name)).toEqual(["In a week"]);
  });

  it.each(["0", "366", "1.5", "soon"])("rejects renewalWindowDays=%s", async (value) => {
    const response = await app.inject({
      method: "GET",
      url: `/summary?renewalWindowDays=${value}`,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toMatchObject({
      error: "ValidationError",
      issues: [expect.objectContaining({ path: "renewalWindowDays", location: "querystring" })],
    });
  });
});

describe("GET /summary at the limits (contract-fuzzing regressions)", () => {
  it("totals maximum-amount weekly plans and ancient dates without overflowing", async () => {
    const max = { ...base, amountMinor: 1_000_000_000, billingCycle: "weekly" as const };
    await database.db.insert(subscriptions).values([
      { ...max, name: "Max 1" },
      { ...max, name: "Max 2", nextRenewalDate: "0020-02-29" },
      { ...max, name: "Max 3", nextRenewalDate: "7901-03-01" },
    ]);

    const response = await app.inject({ method: "GET", url: "/summary?renewalWindowDays=364" });

    expect(response.statusCode).toBe(200);
    const summary = SummaryResponseSchema.parse(response.json());
    expect(summary.spendByCurrency[0]?.yearlyMinor).toBe(3 * 52 * 1_000_000_000);
    expect(summary.upcomingRenewals.items.map((item) => item.name)).toEqual(["Max 2", "Max 1"]);
  });
});
