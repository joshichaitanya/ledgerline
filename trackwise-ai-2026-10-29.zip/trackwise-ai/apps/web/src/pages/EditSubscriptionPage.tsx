import { Link, useNavigate, useParams } from "react-router";
import { ApiError, useSubscription, useUpdateSubscription } from "../api/subscriptions";
import { PageHeader } from "../components/PageHeader";
import { SubscriptionForm } from "../components/SubscriptionForm";
import { toFormValues } from "../lib/subscription-form";

export function EditSubscriptionPage() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const subscription = useSubscription(id);
  const update = useUpdateSubscription(id);

  if (subscription.isPending) {
    return (
      <p role="status" className="text-ink-subtle">
        Loading subscription…
      </p>
    );
  }

  if (subscription.isError) {
    const notFound =
      subscription.error instanceof ApiError &&
      (subscription.error.status === 404 || subscription.error.status === 400);
    return (
      <div role="alert" className="space-y-2">
        <p>{notFound ? "Subscription not found." : "Couldn't load the subscription."}</p>
        <Link to="/subscriptions" className="text-accent-ink underline">
          Back to subscriptions
        </Link>
      </div>
    );
  }

  return (
    <section className="max-w-2xl space-y-6">
      <PageHeader
        title={`Edit ${subscription.data.name}`}
        description="Update the price, billing cycle or renewal date."
      />
      <SubscriptionForm
        defaultValues={toFormValues(subscription.data)}
        submitLabel="Save changes"
        onSubmit={(request) =>
          update.mutate(request, { onSuccess: () => navigate("/subscriptions") })
        }
        isSubmitting={update.isPending}
        submitError={update.error}
      />
    </section>
  );
}
