import { expectNoSeriousA11yViolations } from "./support/accessibility";
import { expect, test } from "./support/fixtures";

// Every page is scanned in both themes: dark mode is where contrast bugs hide.
for (const colorScheme of ["light", "dark"] as const) {
  test.describe(`Accessibility (axe, WCAG 2.1 AA) — ${colorScheme} theme`, () => {
    test.use({ colorScheme });

    test("dashboard (KPIs, renewals and charts)", async ({ page }) => {
      await page.goto("/");
      await expect(page.getByRole("region", { name: "Monthly expenditure" })).toBeVisible();
      await expectNoSeriousA11yViolations(page);
    });

    test("settings", async ({ page }) => {
      await page.goto("/settings");
      await expect(page.getByRole("region", { name: "Exchange rates" })).toBeVisible();
      await expectNoSeriousA11yViolations(page);
    });

    test("subscriptions list", async ({ page }) => {
      await page.goto("/subscriptions");
      await expect(page.getByRole("table")).toBeVisible();
      await expectNoSeriousA11yViolations(page);
    });

    test("add form with validation errors showing", async ({ page }) => {
      await page.goto("/subscriptions/new");
      await page.getByRole("button", { name: "Add subscription" }).click();
      await expect(page.getByText("Name is required")).toBeVisible();
      await expectNoSeriousA11yViolations(page);
    });

    test("edit form", async ({ page, arrange }) => {
      const subscription = await arrange.subscription();
      await page.goto(`/subscriptions/${subscription.id}/edit`);
      await expect(page.getByLabel("Amount")).toHaveValue("9.99");
      await expectNoSeriousA11yViolations(page);
    });

    test("delete confirmation dialog", async ({ page }) => {
      await page.goto("/subscriptions");
      await page.getByRole("button", { name: "Delete Netflix" }).click();
      await expect(page.getByRole("alertdialog")).toBeVisible();
      await expectNoSeriousA11yViolations(page);
    });
  });
}
