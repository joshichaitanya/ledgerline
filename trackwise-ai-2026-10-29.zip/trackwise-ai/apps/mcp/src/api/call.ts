import type { CallToolResult } from "@modelcontextprotocol/sdk/types.js";
import { API_URL } from "./client";
import type { components } from "./schema.gen";

type ErrorResponse = components["schemas"]["ErrorResponse"];

/*
 * Step 4.4 — two kinds of failure in MCP:
 *
 * - PROTOCOL errors (JSON-RPC `error`): the request can't be handled at all, e.g. an unknown
 *   tool name. The SDK produces these; the model never gets a result.
 * - TOOL errors (a normal result with `isError: true`): the model READS these and can recover,
 *   so the message should say what happened and what to do next ("use list_subscriptions to
 *   find ids"), not just "HTTP 404". Two sources:
 *     · arguments that fail the input schema — the SDK reports these as tool errors itself, so
 *       the model sees e.g. "expected number to be >=1 at days" and can retry with valid input;
 *     · failures inside our handler — API down, unknown id, rejected data (handled below).
 */

/** A failure the model should be told about, in words it can act on. */
export class ToolError extends Error {}

/** The thing asked for doesn't exist (HTTP 404). Resources report this as "not found". */
export class NotFoundError extends ToolError {}

/** The shape openapi-fetch resolves to. */
interface ApiResult<T> {
  data?: T;
  error?: unknown;
  response: Response;
}

/**
 * Awaits a typed API call and returns its data, or throws a ToolError explaining the failure.
 * `notFound` is the message to use for a 404 (only callers know what was being looked up).
 */
export async function fromApi<T>(
  call: Promise<ApiResult<T>>,
  { notFound }: { notFound?: string } = {},
): Promise<T> {
  let result: ApiResult<T>;
  try {
    result = await call;
  } catch {
    // fetch() rejects only when there is no HTTP response at all: refused, DNS, timeout.
    throw new ToolError(
      `The TrackWise API is not reachable at ${API_URL}. It may not be running — ask the user ` +
        "to start it (`pnpm dev`) and then try again.",
    );
  }
  if (result.data !== undefined) return result.data;

  const { status } = result.response;
  const body = result.error as ErrorResponse | undefined;
  if (status === 404 && notFound) throw new NotFoundError(notFound);
  if (status === 400 && body?.issues?.length) {
    const issues = body.issues.map((issue) => `${issue.path}: ${issue.message}`).join("; ");
    throw new ToolError(`The request was rejected — ${issues}. Fix these values and retry.`);
  }
  throw new ToolError(
    `The TrackWise API failed (HTTP ${status}${body?.message ? `: ${body.message}` : ""}).`,
  );
}

/**
 * Wraps a tool handler so failures become TOOL errors (isError: true) instead of crashing.
 * ToolErrors keep their message; anything unexpected is reported without internals.
 */
export function safely<Args extends unknown[]>(
  handler: (...args: Args) => Promise<CallToolResult>,
): (...args: Args) => Promise<CallToolResult> {
  return async (...args) => {
    try {
      return await handler(...args);
    } catch (error) {
      const message =
        error instanceof ToolError
          ? error.message
          : "Unexpected error in the TrackWise MCP server. Try again; if it persists, check the server logs.";
      if (!(error instanceof ToolError)) process.stderr.write(`Tool failed: ${String(error)}\n`);
      return { isError: true, content: [{ type: "text", text: message }] };
    }
  };
}
