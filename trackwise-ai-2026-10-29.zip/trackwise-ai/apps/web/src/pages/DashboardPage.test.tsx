import { screen, within } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import type { AnalyticsResponse } from "../api/analytics";
import type { CurrencySpend, SummaryResponse } from "../api/summary";
import { mockApi, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { DashboardPage } from "./DashboardPage";

const usd: CurrencySpend = {
  currency: "USD",
  subscriptionCount: 2,
  monthlyMinor: 4628,
  yearlyMinor: 55_536,
  byCategory: [
    { category: "news", subscriptionCount: 1, monthlyMinor: 3029, yearlyMinor: 36_348 },
    { category: "streaming", subscriptionCount: 1, monthlyMinor: 1599, yearlyMinor: 19_188 },
  ],
};

const eur: CurrencySpend = {
  currency: "EUR",
  subscriptionCount: 1,
  monthlyMinor: 999,
  yearlyMinor: 11_988,
  byCategory: [
    { category: "streaming", subscriptionCount: 1, monthlyMinor: 999, yearlyMinor: 11_988 },
  ],
};

const noRenewals: SummaryResponse["upcomingRenewals"] = {
  asOf: "2026-10-28",
  windowDays: 30,
  items: [],
};

/** Default `converted`: the first currency is primary and nothing else has a rate. */
function withoutRates(spend: CurrencySpend[]): SummaryResponse["converted"] {
  const [primary, ...others] = spend;
  return {
    currency: primary?.currency ?? "USD",
    subscriptionCount: primary?.subscriptionCount ?? 0,
    monthlyMinor: primary?.monthlyMinor ?? 0,
    yearlyMinor: primary?.yearlyMinor ?? 0,
    averageMonthlyMinor: primary ? Math.round(primary.monthlyMinor / primary.subscriptionCount) : 0,
    byCategory: primary?.byCategory ?? [],
    unconvertedCurrencies: others.map((other) => other.currency),
  };
}

const months = (startMonth: number, values: number[]) =>
  values.map((amountMinor, index) => ({
    month: new Date(Date.UTC(2026, startMonth - 1 + index, 1)).toISOString().slice(0, 7),
    amountMinor,
  }));

const analytics: AnalyticsResponse = {
  currency: "USD",
  asOf: "2026-10-28",
  yearToDateMinor: 37_500,
  spendingTrend: months(
    -1,
    Array.from({ length: 12 }, (_, i) => (i + 1) * 100),
  ),
  forecast: months(11, [4000, 4000, 4500, 4000, 4000, 4500]),
  monthlyExpenditure: {
    year: 2026,
    months: months(
      1,
      Array.from({ length: 12 }, () => 4000),
    ).map((m, index) => ({
      ...m,
      kind: index < 9 ? "actual" : index === 9 ? "current" : "projected",
    })),
  },
  unconvertedCurrencies: [],
};

type SummaryFixture = Pick<SummaryResponse, "subscriptionCount" | "spendByCurrency"> &
  Partial<Pick<SummaryResponse, "converted" | "upcomingRenewals">>;

function renderWith(summary: SummaryFixture, analyticsBody: AnalyticsResponse = analytics) {
  mockApi(
    route("get", "/summary").reply(() => ({
      status: 200,
      body: {
        converted: withoutRates(summary.spendByCurrency),
        upcomingRenewals: noRenewals,
        ...summary,
      },
    })),
    route("get", "/analytics").reply(() => ({ status: 200, body: analyticsBody })),
  );
  renderWithQueryClient(<DashboardPage />);
  return userEvent.setup();
}

describe("DashboardPage KPIs", () => {
  it("shows monthly, yearly, Year-to-date, count and average tiles", async () => {
    renderWith({ subscriptionCount: 2, spendByCurrency: [usd] });

    expect(await screen.findByRole("region", { name: "Monthly spend" })).toHaveTextContent(
      "$46.28",
    );
    expect(screen.getByRole("region", { name: "Yearly spend" })).toHaveTextContent("$555.36");
    expect(screen.getByRole("region", { name: "Year-to-date" })).toHaveTextContent("$375.00");
    expect(screen.getByRole("region", { name: "Active subscriptions" })).toHaveTextContent("2");
    // 4628 / 2 subscriptions = 2314 → $23.14 per month
    expect(screen.getByRole("region", { name: "Avg per subscription" })).toHaveTextContent(
      "$23.14",
    );
  });

  it("lists currencies without a rate separately instead of summing them", async () => {
    renderWith({ subscriptionCount: 3, spendByCurrency: [usd, eur] });

    const monthly = await screen.findByRole("region", { name: "Monthly spend" });
    expect(monthly).toHaveTextContent("$46.28");
    expect(monthly).toHaveTextContent("+ €9.99 (no rate)");
    expect(screen.getByRole("region", { name: "Yearly spend" })).toHaveTextContent(
      "+ €119.88 (no rate)",
    );
    expect(screen.getByText(/No rate for EUR: shown separately/)).toBeInTheDocument();
  });

  it("shows converted totals when a rate exists", async () => {
    renderWith({
      subscriptionCount: 3,
      spendByCurrency: [usd, eur],
      // €9.99 × 1.1 = $10.99 → $46.28 + $10.99 = $57.27
      converted: {
        currency: "USD",
        subscriptionCount: 3,
        monthlyMinor: 5727,
        yearlyMinor: 68_723,
        averageMonthlyMinor: 1909,
        byCategory: [
          { category: "streaming", subscriptionCount: 2, monthlyMinor: 2698, yearlyMinor: 32_375 },
          { category: "news", subscriptionCount: 1, monthlyMinor: 3029, yearlyMinor: 36_348 },
        ],
        unconvertedCurrencies: [],
      },
    });

    const monthly = await screen.findByRole("region", { name: "Monthly spend" });
    expect(monthly).toHaveTextContent("$57.27");
    expect(monthly).not.toHaveTextContent("€");
    expect(screen.getByRole("region", { name: "Avg per subscription" })).toHaveTextContent(
      "$19.09",
    );
    expect(screen.getByText(/converted to USD using exchange rates/)).toBeInTheDocument();
  });

  it("shows an empty state with a link to add one", async () => {
    renderWith({ subscriptionCount: 0, spendByCurrency: [] });

    expect(await screen.findByText("No subscriptions yet.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Add a subscription" })).toHaveAttribute(
      "href",
      "/subscriptions/new",
    );
  });
});

describe("DashboardPage charts", () => {
  it("labels every category with its amount and share, highest first", async () => {
    renderWith({ subscriptionCount: 2, spendByCurrency: [usd] });

    const breakdown = await screen.findByRole("region", { name: "Category breakdown" });
    const items = within(breakdown).getAllByRole("listitem");
    expect(items[0]).toHaveTextContent("News$30.29 · 65%");
    expect(items[1]).toHaveTextContent("Streaming$15.99 · 35%");
  });

  it("offers every chart's numbers as a table", async () => {
    const user = renderWith({ subscriptionCount: 2, spendByCurrency: [usd] });

    const forecast = await screen.findByRole("region", { name: "6-month forecast" });
    await user.click(within(forecast).getByText("Show data"));
    const rows = await within(forecast).findAllByRole("row");
    expect(rows).toHaveLength(7); // header + 6 months
    expect(rows[1]).toHaveTextContent("Nov 2026$40.00");

    const trends = screen.getByRole("region", { name: "Spending trends" });
    await user.click(within(trends).getByText("Show data"));
    expect(await within(trends).findAllByRole("row")).toHaveLength(13); // header + 12 months

    const expenditure = screen.getByRole("region", { name: "Monthly expenditure" });
    await user.click(within(expenditure).getByText("Show data"));
    // <details> opens asynchronously after the click, so wait for the rows.
    const expenditureRows = await within(expenditure).findAllByRole("row");
    expect(expenditureRows[10]).toHaveTextContent("Oct 2026 · This month$40.00");
    expect(expenditureRows[11]).toHaveTextContent("Nov 2026 · Scheduled");
  });

  it("says which currencies are excluded from charts for lack of a rate", async () => {
    renderWith(
      { subscriptionCount: 2, spendByCurrency: [usd] },
      { ...analytics, unconvertedCurrencies: ["JPY"] },
    );

    expect(
      await screen.findByText(
        /No rate for JPY: shown separately, not included in totals or charts/,
      ),
    ).toBeInTheDocument();
  });

  it("shows an error with a working retry", async () => {
    let fail = true;
    mockApi(
      route("get", "/summary").reply(() => ({
        status: 200,
        body: {
          subscriptionCount: 2,
          spendByCurrency: [usd],
          converted: withoutRates([usd]),
          upcomingRenewals: noRenewals,
        },
      })),
      route("get", "/analytics").reply(() => {
        if (fail) throw new TypeError("Failed to fetch");
        return { status: 200, body: analytics };
      }),
    );
    const user = userEvent.setup();
    renderWithQueryClient(<DashboardPage />);

    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent("Couldn't load the dashboard.");
    fail = false;
    await user.click(within(alert).getByRole("button", { name: "Retry" }));

    expect(await screen.findByRole("region", { name: "Year-to-date" })).toHaveTextContent(
      "$375.00",
    );
  });
});

describe("DashboardPage renewing soon", () => {
  const renewal = (name: string, daysUntil: number, renewalDate: string) => ({
    subscriptionId: crypto.randomUUID(),
    name,
    amountMinor: 1599,
    currency: "USD" as const,
    billingCycle: "monthly" as const,
    renewalDate,
    daysUntil,
  });

  it("lists renewals with dates and relative days, highlighting those due within a week", async () => {
    renderWith({
      subscriptionCount: 2,
      spendByCurrency: [usd],
      upcomingRenewals: {
        asOf: "2026-10-28",
        windowDays: 30,
        items: [
          renewal("Netflix", 1, "2026-10-29"),
          renewal("Spotify", 7, "2026-11-04"),
          renewal("iCloud+", 20, "2026-11-17"),
        ],
      },
    });

    const panel = await screen.findByRole("region", { name: "Renewing soon" });
    const [netflix, spotify, icloud] = within(panel).getAllByRole("listitem");
    expect(netflix).toHaveTextContent("Netflix");
    expect(netflix).toHaveTextContent("Oct 29, 2026 · Tomorrow");
    expect(netflix).toHaveTextContent("Due soon");
    expect(spotify).toHaveTextContent("In 7 days");
    expect(spotify).toHaveTextContent("Due soon");
    expect(icloud).toHaveTextContent("In 20 days");
    expect(icloud).not.toHaveTextContent("Due soon");
  });

  it("says when nothing renews in the window", async () => {
    renderWith({ subscriptionCount: 2, spendByCurrency: [usd] });

    const panel = await screen.findByRole("region", { name: "Renewing soon" });
    expect(panel).toHaveTextContent("Nothing renews in the next 30 days.");
  });
});
