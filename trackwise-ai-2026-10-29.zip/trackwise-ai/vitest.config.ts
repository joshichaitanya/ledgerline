import { defineConfig } from "vitest/config";

// Each workspace package with a vitest.config.ts becomes a test project.
export default defineConfig({
  test: {
    projects: ["apps/*/vitest.config.ts", "packages/*/vitest.config.ts"],
    coverage: {
      provider: "v8",
      include: ["apps/*/src/**", "packages/*/src/**"],
      exclude: [
        "**/*.gen.ts",
        "**/*.test.{ts,tsx}",
        "**/test/**",
        // Entry points: process wiring, exercised by E2E rather than unit tests.
        "apps/api/src/server.ts",
        "apps/mcp/src/server.ts",
        "apps/web/src/main.tsx",
      ],
      reporter: ["text", "text-summary", "html", "json-summary"],
      reportsDirectory: "reports/coverage",
      // A few points below the measured baseline per package: stops coverage drifting down
      // without demanding busywork tests. Raise them as coverage improves.
      thresholds: {
        "packages/contracts/src/**": { statements: 95, branches: 90, functions: 95, lines: 95 },
        "apps/api/src/**": { statements: 85, branches: 80, functions: 80, lines: 85 },
        "apps/web/src/**": { statements: 85, branches: 70, functions: 85, lines: 85 },
        "apps/mcp/src/**": { statements: 90, branches: 80, functions: 95, lines: 90 },
      },
    },
  },
});
