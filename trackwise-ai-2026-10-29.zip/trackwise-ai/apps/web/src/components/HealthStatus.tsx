import { useHealth } from "../api/health";

type Indicator = "ok" | "down" | "unreachable" | "checking" | "unknown";

const dotColor: Record<Indicator, string> = {
  ok: "bg-success",
  down: "bg-danger",
  unreachable: "bg-danger",
  checking: "bg-neutral-dot",
  unknown: "bg-neutral-dot",
};

export function HealthStatus() {
  const { data, isPending, isError } = useHealth();

  const apiState: Indicator = isPending ? "checking" : isError ? "unreachable" : data.checks.api;
  const databaseState: Indicator = isPending
    ? "checking"
    : isError
      ? "unknown"
      : data.checks.database;

  return (
    <div role="status" aria-label="System status">
      <ul className="flex gap-4 text-sm text-ink-muted">
        <Item label="API" state={apiState} />
        <Item label="Database" state={databaseState} />
      </ul>
    </div>
  );
}

function Item({ label, state }: { label: string; state: Indicator }) {
  return (
    <li className="flex items-center gap-1.5">
      <span aria-hidden="true" className={`size-2 rounded-full ${dotColor[state]}`} />
      {label}: {state}
    </li>
  );
}
