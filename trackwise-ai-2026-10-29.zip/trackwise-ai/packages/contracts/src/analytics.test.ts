import { describe, expect, it } from "vitest";
import { buildAnalytics, type Charge, scheduledCharges, shiftMonth } from "./analytics";
import type { Currency } from "./subscription";

const today = "2026-10-28";
const subscriptions = [
  // Monthly $15.99 on the 15th; weekly $5.00 from Oct 30.
  { amountMinor: 1599, currency: "USD", billingCycle: "monthly", nextRenewalDate: "2026-11-15" },
  { amountMinor: 500, currency: "USD", billingCycle: "weekly", nextRenewalDate: "2026-10-30" },
] as const;
const usd = (date: string, amountMinor: number): Charge => ({ date, amountMinor, currency: "USD" });
const payments: Charge[] = [
  usd("2025-10-15", 1599), // before the 12-month trend window
  usd("2025-11-15", 1599),
  { date: "2026-01-10", amountMinor: 999, currency: "EUR" },
  usd("2026-09-15", 1599),
  usd("2026-10-15", 1599),
  usd("2026-10-23", 500),
];

const analytics = (rates: Map<Currency, number> = new Map()) =>
  buildAnalytics({ payments, subscriptions, today, primary: "USD", rates });

describe("shiftMonth", () => {
  it.each([
    ["2026-10", 1, "2026-11"],
    ["2026-12", 1, "2027-01"],
    ["2026-01", -1, "2025-12"],
    ["2026-10", -11, "2025-11"],
  ])("%s %+i → %s", (month, by, expected) => {
    expect(shiftMonth(month, by)).toBe(expected);
  });
});

describe("scheduledCharges", () => {
  it("lists every renewal in the range, inclusive", () => {
    const dates = scheduledCharges(subscriptions, "2026-11-01", "2026-11-30").map((c) => c.date);

    expect(dates.sort()).toEqual([
      "2026-11-06",
      "2026-11-13",
      "2026-11-15",
      "2026-11-20",
      "2026-11-27",
    ]);
  });
});

describe("buildAnalytics", () => {
  it("builds a 12-month spending trend from payments, ending this month", () => {
    const { spendingTrend } = analytics();

    expect(spendingTrend).toHaveLength(12);
    expect(spendingTrend[0]).toEqual({ month: "2025-11", amountMinor: 1599 });
    expect(spendingTrend.at(-1)).toEqual({ month: "2026-10", amountMinor: 1599 + 500 });
    expect(spendingTrend.find((m) => m.month === "2026-01")?.amountMinor).toBe(0); // EUR, no rate
  });

  it("totals this year's payments as Year-to-Date", () => {
    expect(analytics().yearToDateMinor).toBe(1599 + 1599 + 500);
  });

  it("forecasts the next 6 months from the renewal schedule", () => {
    // Monthly $15.99 plus 4 or 5 weekly $5.00 renewals per month.
    expect(analytics().forecast).toEqual([
      { month: "2026-11", amountMinor: 1599 + 4 * 500 },
      { month: "2026-12", amountMinor: 1599 + 4 * 500 },
      { month: "2027-01", amountMinor: 1599 + 5 * 500 },
      { month: "2027-02", amountMinor: 1599 + 4 * 500 },
      { month: "2027-03", amountMinor: 1599 + 4 * 500 },
      { month: "2027-04", amountMinor: 1599 + 5 * 500 },
    ]);
  });

  it("splits this year into actual, current and projected months without double counting", () => {
    const { year, months } = analytics().monthlyExpenditure;
    const byMonth = Object.fromEntries(months.map((m) => [m.month, m]));

    expect(year).toBe(2026);
    expect(months).toHaveLength(12);
    expect(byMonth["2026-09"]).toEqual({ month: "2026-09", amountMinor: 1599, kind: "actual" });
    // October: $20.99 paid so far + the weekly renewal still to come on Oct 30.
    expect(byMonth["2026-10"]).toEqual({
      month: "2026-10",
      amountMinor: 2099 + 500,
      kind: "current",
    });
    expect(byMonth["2026-12"]).toEqual({
      month: "2026-12",
      amountMinor: 1599 + 4 * 500,
      kind: "projected",
    });
  });

  it("excludes and reports currencies without a rate, and converts them once a rate exists", () => {
    expect(analytics().unconvertedCurrencies).toEqual(["EUR"]);

    const converted = analytics(new Map([["EUR", 1.1]]));

    expect(converted.unconvertedCurrencies).toEqual([]);
    // €9.99 × 1.1 = $10.989 → $10.99
    expect(converted.spendingTrend.find((m) => m.month === "2026-01")?.amountMinor).toBe(1099);
    expect(converted.yearToDateMinor).toBe(1599 + 1599 + 500 + 1099);
  });
});
