import { test as base } from "@playwright/test";
import createClient, { type Client } from "openapi-fetch";
import type { components, paths } from "./schema.gen";

export { expect } from "@playwright/test";

type Subscription = components["schemas"]["Subscription"];
type CreateSubscriptionRequest = components["schemas"]["CreateSubscriptionRequestInput"];

export interface Arrange {
  /** Creates a subscription through the API; deleted automatically after the test. */
  subscription(overrides?: Partial<CreateSubscriptionRequest>): Promise<Subscription>;
  /** Registers rows the test creates through the UI (by name) for the same cleanup. */
  cleanUpNamed(name: string): void;
  /** Restores the default settings (USD, no exchange rates) after the test. */
  resetSettingsAfter(): void;
}

interface Fixtures {
  /** API client typed from apps/api/openapi.json (through the web proxy, like the browser). */
  api: Client<paths>;
  arrange: Arrange;
}

export const test = base.extend<Fixtures>({
  api: async ({ baseURL }, use) => {
    await use(createClient<paths>({ baseUrl: `${baseURL}/api` }));
  },

  arrange: async ({ api }, use) => {
    const createdIds: string[] = [];
    const namesToRemove: string[] = [];
    let resetSettings = false;

    await use({
      async subscription(overrides = {}) {
        const { data, error, response } = await api.POST("/subscriptions", {
          body: {
            name: uniqueName("Arranged"),
            amountMinor: 999,
            currency: "USD",
            billingCycle: "monthly",
            category: "other",
            nextRenewalDate: "2099-01-01",
            ...overrides,
          },
        });
        if (!data)
          throw new Error(`Arrange failed: HTTP ${response.status} ${JSON.stringify(error)}`);
        createdIds.push(data.id);
        return data;
      },
      cleanUpNamed(name) {
        namesToRemove.push(name);
      },
      resetSettingsAfter() {
        resetSettings = true;
      },
    });

    // Teardown runs even when the test fails, so shared E2E data stays as seeded.
    if (namesToRemove.length > 0) {
      const { data } = await api.GET("/subscriptions");
      for (const item of data?.items ?? []) {
        if (namesToRemove.includes(item.name)) createdIds.push(item.id);
      }
    }
    for (const id of createdIds) {
      await api.DELETE("/subscriptions/{id}", { params: { path: { id } } });
    }
    if (resetSettings) {
      // Rates first: with no rates, switching back to USD can never be refused.
      const { data } = await api.GET("/exchange-rates");
      for (const { currency } of data?.items ?? []) {
        await api.DELETE("/exchange-rates/{currency}", { params: { path: { currency } } });
      }
      await api.PUT("/settings", { body: { primaryCurrency: "USD" } });
    }
  },
});

/** Unique per run, so leftovers from an aborted run can never collide. */
export function uniqueName(prefix: string): string {
  return `${prefix} ${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

/** A UTC calendar date `days` from now, matching how the API decides "today". */
export function utcDateFromToday(days: number): string {
  return new Date(Date.now() + days * 86_400_000).toISOString().slice(0, 10);
}
