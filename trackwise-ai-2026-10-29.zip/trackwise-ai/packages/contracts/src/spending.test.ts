import { describe, expect, it } from "vitest";
import { convertSpending, summarizeSpending, toMonthlyMinor, toYearlyMinor } from "./spending";
import type { Subscription } from "./subscription";

type Spendable = Pick<Subscription, "amountMinor" | "currency" | "billingCycle" | "category">;

const usd = (
  amountMinor: number,
  billingCycle: Spendable["billingCycle"],
  category: Spendable["category"] = "streaming",
): Spendable => ({ amountMinor, currency: "USD", billingCycle, category });

describe("toYearlyMinor / toMonthlyMinor", () => {
  it.each([
    [699, "weekly", 36_348, 3029],
    [1599, "monthly", 19_188, 1599],
    [10_000, "yearly", 10_000, 833],
    [7999, "yearly", 7999, 667],
  ] as const)("%i %s → %i/yr, %i/mo", (amount, cycle, yearly, monthly) => {
    expect(toYearlyMinor(amount, cycle)).toBe(yearly);
    expect(toMonthlyMinor(amount, cycle)).toBe(monthly);
  });
});

describe("summarizeSpending", () => {
  it("returns zeroes for no subscriptions", () => {
    expect(summarizeSpending([])).toEqual({ subscriptionCount: 0, spendByCurrency: [] });
  });

  it("normalises mixed billing cycles into monthly and yearly totals", () => {
    const summary = summarizeSpending([
      usd(699, "weekly"),
      usd(1599, "monthly"),
      usd(10_000, "yearly"),
    ]);

    expect(summary.spendByCurrency[0]).toMatchObject({
      currency: "USD",
      subscriptionCount: 3,
      yearlyMinor: 36_348 + 19_188 + 10_000,
      monthlyMinor: Math.round(65_536 / 12),
    });
  });

  it("rounds once per total, not per subscription", () => {
    // Each is 83.33/mo; rounding each first would total 249, the true total is 250.
    const summary = summarizeSpending([
      usd(1000, "yearly"),
      usd(1000, "yearly"),
      usd(1000, "yearly"),
    ]);

    expect(summary.spendByCurrency[0]?.monthlyMinor).toBe(250);
  });

  it("keeps currencies separate, most subscriptions first", () => {
    const summary = summarizeSpending([
      { amountMinor: 999, currency: "EUR", billingCycle: "monthly", category: "streaming" },
      usd(1599, "monthly"),
      usd(1199, "monthly", "music"),
      { amountMinor: 2400, currency: "JPY", billingCycle: "yearly", category: "gaming" },
    ]);

    expect(summary.subscriptionCount).toBe(4);
    expect(
      summary.spendByCurrency.map(({ currency, monthlyMinor }) => [currency, monthlyMinor]),
    ).toEqual([
      ["USD", 2798],
      ["EUR", 999],
      ["JPY", 200],
    ]);
  });

  it("breaks spend down by category, highest first", () => {
    const summary = summarizeSpending([
      usd(299, "monthly", "cloud"),
      usd(1599, "monthly", "streaming"),
      usd(1199, "monthly", "music"),
      usd(1399, "monthly", "streaming"),
    ]);

    expect(summary.spendByCurrency[0]?.byCategory).toEqual([
      { category: "streaming", subscriptionCount: 2, monthlyMinor: 2998, yearlyMinor: 35_976 },
      { category: "music", subscriptionCount: 1, monthlyMinor: 1199, yearlyMinor: 14_388 },
      { category: "cloud", subscriptionCount: 1, monthlyMinor: 299, yearlyMinor: 3588 },
    ]);
  });
});

describe("convertSpending", () => {
  const spend = summarizeSpending([
    { amountMinor: 1599, currency: "USD", billingCycle: "monthly", category: "streaming" },
    { amountMinor: 999, currency: "EUR", billingCycle: "monthly", category: "streaming" },
    { amountMinor: 1199, currency: "USD", billingCycle: "monthly", category: "music" },
    { amountMinor: 2400, currency: "JPY", billingCycle: "yearly", category: "gaming" },
  ]).spendByCurrency;

  it("merges convertible currencies into the primary and lists the rest", () => {
    const converted = convertSpending(spend, "USD", new Map([["EUR", 1.1]]));

    // USD 33,576/yr + EUR 11,988/yr × 1.1 = 13,187 → 46,763/yr → 3,897/mo
    expect(converted).toMatchObject({
      currency: "USD",
      subscriptionCount: 3,
      yearlyMinor: 46_763,
      monthlyMinor: 3897,
      averageMonthlyMinor: 1299,
      unconvertedCurrencies: ["JPY"],
    });
    expect(converted.byCategory.map((c) => [c.category, c.yearlyMinor])).toEqual([
      ["streaming", 19_188 + 13_187],
      ["music", 14_388],
    ]);
  });

  it("returns zero totals, not an error, when nothing can be converted", () => {
    const converted = convertSpending(spend, "GBP", new Map());

    expect(converted).toMatchObject({
      subscriptionCount: 0,
      monthlyMinor: 0,
      averageMonthlyMinor: 0,
      byCategory: [],
      unconvertedCurrencies: ["EUR", "JPY", "USD"],
    });
  });
});
