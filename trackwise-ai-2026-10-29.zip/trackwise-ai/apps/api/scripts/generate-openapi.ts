/**
 * Writes the OpenAPI spec derived from the route schemas to apps/api/openapi.json.
 * With --check, fails instead if the committed spec is out of date (contract drift).
 */
import { readFile, writeFile } from "node:fs/promises";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";

const outputPath = new URL("../openapi.json", import.meta.url);
const checkOnly = process.argv.includes("--check");

// Never queried: postgres.js only connects on the first query.
const database = createDatabase("postgres://unused@localhost/unused");
const app = await buildApp({ database });
await app.ready();
const spec = `${JSON.stringify(app.swagger(), null, 2)}\n`;
await app.close();
await database.close();

if (checkOnly) {
  const current = await readFile(outputPath, "utf8").catch(() => "");
  if (current !== spec) {
    console.error("apps/api/openapi.json is out of date. Run `pnpm openapi:generate`.");
    process.exit(1);
  }
  console.log("apps/api/openapi.json is up to date.");
} else {
  await writeFile(outputPath, spec);
  console.log("Wrote apps/api/openapi.json");
}
