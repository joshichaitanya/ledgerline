import type { components } from "../api/schema.gen";

type Schemas = components["schemas"];

export function aSubscription(
  overrides: Partial<Schemas["Subscription"]> = {},
): Schemas["Subscription"] {
  return {
    id: crypto.randomUUID(),
    name: "Netflix",
    amountMinor: 1599,
    currency: "USD",
    billingCycle: "monthly",
    category: "streaming",
    nextRenewalDate: "2026-11-15",
    notes: null,
    createdAt: "2026-10-01T00:00:00.000Z",
    updatedAt: "2026-10-01T00:00:00.000Z",
    ...overrides,
  };
}

export function aPayment(
  subscriptionId: string,
  paidOn: string,
  amountMinor = 1599,
): Schemas["Payment"] {
  return {
    id: crypto.randomUUID(),
    subscriptionId,
    paidOn,
    amountMinor,
    currency: "USD",
    createdAt: "2026-10-01T00:00:00.000Z",
    updatedAt: "2026-10-01T00:00:00.000Z",
  };
}

export const summary: Schemas["SummaryResponse"] = {
  subscriptionCount: 3,
  spendByCurrency: [],
  converted: {
    currency: "USD",
    subscriptionCount: 2,
    monthlyMinor: 4000,
    yearlyMinor: 48_000,
    averageMonthlyMinor: 2000,
    byCategory: [
      { category: "streaming", subscriptionCount: 1, monthlyMinor: 3000, yearlyMinor: 36_000 },
      { category: "music", subscriptionCount: 1, monthlyMinor: 1000, yearlyMinor: 12_000 },
    ],
    unconvertedCurrencies: ["ISK"],
  },
  upcomingRenewals: {
    asOf: "2026-10-29",
    windowDays: 30,
    items: [
      {
        subscriptionId: crypto.randomUUID(),
        name: "Netflix",
        amountMinor: 1599,
        currency: "USD",
        billingCycle: "monthly",
        renewalDate: "2026-10-30",
        daysUntil: 1,
      },
    ],
  },
};

export const analytics: Schemas["AnalyticsResponse"] = {
  currency: "USD",
  asOf: "2026-10-29",
  yearToDateMinor: 37_500,
  spendingTrend: [],
  forecast: [],
  monthlyExpenditure: { year: 2026, months: [] },
  unconvertedCurrencies: [],
};
