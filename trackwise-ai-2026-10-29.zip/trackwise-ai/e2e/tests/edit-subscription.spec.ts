import { expect, test } from "./support/fixtures";

test.describe("Edit a subscription", () => {
  test("changes the price and shows it in the list", async ({ page, arrange }) => {
    const subscription = await arrange.subscription({ amountMinor: 999 });

    await page.goto("/subscriptions");
    await page.getByRole("link", { name: `Edit ${subscription.name}` }).click();

    await expect(page.getByRole("heading", { name: `Edit ${subscription.name}` })).toBeVisible();
    await expect(page.getByLabel("Amount")).toHaveValue("9.99");
    await page.getByLabel("Amount").fill("21.50");
    await page.getByRole("button", { name: "Save changes" }).click();

    await expect(page).toHaveURL(/\/subscriptions$/);
    await expect(page.getByRole("row").filter({ hasText: subscription.name })).toContainText(
      "$21.50",
    );
  });

  test("cancel leaves the subscription unchanged", async ({ page, arrange }) => {
    const subscription = await arrange.subscription({ amountMinor: 999 });

    await page.goto(`/subscriptions/${subscription.id}/edit`);
    await page.getByLabel("Amount").fill("1.00");
    await page.getByRole("link", { name: "Cancel" }).click();

    await expect(page.getByRole("row").filter({ hasText: subscription.name })).toContainText(
      "$9.99",
    );
  });
});
