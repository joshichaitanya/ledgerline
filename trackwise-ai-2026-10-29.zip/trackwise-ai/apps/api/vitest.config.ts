import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    name: "api",
    include: ["test/**/*.test.ts"],
    globalSetup: ["./test/global-setup.ts"],
    // Test files share one database and clean tables between tests, so run them one at a time.
    fileParallelism: false,
  },
});
