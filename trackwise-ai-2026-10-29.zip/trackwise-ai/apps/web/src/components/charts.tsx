import { formatMoney } from "@subtrack/contracts";
import { type ReactNode, useId } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { components } from "../api/schema.gen";
import { type ChartColors, categoryColor } from "../lib/chart-colors";
import { categoryLabel, formatMonth } from "../lib/format";

type MonthlyAmount = components["schemas"]["MonthlyAmount"];
type ExpenditureMonth = components["schemas"]["ExpenditureMonth"];
type CategorySpend = components["schemas"]["CategorySpend"];

// Charts are drawn for sighted users; every card also offers the same numbers as a table
// ("Show data"), which is what screen readers use. Recharts' keyboard layer is turned off so
// the hidden SVG contains nothing focusable.

/** A titled card holding one chart and its data table. */
export function ChartCard({
  title,
  description,
  table,
  children,
  legend,
}: {
  title: string;
  description: string;
  table: ReactNode;
  children: ReactNode;
  legend?: ReactNode;
}) {
  const headingId = useId();
  return (
    <section aria-labelledby={headingId} className="rounded-xl border border-line bg-surface p-6">
      <h3 id={headingId} className="text-lg font-semibold">
        {title}
      </h3>
      <p className="text-sm text-ink-subtle">{description}</p>
      <div aria-hidden="true" className="mt-4 h-64">
        {children}
      </div>
      {legend}
      <details className="mt-3 text-sm">
        <summary className="cursor-pointer text-accent-ink">Show data</summary>
        <div className="mt-2 max-h-64 overflow-auto">{table}</div>
      </details>
    </section>
  );
}

/** Two-column data table: label + formatted amount. */
export function DataTable({
  caption,
  rows,
}: {
  caption: string;
  rows: { label: string; value: string; note?: string }[];
}) {
  return (
    <table className="w-full text-left">
      <caption className="sr-only">{caption}</caption>
      <thead className="text-xs uppercase text-ink-muted">
        <tr>
          <th scope="col" className="py-1 font-medium">
            Period
          </th>
          <th scope="col" className="py-1 text-right font-medium">
            Amount
          </th>
        </tr>
      </thead>
      <tbody className="divide-y divide-line">
        {rows.map((row) => (
          <tr key={row.label}>
            <th scope="row" className="py-1 font-normal">
              {row.label}
              {row.note && <span className="text-ink-subtle"> · {row.note}</span>}
            </th>
            <td className="py-1 text-right tabular-nums">{row.value}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

const shortMonth = (yearMonth: string) =>
  formatMonth(yearMonth).replace(/ (\d{2})(\d{2})$/, " '$2");

/** Axis ticks: compact whole amounts in the major unit ("$1.2K"). */
function compactMoney(currency: string) {
  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    notation: "compact",
    maximumFractionDigits: 1,
  });
  return (major: number) => formatter.format(major);
}

function axesFor(colors: ChartColors, currency: string, minorDigits: number) {
  const tick = { fill: colors.axis, fontSize: 12 };
  return {
    grid: <CartesianGrid stroke={colors.grid} vertical={false} />,
    xAxis: (
      <XAxis dataKey="label" tick={tick} tickLine={false} axisLine={{ stroke: colors.grid }} />
    ),
    yAxis: (
      <YAxis
        tick={tick}
        tickLine={false}
        axisLine={false}
        width={56}
        tickFormatter={compactMoney(currency)}
      />
    ),
    tooltip: (
      <Tooltip
        formatter={(value) => formatMoney(Math.round(Number(value) * 10 ** minorDigits), currency)}
        contentStyle={{
          background: colors.surface,
          border: `1px solid ${colors.grid}`,
          borderRadius: 8,
          fontSize: 12,
        }}
        labelStyle={{ color: colors.axis }}
        cursor={{ stroke: colors.grid }}
      />
    ),
  };
}

/** Minor units → major units for plotting (axis and tooltip format them back to money). */
const toPoints = (series: MonthlyAmount[], minorDigits: number) =>
  series.map((point) => ({
    label: shortMonth(point.month),
    value: point.amountMinor / 10 ** minorDigits,
  }));

export function MonthlyLineChart({
  series,
  currency,
  minorDigits,
  colors,
  dashed = false,
}: {
  series: MonthlyAmount[];
  currency: string;
  minorDigits: number;
  colors: ChartColors;
  /** Dashed = projected values, solid = recorded ones. */
  dashed?: boolean;
}) {
  const axes = axesFor(colors, currency, minorDigits);
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={toPoints(series, minorDigits)} accessibilityLayer={false}>
        {axes.grid}
        {axes.xAxis}
        {axes.yAxis}
        {axes.tooltip}
        <Line
          type="monotone"
          dataKey="value"
          name="Amount"
          stroke={colors.series}
          strokeWidth={2}
          strokeDasharray={dashed ? "6 4" : undefined}
          dot={{ r: 4, fill: colors.series, stroke: colors.surface, strokeWidth: 2 }}
          activeDot={{ r: 5 }}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

const KIND_LABEL = { actual: "Paid", current: "This month", projected: "Scheduled" } as const;

export function ExpenditureBarChart({
  months,
  currency,
  minorDigits,
  colors,
}: {
  months: ExpenditureMonth[];
  currency: string;
  minorDigits: number;
  colors: ChartColors;
}) {
  const axes = axesFor(colors, currency, minorDigits);
  const fill = { actual: colors.series, current: colors.current, projected: colors.projected };
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={months.map((m) => ({
          label: formatMonth(m.month).slice(0, 3),
          value: m.amountMinor / 10 ** minorDigits,
          kind: m.kind,
        }))}
        accessibilityLayer={false}
      >
        {axes.grid}
        {axes.xAxis}
        {axes.yAxis}
        {axes.tooltip}
        <Bar
          dataKey="value"
          name="Amount"
          maxBarSize={24}
          radius={[4, 4, 0, 0]}
          isAnimationActive={false}
        >
          {months.map((m) => (
            <Cell key={m.month} fill={fill[m.kind]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ExpenditureLegend({ colors }: { colors: ChartColors }) {
  const items = [
    ["Paid", colors.series],
    ["This month", colors.current],
    ["Scheduled", colors.projected],
  ] as const;
  return (
    <ul className="mt-3 flex flex-wrap gap-4 text-sm text-ink-muted">
      {items.map(([label, color]) => (
        <li key={label} className="flex items-center gap-1.5">
          <span aria-hidden="true" className="size-2.5 rounded-sm" style={{ background: color }} />
          {label}
        </li>
      ))}
    </ul>
  );
}

export const expenditureNote = (kind: ExpenditureMonth["kind"]) => KIND_LABEL[kind];

/** Donut of monthly-equivalent spend per category, with a direct-labelled legend. */
export function CategoryDonut({
  categories,
  currency,
  minorDigits,
  colors,
}: {
  categories: CategorySpend[];
  currency: string;
  minorDigits: number;
  colors: ChartColors;
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart accessibilityLayer={false}>
        <Pie
          data={categories.map((c) => ({
            name: categoryLabel(c.category),
            category: c.category,
            value: c.monthlyMinor / 10 ** minorDigits,
          }))}
          dataKey="value"
          nameKey="name"
          // Pie is focusable by default even with accessibilityLayer off; the data table is
          // the accessible view, so keep the hidden chart out of the tab order.
          rootTabIndex={-1}
          innerRadius="55%"
          outerRadius="85%"
          // A 2px surface-coloured gap separates adjacent slices.
          stroke={colors.surface}
          strokeWidth={2}
          isAnimationActive={false}
        >
          {categories.map((c) => (
            <Cell key={c.category} fill={categoryColor(colors, c.category)} />
          ))}
        </Pie>
        <Tooltip
          formatter={(value) =>
            formatMoney(Math.round(Number(value) * 10 ** minorDigits), currency)
          }
          contentStyle={{
            background: colors.surface,
            border: `1px solid ${colors.grid}`,
            borderRadius: 8,
            fontSize: 12,
          }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}

/** Legend with every value as text (identity never relies on colour alone). */
export function CategoryLegend({
  categories,
  currency,
  colors,
}: {
  categories: CategorySpend[];
  currency: string;
  colors: ChartColors;
}) {
  const total = categories.reduce((sum, c) => sum + c.monthlyMinor, 0);
  return (
    <ul className="mt-3 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
      {categories.map((c) => (
        <li key={c.category} className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-2">
            <span
              aria-hidden="true"
              className="size-2.5 rounded-full"
              style={{ background: categoryColor(colors, c.category) }}
            />
            {categoryLabel(c.category)}
          </span>
          <span className="tabular-nums">
            {formatMoney(c.monthlyMinor, currency)}
            <span className="text-ink-subtle">
              {" "}
              · {total === 0 ? 0 : Math.round((100 * c.monthlyMinor) / total)}%
            </span>
          </span>
        </li>
      ))}
    </ul>
  );
}
