import { screen, within } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import type { Payment } from "../api/payments";
import { mockApi, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { PaymentHistory } from "./PaymentHistory";

const subscriptionId = crypto.randomUUID();
const payment = (paidOn: string, amountMinor = 1599): Payment => ({
  id: crypto.randomUUID(),
  subscriptionId,
  paidOn,
  amountMinor,
  currency: "USD",
  createdAt: "2026-10-01T00:00:00.000Z",
  updatedAt: "2026-10-01T00:00:00.000Z",
});

describe("PaymentHistory", () => {
  it("lists payments newest first and corrects an amount", async () => {
    const latest = payment("2026-10-15");
    let items = [latest, payment("2026-09-15")];
    let patchBody: unknown;
    mockApi(
      route("get", "/subscriptions/{id}/payments").reply(() => ({ status: 200, body: { items } })),
      route("patch", "/payments/{id}").reply(async ({ request }) => {
        patchBody = await request.json();
        items = items.map((p) => (p.id === latest.id ? { ...p, amountMinor: 1799 } : p));
        return { status: 200, body: { ...latest, amountMinor: 1799 } };
      }),
    );
    const user = userEvent.setup();
    renderWithQueryClient(<PaymentHistory subscriptionId={subscriptionId} />);

    const table = await screen.findByRole("table");
    const [, first, second] = within(table).getAllByRole("row");
    expect(first).toHaveTextContent("Oct 15, 2026$15.99");
    expect(second).toHaveTextContent("Sep 15, 2026");

    await user.click(screen.getByRole("button", { name: "Edit payment of Oct 15, 2026" }));
    const amount = screen.getByLabelText("Payment amount");
    await user.clear(amount);
    await user.type(amount, "17.99");
    await user.click(screen.getByRole("button", { name: "Save" }));

    expect(await screen.findByText("$17.99")).toBeInTheDocument();
    expect(patchBody).toEqual({ amountMinor: 1799, paidOn: "2026-10-15" });
  });

  it("explains a duplicate date instead of failing silently", async () => {
    mockApi(
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 200,
        body: { items: [payment("2026-10-15"), payment("2026-09-15")] },
      })),
      route("patch", "/payments/{id}").reply(() => ({
        status: 409,
        body: {
          error: "DuplicatePaymentDate",
          message: "This subscription already has a payment on that date",
        },
      })),
    );
    const user = userEvent.setup();
    renderWithQueryClient(<PaymentHistory subscriptionId={subscriptionId} />);

    await user.click(await screen.findByRole("button", { name: "Edit payment of Oct 15, 2026" }));
    await user.click(screen.getByRole("button", { name: "Save" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "already has a payment on that date",
    );
  });

  it("validates the amount before calling the API", async () => {
    mockApi(
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 200,
        body: { items: [payment("2026-10-15")] },
      })),
    );
    const user = userEvent.setup();
    renderWithQueryClient(<PaymentHistory subscriptionId={subscriptionId} />);

    await user.click(await screen.findByRole("button", { name: "Edit payment of Oct 15, 2026" }));
    const amount = screen.getByLabelText("Payment amount");
    await user.clear(amount);
    await user.type(amount, "abc");
    await user.click(screen.getByRole("button", { name: "Save" }));

    expect(screen.getByRole("alert")).toHaveTextContent("Enter an amount like 9.99");
  });

  it("deletes a payment after confirmation", async () => {
    const skipped = payment("2026-09-15");
    let items = [payment("2026-10-15"), skipped];
    mockApi(
      route("get", "/subscriptions/{id}/payments").reply(() => ({ status: 200, body: { items } })),
      route("delete", "/payments/{id}").reply(({ params }) => {
        items = items.filter((p) => p.id !== params.id);
        return { status: 204 };
      }),
    );
    const user = userEvent.setup();
    renderWithQueryClient(<PaymentHistory subscriptionId={subscriptionId} />);

    await user.click(await screen.findByRole("button", { name: "Delete payment of Sep 15, 2026" }));
    const dialog = screen.getByRole("alertdialog", { name: "Delete the payment of Sep 15, 2026?" });
    await user.click(within(dialog).getByRole("button", { name: "Delete" }));

    await expect.poll(() => screen.queryAllByRole("row").length).toBe(2); // header + 1 payment
    expect(screen.queryByText("Sep 15, 2026")).not.toBeInTheDocument();
  });
});
