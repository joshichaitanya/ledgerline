import { buildApp } from "./app";
import { loadConfig } from "./config";
import { createDatabase } from "./db/client";

const config = loadConfig();
const database = createDatabase(config.DATABASE_URL);
const app = await buildApp({ database, logger: { level: config.LOG_LEVEL } });

app.addHook("onClose", () => database.close());

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.once(signal, async () => {
    app.log.info({ signal }, "shutting down");
    await app.close();
    process.exit(0);
  });
}

await app.listen({ host: config.HOST, port: config.PORT });
