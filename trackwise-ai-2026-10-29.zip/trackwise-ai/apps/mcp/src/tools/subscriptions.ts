import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import {
  BillingCycleSchema,
  CategorySchema,
  CURRENCY_CODES,
  formatMoney,
  parseMoney,
} from "@subtrack/contracts";
import { z } from "zod";
import { CREATES, READ_ONLY } from "../annotations";
import { fromApi, safely, ToolError } from "../api/call";
import { api } from "../api/client";
import { presentSubscription } from "../present";

// Must match presentSubscription() exactly: the SDK validates every structuredContent against
// the declared output schema and rejects extra properties.
const subscriptionSummary = z.object({
  id: z.string(),
  name: z.string(),
  price: z.string().describe("Formatted price per billing cycle, e.g. '$15.99'"),
  billingCycle: z.string(),
  nextRenewalDate: z.string().describe("ISO date (YYYY-MM-DD)"),
  category: z.string(),
  // Optional rather than nullable: `null` is published as `type: ["string","null"]`, which
  // some AI providers' tool formats reject. Absent = no notes, which reads fine for a model.
  notes: z.string().optional().describe("Only present when the user added notes"),
});

export function registerSubscriptionTools(server: McpServer) {
  server.registerTool(
    "list_subscriptions",
    {
      title: "List subscriptions",
      annotations: READ_ONLY,
      // Written for an AI reader: what it returns, in what order, what units.
      description:
        "List the user's subscriptions, soonest renewal first. Prices are per billing cycle. " +
        "Optionally filter by category. Use the returned ids with get_subscription.",
      // z.enum(…options) rather than CategorySchema itself: CategorySchema carries an OpenAPI
      // id, which would turn into a `$ref` the tool schema can't resolve. A fresh enum inlines
      // the actual values, so clients (and later the AI) see all 8 categories.
      inputSchema: {
        category: z
          .enum(CategorySchema.options)
          .optional()
          .describe("Only return subscriptions in this category"),
      },
      outputSchema: { subscriptions: z.array(subscriptionSummary) },
    },
    safely(async ({ category }) => {
      const data = await fromApi(api.GET("/subscriptions"));
      const subscriptions = data.items
        .filter((s) => !category || s.category === category)
        .map(presentSubscription);

      // Two forms of the same result: text to read, structured data to process.
      const text =
        subscriptions.length === 0
          ? "No subscriptions found."
          : subscriptions
              .map(
                (s) =>
                  `${s.name} (id ${s.id}): ${s.price} ${s.billingCycle}, renews ${s.nextRenewalDate} (${s.category})`,
              )
              .join("\n");
      return { content: [{ type: "text", text }], structuredContent: { subscriptions } };
    }),
  );

  server.registerTool(
    "get_subscription",
    {
      title: "Get subscription details",
      annotations: READ_ONLY,
      description:
        "Get one subscription's full details and its recent payments (newest first). " +
        "Needs the subscription id — call list_subscriptions first to find it.",
      inputSchema: {
        id: z.uuid().describe("Subscription id, as returned by list_subscriptions"),
        paymentLimit: z
          .number()
          .int()
          .min(0)
          .max(50)
          .default(12)
          .describe("How many recent payments to include (default 12)"),
      },
      outputSchema: {
        subscription: subscriptionSummary,
        recentPayments: z.array(z.object({ paidOn: z.string(), amount: z.string() })),
        totalPaymentsRecorded: z.number(),
      },
    },
    safely(async ({ id, paymentLimit }) => {
      const notFound = `No subscription has id ${id}. Use list_subscriptions to find valid ids.`;
      const s = await fromApi(api.GET("/subscriptions/{id}", { params: { path: { id } } }), {
        notFound,
      });
      const payments = await fromApi(
        api.GET("/subscriptions/{id}/payments", { params: { path: { id } } }),
        { notFound },
      );

      const subscription = presentSubscription(s);
      const recentPayments = payments.items.slice(0, paymentLimit).map((p) => ({
        paidOn: p.paidOn,
        amount: formatMoney(p.amountMinor, p.currency),
      }));

      const lines = [
        `${s.name}: ${subscription.price} ${s.billingCycle} (${s.category}), next renewal ${s.nextRenewalDate}.`,
        ...(s.notes ? [`Notes: ${s.notes}`] : []),
        payments.items.length === 0
          ? "No payments recorded yet."
          : `Recent payments (${recentPayments.length} of ${payments.items.length}): ` +
            recentPayments.map((p) => `${p.paidOn} ${p.amount}`).join(", "),
      ];
      return {
        content: [{ type: "text", text: lines.join("\n") }],
        structuredContent: {
          subscription,
          recentPayments,
          totalPaymentsRecorded: payments.items.length,
        },
      };
    }),
  );

  server.registerTool(
    "add_subscription",
    {
      title: "Add a subscription",
      annotations: CREATES,
      description:
        "Add a new subscription for the user. Only call this when the user asked to add one, " +
        "and confirm the details with them if anything (price, currency, cycle, date) is unclear. " +
        "Calling it twice adds it twice — check list_subscriptions first if it might exist already.",
      // Every field mirrors the shared contract (same rules as the web form and the API), but
      // as plain values a model can't get wrong: a decimal price, not minor units.
      inputSchema: {
        name: z.string().max(100).describe("Service name, e.g. 'YouTube Premium'"),
        // A number OR a string: models (and clients) often send prices as numbers. Either way it
        // is parsed as text by parseMoney, so 19.99 never becomes 1998.9999 minor units.
        amount: z
          .union([z.number().positive(), z.string()])
          .describe("Price per billing cycle, e.g. 149 or 15.99 — no currency symbol"),
        currency: z.enum(CURRENCY_CODES).describe("ISO 4217 code of the price, e.g. 'INR', 'USD'"),
        billingCycle: z.enum(BillingCycleSchema.options),
        category: z.enum(CategorySchema.options),
        nextRenewalDate: z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD")
          .describe("Date of the next charge, YYYY-MM-DD"),
        notes: z.string().max(500).optional().describe("Optional, e.g. 'Family plan'"),
      },
      outputSchema: { subscription: subscriptionSummary },
    },
    safely(async ({ amount, currency, ...fields }) => {
      // Same parser as the web form: string arithmetic, the currency's own decimal places.
      const price = parseMoney(String(amount), currency);
      if (!price.ok) throw new ToolError(`amount: ${price.error}. Fix the amount and retry.`);

      const created = await fromApi(
        api.POST("/subscriptions", {
          body: { ...fields, currency, amountMinor: price.amountMinor },
        }),
      );
      const subscription = presentSubscription(created);
      return {
        content: [
          {
            type: "text",
            text:
              `Added ${subscription.name}: ${subscription.price} ${subscription.billingCycle} ` +
              `(${subscription.category}), next renewal ${subscription.nextRenewalDate}. id ${subscription.id}`,
          },
        ],
        structuredContent: { subscription },
      };
    }),
  );
}
