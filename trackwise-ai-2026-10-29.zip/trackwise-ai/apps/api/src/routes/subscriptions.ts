import {
  CreateSubscriptionRequestSchema,
  ErrorResponseSchema,
  SubscriptionIdParamsSchema,
  SubscriptionListResponseSchema,
  SubscriptionSchema,
  toIsoDate,
  UpdateSubscriptionRequestSchema,
} from "@subtrack/contracts";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { z } from "zod";
import type { Database } from "../db/client";
import { processDueRenewals } from "../subscriptions/renewals";
import {
  createSubscription,
  deleteSubscription,
  getSubscription,
  listSubscriptions,
  updateSubscription,
} from "../subscriptions/repository";

const notFound = { error: "NotFound", message: "Subscription not found" } as const;
const notFoundResponse = ErrorResponseSchema.describe("No subscription has this id");

export const subscriptionRoutes: FastifyPluginAsyncZod<{
  database: Database;
  now: () => Date;
}> = async (app, { database, now }) => {
  // Renewal dates shown to clients must be current: record passed renewals first.
  const processRenewals = () => processDueRenewals(database, toIsoDate(now()));

  app.get(
    "/subscriptions",
    {
      schema: {
        operationId: "listSubscriptions",
        tags: ["subscriptions"],
        summary: "List subscriptions, soonest renewal first",
        response: {
          200: SubscriptionListResponseSchema.describe("All subscriptions, soonest renewal first"),
        },
      },
    },
    async () => {
      await processRenewals();
      return { items: await listSubscriptions(database) };
    },
  );

  app.post(
    "/subscriptions",
    {
      schema: {
        operationId: "createSubscription",
        tags: ["subscriptions"],
        summary: "Create a subscription",
        body: CreateSubscriptionRequestSchema,
        response: {
          201: SubscriptionSchema.describe("The created subscription"),
          400: ErrorResponseSchema.describe("Invalid request body"),
        },
      },
    },
    async (request, reply) =>
      reply.code(201).send(await createSubscription(database, request.body)),
  );

  app.get(
    "/subscriptions/:id",
    {
      schema: {
        operationId: "getSubscription",
        tags: ["subscriptions"],
        summary: "Get one subscription",
        params: SubscriptionIdParamsSchema,
        response: {
          200: SubscriptionSchema.describe("The subscription"),
          400: ErrorResponseSchema.describe("Malformed id"),
          404: notFoundResponse,
        },
      },
    },
    async (request, reply) => {
      await processRenewals();
      const subscription = await getSubscription(database, request.params.id);
      return subscription ? subscription : reply.code(404).send(notFound);
    },
  );

  app.patch(
    "/subscriptions/:id",
    {
      schema: {
        operationId: "updateSubscription",
        tags: ["subscriptions"],
        summary: "Update some or all fields of a subscription",
        params: SubscriptionIdParamsSchema,
        body: UpdateSubscriptionRequestSchema,
        response: {
          200: SubscriptionSchema.describe("The updated subscription"),
          400: ErrorResponseSchema.describe("Malformed id or invalid request body"),
          404: notFoundResponse,
        },
      },
    },
    async (request, reply) => {
      const subscription = await updateSubscription(database, request.params.id, request.body);
      return subscription ? subscription : reply.code(404).send(notFound);
    },
  );

  app.delete(
    "/subscriptions/:id",
    {
      schema: {
        operationId: "deleteSubscription",
        tags: ["subscriptions"],
        summary: "Delete a subscription",
        params: SubscriptionIdParamsSchema,
        response: {
          204: z.null().describe("Deleted (no content)"),
          400: ErrorResponseSchema.describe("Malformed id"),
          404: notFoundResponse,
        },
      },
    },
    async (request, reply) => {
      const deleted = await deleteSubscription(database, request.params.id);
      return deleted ? reply.code(204).send(null) : reply.code(404).send(notFound);
    },
  );
};
