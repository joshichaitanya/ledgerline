import { describe, expect, it } from "vitest";
import { connectClient } from "./test/connect";

/** Every `$ref` and every array-valued `type` in a JSON Schema, with its path. */
function portabilityProblems(schema: unknown, path: string): string[] {
  if (schema === null || typeof schema !== "object") return [];
  const problems: string[] = [];
  for (const [key, value] of Object.entries(schema)) {
    if (key === "$ref") problems.push(`${path}: unresolved $ref ${String(value)}`);
    if (key === "type" && Array.isArray(value)) problems.push(`${path}: type array ${value}`);
    problems.push(...portabilityProblems(value, `${path}.${key}`));
  }
  return problems;
}

describe("what clients (and AIs) see", () => {
  it("advertises every tool with a real description and annotations", async () => {
    const client = await connectClient();
    const { tools } = await client.listTools();

    expect(tools.map((tool) => tool.name).sort()).toEqual([
      "add_subscription",
      "get_spending_summary",
      "get_subscription",
      "get_upcoming_renewals",
      "list_subscriptions",
      "ping",
    ]);
    for (const tool of tools) {
      expect(tool.description?.length, tool.name).toBeGreaterThan(30);
      expect(tool.annotations, tool.name).toBeDefined();
    }
  });

  it("marks lookups read-only and add_subscription as a non-destructive write", async () => {
    const client = await connectClient();
    const { tools } = await client.listTools();
    const byName = Object.fromEntries(tools.map((tool) => [tool.name, tool.annotations]));

    for (const name of [
      "ping",
      "list_subscriptions",
      "get_subscription",
      "get_spending_summary",
      "get_upcoming_renewals",
    ]) {
      expect(byName[name]?.readOnlyHint, name).toBe(true);
    }
    expect(byName.add_subscription).toMatchObject({
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
    });
  });

  // Regressions: CategorySchema once published as an unresolvable $ref, and a nullable field
  // as `type: ["string","null"]`, which some AI providers' tool formats reject.
  it("publishes portable JSON Schemas: no $refs, no type arrays", async () => {
    const client = await connectClient();
    const { tools } = await client.listTools();

    const problems = tools.flatMap((tool) => [
      ...portabilityProblems(tool.inputSchema, `${tool.name}.input`),
      ...portabilityProblems(tool.outputSchema, `${tool.name}.output`),
    ]);
    expect(problems).toEqual([]);
  });

  it("inlines the category values so a model can see every option", async () => {
    const client = await connectClient();
    const { tools } = await client.listTools();
    const list = tools.find((tool) => tool.name === "list_subscriptions");

    expect(list?.inputSchema.properties?.category).toMatchObject({
      enum: ["streaming", "music", "software", "cloud", "news", "fitness", "gaming", "other"],
    });
  });
});
