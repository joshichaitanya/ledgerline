-- Runs once, when the volume is first created.
-- "subtrack" (dev) is created by POSTGRES_DB; these isolate automated tests from dev data.
CREATE DATABASE subtrack_test;
CREATE DATABASE subtrack_e2e;
CREATE DATABASE subtrack_fuzz;
