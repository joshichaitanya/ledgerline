import { expect, test } from "./support/fixtures";

// The seed records a year of payment history, so every chart has real data.
test.describe("Dashboard charts", () => {
  test("shows KPIs, four charts and their data tables", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("region", { name: "Monthly spend" })).toContainText("$124.34");
    await expect(page.getByRole("region", { name: "Year-to-date" })).toContainText("$");

    for (const chart of [
      "Spending trends",
      "Category breakdown",
      "6-month forecast",
      "Monthly expenditure",
    ]) {
      const card = page.getByRole("region", { name: chart });
      await expect(card.locator("svg.recharts-surface")).toBeVisible();
    }

    const trends = page.getByRole("region", { name: "Spending trends" });
    await trends.getByText("Show data").click();
    await expect(trends.getByRole("row")).toHaveCount(13); // header + 12 months

    const breakdown = page.getByRole("region", { name: "Category breakdown" });
    await expect(breakdown).toContainText("Streaming");
    await expect(breakdown).toContainText("%");
  });

  test("a new subscription appears in the forecast", async ({ page, arrange }) => {
    await page.goto("/");
    const forecast = page.getByRole("region", { name: "6-month forecast" });
    await forecast.getByText("Show data").click();
    const firstMonth = forecast.getByRole("row").nth(1);
    const before = await firstMonth.locator("td").textContent();

    // $100/month renewing on the 1st of next month.
    const nextMonthStart = new Date();
    nextMonthStart.setUTCMonth(nextMonthStart.getUTCMonth() + 1, 1);
    await arrange.subscription({
      amountMinor: 10_000,
      nextRenewalDate: nextMonthStart.toISOString().slice(0, 10),
    });
    await page.reload();
    await page.getByRole("region", { name: "6-month forecast" }).getByText("Show data").click();

    const after = await page
      .getByRole("region", { name: "6-month forecast" })
      .getByRole("row")
      .nth(1)
      .locator("td")
      .textContent();
    const toNumber = (text: string | null) => Number((text ?? "").replace(/[^0-9.]/g, ""));
    expect(toNumber(after) - toNumber(before)).toBeCloseTo(100, 2);
  });
});

test("the old /analytics address redirects to the dashboard", async ({ page }) => {
  await page.goto("/analytics");

  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
});
