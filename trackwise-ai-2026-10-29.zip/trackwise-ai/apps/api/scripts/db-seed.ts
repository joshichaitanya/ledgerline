import { loadConfig } from "../src/config";
import { createDatabase } from "../src/db/client";
import { seed } from "../src/db/seed";

const database = createDatabase(loadConfig().DATABASE_URL);
try {
  console.log(await seed(database, { reset: process.argv.includes("--reset") }));
} finally {
  await database.close();
}
