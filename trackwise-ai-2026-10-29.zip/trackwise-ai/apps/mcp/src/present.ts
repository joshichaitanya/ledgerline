import { formatMoney } from "@subtrack/contracts";
import type { components } from "./api/schema.gen";

type Subscription = components["schemas"]["Subscription"];

/**
 * How a subscription is shown to a model: formatted price ("$15.99", never 1599 minor units),
 * ISO dates, and the id so the model can chain calls. Shared by tools and resources so both
 * describe a subscription identically.
 */
export function presentSubscription(s: Subscription) {
  return {
    id: s.id,
    name: s.name,
    price: formatMoney(s.amountMinor, s.currency),
    billingCycle: s.billingCycle,
    nextRenewalDate: s.nextRenewalDate,
    category: s.category,
    ...(s.notes ? { notes: s.notes } : {}),
  };
}
