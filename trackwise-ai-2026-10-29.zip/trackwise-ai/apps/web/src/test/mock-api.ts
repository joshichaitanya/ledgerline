import { vi } from "vitest";
import type { paths } from "../api/schema.gen";

// Typed fetch stubs. Each route's replies are checked against the generated OpenAPI
// schema, so a test fixture that drifts from the API contract fails to compile.

type Path = keyof paths;
type Method<P extends Path> = {
  [M in keyof paths[P]]: paths[P][M] extends { responses: unknown } ? M : never;
}[keyof paths[P]] &
  string;
type Responses<P extends Path, M extends Method<P>> = paths[P][M] extends { responses: infer R }
  ? R
  : never;
type JsonBody<R> = R extends { content: { "application/json": infer Body } } ? Body : undefined;

/** One of the operation's documented responses: `{ status, body }` with a matching body type. */
export type Reply<P extends Path, M extends Method<P>> = {
  [S in keyof Responses<P, M>]: undefined extends JsonBody<Responses<P, M>[S]>
    ? { status: S; body?: undefined }
    : { status: S; body: JsonBody<Responses<P, M>[S]> };
}[keyof Responses<P, M>];

interface RouteContext {
  /** Values of `{placeholders}` in the path template. */
  params: Record<string, string>;
  request: Request;
}

export interface MockRoute {
  method: string;
  matches: (pathname: string) => Record<string, string> | undefined;
  handle: (context: RouteContext) => Promise<Response>;
  label: string;
}

/**
 * Declares a mocked operation:
 * `route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body }))`.
 * Two steps on purpose: `route()` fixes the operation, so `reply()` checks the handler
 * against concrete response types (no literal widening). Throw to simulate a network failure.
 */
export function route<P extends Path, M extends Method<P>>(method: M, path: P) {
  const names: string[] = [];
  const pattern = new RegExp(
    `^${String(path).replace(/\{(\w+)\}/g, (_match, name: string) => {
      names.push(name);
      return "([^/]+)";
    })}$`,
  );
  return {
    reply(handler: (context: RouteContext) => Reply<P, M> | Promise<Reply<P, M>>): MockRoute {
      return {
        method: method.toUpperCase(),
        label: `${method.toUpperCase()} ${String(path)}`,
        matches: (pathname) => {
          const match = pattern.exec(pathname);
          return match
            ? Object.fromEntries(names.map((name, index) => [name, match[index + 1] ?? ""]))
            : undefined;
        },
        handle: async (context) => {
          const reply = (await handler(context)) as { status: number; body?: unknown };
          return reply.body === undefined
            ? new Response(null, { status: reply.status })
            : Response.json(reply.body, { status: reply.status });
        },
      };
    },
  };
}

const API_PREFIX = "/api";

/** Stubs fetch with the given routes. Unmatched requests fail loudly. Returns the mock. */
export function mockApi(...routes: MockRoute[]) {
  const fetchMock = vi.fn(async (request: Request) => {
    const pathname = new URL(request.url).pathname.replace(API_PREFIX, "");
    for (const candidate of routes) {
      const params = candidate.method === request.method && candidate.matches(pathname);
      if (params) return candidate.handle({ params, request });
    }
    throw new Error(
      `Unexpected request: ${request.method} ${pathname} (mocked: ${routes.map((r) => r.label).join(", ")})`,
    );
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

/** The requests made so far, as "METHOD /path" strings (without the /api prefix). */
export function requestsOf(fetchMock: ReturnType<typeof mockApi>): string[] {
  return fetchMock.mock.calls.map(
    ([request]) => `${request.method} ${new URL(request.url).pathname.replace(API_PREFIX, "")}`,
  );
}

/** Simulates the network being down for any request. */
export function mockNetworkError() {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => {
      throw new TypeError("Failed to fetch");
    }),
  );
}
