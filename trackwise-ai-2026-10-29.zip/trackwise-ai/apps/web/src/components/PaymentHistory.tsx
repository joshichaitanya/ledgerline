import { formatMoney, parseMoney, toMajorString } from "@subtrack/contracts";
import { useCallback, useId, useState } from "react";
import { type Payment, useDeletePayment, usePayments, useUpdatePayment } from "../api/payments";
import { formatDate } from "../lib/format";
import { ConfirmDialog } from "./ConfirmDialog";

const input =
  "rounded-md border border-line-strong bg-surface px-2 py-1 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent";

/** Payments recorded automatically as renewals pass; each can be corrected or removed. */
export function PaymentHistory({ subscriptionId }: { subscriptionId: string }) {
  const payments = usePayments(subscriptionId);
  const [editing, setEditing] = useState<string | null>(null);
  const [toDelete, setToDelete] = useState<Payment | null>(null);
  const remove = useDeletePayment(subscriptionId);
  const closeDialog = useCallback(() => {
    setToDelete(null);
    remove.reset();
  }, [remove.reset]);

  return (
    <section
      aria-labelledby="payments-heading"
      className="rounded-xl border border-line bg-surface p-6"
    >
      <h3 id="payments-heading" className="text-lg font-semibold">
        Payment history
      </h3>
      <p className="mb-4 text-sm text-ink-subtle">
        Recorded automatically when a renewal date passes. Correct an amount if the price changed,
        or delete a payment you skipped.
      </p>
      {payments.isPending ? (
        <p role="status" className="text-ink-subtle">
          Loading payments…
        </p>
      ) : payments.isError ? (
        <p role="alert" className="text-danger-ink">
          Couldn't load payments.
        </p>
      ) : payments.data.length === 0 ? (
        <p className="text-sm text-ink-muted">No payments yet. One is recorded at each renewal.</p>
      ) : (
        <table className="w-full text-left text-sm">
          <caption className="sr-only">Payments, newest first</caption>
          <thead className="border-b border-line text-xs uppercase text-ink-muted">
            <tr>
              <th scope="col" className="py-2 font-medium">
                Date
              </th>
              <th scope="col" className="py-2 text-right font-medium">
                Amount
              </th>
              <th scope="col" className="py-2">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {payments.data.map((payment) =>
              editing === payment.id ? (
                <EditPaymentRow
                  key={payment.id}
                  payment={payment}
                  subscriptionId={subscriptionId}
                  onDone={() => setEditing(null)}
                />
              ) : (
                <tr key={payment.id}>
                  <td className="py-2 tabular-nums">{formatDate(payment.paidOn)}</td>
                  <td className="py-2 text-right tabular-nums">
                    {formatMoney(payment.amountMinor, payment.currency)}
                  </td>
                  <td className="whitespace-nowrap py-2 text-right">
                    <button
                      type="button"
                      onClick={() => setEditing(payment.id)}
                      aria-label={`Edit payment of ${formatDate(payment.paidOn)}`}
                      className="rounded-md px-2 py-1 font-medium text-accent-ink hover:bg-accent-soft"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => setToDelete(payment)}
                      aria-label={`Delete payment of ${formatDate(payment.paidOn)}`}
                      className="ml-1 rounded-md px-2 py-1 font-medium text-danger-ink hover:bg-danger-soft"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ),
            )}
          </tbody>
        </table>
      )}
      {toDelete && (
        <ConfirmDialog
          title={`Delete the payment of ${formatDate(toDelete.paidOn)}?`}
          description="It won't be recorded again. Use this for a renewal you skipped."
          confirmLabel="Delete"
          onConfirm={() => remove.mutate(toDelete.id, { onSuccess: closeDialog })}
          onCancel={closeDialog}
          isPending={remove.isPending}
          error={remove.error}
        />
      )}
    </section>
  );
}

function EditPaymentRow({
  payment,
  subscriptionId,
  onDone,
}: {
  payment: Payment;
  subscriptionId: string;
  onDone: () => void;
}) {
  const id = useId();
  const [amount, setAmount] = useState(toMajorString(payment.amountMinor, payment.currency));
  const [paidOn, setPaidOn] = useState(payment.paidOn);
  const [error, setError] = useState<string | null>(null);
  const update = useUpdatePayment(subscriptionId);

  return (
    <tr>
      <td colSpan={3} className="py-2">
        <form
          className="flex flex-wrap items-center gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            const parsed = parseMoney(amount, payment.currency);
            if (!parsed.ok) return setError(parsed.error);
            setError(null);
            update.mutate(
              { id: payment.id, patch: { amountMinor: parsed.amountMinor, paidOn } },
              { onSuccess: onDone, onError: (failure) => setError(failure.message) },
            );
          }}
        >
          <label htmlFor={`${id}-date`} className="sr-only">
            Payment date
          </label>
          <input
            id={`${id}-date`}
            type="date"
            value={paidOn}
            onChange={(event) => setPaidOn(event.target.value)}
            className={input}
          />
          <label htmlFor={`${id}-amount`} className="sr-only">
            Payment amount
          </label>
          <input
            id={`${id}-amount`}
            type="text"
            inputMode="decimal"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
            aria-invalid={Boolean(error)}
            aria-describedby={error ? `${id}-error` : undefined}
            className={`${input} w-28 text-right`}
          />
          <span className="text-sm text-ink-subtle">{payment.currency}</span>
          <button
            type="submit"
            disabled={update.isPending}
            className="rounded-md bg-accent px-3 py-1 text-sm font-medium text-white hover:bg-accent-hover disabled:opacity-50"
          >
            Save
          </button>
          <button
            type="button"
            onClick={onDone}
            className="text-sm font-medium text-ink-muted hover:text-ink"
          >
            Cancel
          </button>
          {error && (
            <p id={`${id}-error`} role="alert" className="w-full text-sm text-danger-ink">
              {error}
            </p>
          )}
        </form>
      </td>
    </tr>
  );
}
