#!/usr/bin/env bash
# Contract fuzzing: Schemathesis generates many requests from apps/api/openapi.json (valid and
# invalid) and checks the real API's responses: no 5xx, bodies match their schemas, and every
# status code returned is documented. Runs against a dedicated database, never dev or E2E data.
#
#   pnpm contract:fuzz                # default
#   FUZZ_MAX_EXAMPLES=500 pnpm contract:fuzz
set -euo pipefail

SCHEMATHESIS_IMAGE="schemathesis/schemathesis:4.32.7"
PORT="${FUZZ_PORT:-3200}"
DB_NAME="subtrack_fuzz"
DATABASE_URL="postgres://subtrack:subtrack@localhost:5433/${DB_NAME}"
root="$(cd "$(dirname "$0")/.." && pwd)"
report_dir="$root/reports/schemathesis"

cd "$root"
mkdir -p "$report_dir"

# 1. A brand-new database per run (fuzzing fills it with junk), migrated and seeded.
docker compose exec -T postgres dropdb -U subtrack --if-exists --force "${DB_NAME}"
docker compose exec -T postgres createdb -U subtrack "${DB_NAME}"
DATABASE_URL="$DATABASE_URL" pnpm --silent --filter @subtrack/api db:migrate
DATABASE_URL="$DATABASE_URL" pnpm --silent --filter @subtrack/api db:seed --reset

# 2. Start the API (one process, so it can be stopped reliably) and wait until healthy.
# Bound to 0.0.0.0 so the Schemathesis container can reach it.
(cd apps/api && HOST=0.0.0.0 PORT="$PORT" LOG_LEVEL=warn DATABASE_URL="$DATABASE_URL" \
  exec node --import tsx src/server.ts) &
api_pid=$!
trap 'kill "$api_pid" 2>/dev/null || true' EXIT
for _ in $(seq 1 60); do
  curl -sf "http://localhost:${PORT}/health" >/dev/null && break
  sleep 0.5
done

# 3. Fuzz. Docker Desktop (macOS) reaches the host via host.docker.internal; Linux CI uses host networking.
if [ "$(uname)" = "Linux" ]; then
  network=(--network host); base_url="http://localhost:${PORT}"
else
  network=(); base_url="http://host.docker.internal:${PORT}"
fi

# ${a[@]+...} expands safely when empty under `set -u` (macOS ships bash 3.2).
docker run --rm ${network[@]+"${network[@]}"} \
  -v "$root/apps/api/openapi.json:/specs/openapi.json:ro" \
  -v "$report_dir:/reports" \
  "$SCHEMATHESIS_IMAGE" run /specs/openapi.json \
  --url "$base_url" \
  --checks all \
  --max-examples "${FUZZ_MAX_EXAMPLES:-50}" \
  --report junit --report-junit-path /reports/junit.xml
