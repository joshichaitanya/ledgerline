import { type QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "./client";
import type { components } from "./schema.gen";
import { ApiError } from "./subscriptions";

export type Currency = components["schemas"]["Currency"];
export type ExchangeRate = components["schemas"]["ExchangeRate"];

const keys = { settings: ["settings"] as const, rates: ["exchange-rates"] as const };

/** Settings and rates change every converted total, so refresh the dashboard too. */
function invalidateAfterWrite(queryClient: QueryClient) {
  return Promise.all([
    queryClient.invalidateQueries({ queryKey: keys.settings }),
    queryClient.invalidateQueries({ queryKey: keys.rates }),
    queryClient.invalidateQueries({ queryKey: ["summary"] }),
    queryClient.invalidateQueries({ queryKey: ["analytics"] }),
  ]);
}

export function useSettings() {
  return useQuery({
    queryKey: keys.settings,
    queryFn: async () => {
      const { data, error, response } = await api.GET("/settings");
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
  });
}

export function useExchangeRates() {
  return useQuery({
    queryKey: keys.rates,
    queryFn: async () => {
      const { data, error, response } = await api.GET("/exchange-rates");
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
  });
}

export function useUpdatePrimaryCurrency() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (primaryCurrency: Currency) => {
      const { data, error, response } = await api.PUT("/settings", { body: { primaryCurrency } });
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
    onSuccess: () => invalidateAfterWrite(queryClient),
  });
}

export function useSetExchangeRate() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ currency, rate }: { currency: Currency; rate: number }) => {
      const { data, error, response } = await api.PUT("/exchange-rates/{currency}", {
        params: { path: { currency } },
        body: { rate },
      });
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
    onSuccess: () => invalidateAfterWrite(queryClient),
  });
}

export function useDeleteExchangeRate() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (currency: Currency) => {
      const { error, response } = await api.DELETE("/exchange-rates/{currency}", {
        params: { path: { currency } },
      });
      if (!response.ok) throw new ApiError(response.status, error);
    },
    onSuccess: () => invalidateAfterWrite(queryClient),
  });
}
