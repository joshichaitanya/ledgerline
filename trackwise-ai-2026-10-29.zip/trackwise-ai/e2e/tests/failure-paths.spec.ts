import { expect, test } from "./support/fixtures";

// The app retries failed queries (TanStack Query default: 3 retries with backoff),
// so an error state can take several seconds to appear.
const afterRetries = { timeout: 15_000 };

test.describe("When things go wrong", () => {
  test("subscriptions list shows an error while the API is down, and Retry recovers", async ({
    page,
  }) => {
    await page.route("**/api/subscriptions", (route) => route.abort("connectionrefused"));
    await page.goto("/subscriptions");

    const alert = page.getByRole("alert");
    await expect(alert).toContainText("Couldn't load subscriptions.", afterRetries);

    await page.unroute("**/api/subscriptions");
    await alert.getByRole("button", { name: "Retry" }).click();

    await expect(page.getByRole("table")).toBeVisible();
    await expect(page.getByRole("alert")).toBeHidden();
  });

  test("dashboard shows an error while the API is down, and Retry recovers", async ({ page }) => {
    await page.route("**/api/summary", (route) => route.abort("connectionrefused"));
    await page.goto("/");

    const alert = page.getByRole("alert");
    await expect(alert).toContainText("Couldn't load the dashboard.", afterRetries);

    await page.unroute("**/api/summary");
    await alert.getByRole("button", { name: "Retry" }).click();

    await expect(page.getByRole("region", { name: "Monthly spend" })).toBeVisible();
  });

  test("header reports the API as unreachable", async ({ page }) => {
    await page.route("**/api/health", (route) => route.abort("connectionrefused"));
    await page.goto("/");

    await expect(page.getByRole("status", { name: "System status" })).toContainText(
      "API: unreachable",
      afterRetries,
    );
  });

  test("an unknown subscription id shows not found", async ({ page }) => {
    await page.goto("/subscriptions/00000000-0000-4000-8000-000000000000/edit");

    await expect(page.getByRole("alert")).toContainText("Subscription not found.");
    await page.getByRole("link", { name: "Back to subscriptions" }).click();
    await expect(page).toHaveURL(/\/subscriptions$/);
  });

  test("server-side validation errors are shown on the form", async ({ page }) => {
    // Simulate the server rejecting a request the browser considered valid.
    await page.route("**/api/subscriptions", (route) =>
      route.request().method() === "POST"
        ? route.fulfill({
            status: 400,
            json: {
              error: "ValidationError",
              message: "Request validation failed",
              issues: [{ path: "name", location: "body", message: "Name is already taken" }],
            },
          })
        : route.fallback(),
    );
    await page.goto("/subscriptions/new");
    await page.getByLabel("Name").fill("Duplicate");
    await page.getByLabel("Amount").fill("5");
    await page.getByLabel("Next renewal date").fill("2099-01-01");
    await page.getByRole("button", { name: "Add subscription" }).click();

    await expect(page.getByRole("alert")).toContainText("name: Name is already taken");
    await expect(page).toHaveURL(/\/subscriptions\/new$/);
  });
});
