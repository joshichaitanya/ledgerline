import { describe, expect, it } from "vitest";
import { presentSubscription } from "./present";
import { aSubscription } from "./test/fixtures";

describe("presentSubscription", () => {
  it("formats the price for a reader instead of exposing minor units", () => {
    const presented = presentSubscription(aSubscription({ amountMinor: 1599, currency: "USD" }));

    expect(presented.price).toBe("$15.99");
    expect(presented).not.toHaveProperty("amountMinor");
  });

  it.each([
    [149_900, "INR", "₹1,499.00"],
    [2400, "JPY", "¥2,400"],
    [999, "EUR", "€9.99"],
  ] as const)("formats %i %s as %s", (amountMinor, currency, expected) => {
    expect(presentSubscription(aSubscription({ amountMinor, currency })).price).toBe(expected);
  });

  it("keeps the id, so a model can chain list → get", () => {
    const subscription = aSubscription();

    expect(presentSubscription(subscription).id).toBe(subscription.id);
  });

  it("includes notes only when there are some (absent, never null)", () => {
    expect(presentSubscription(aSubscription({ notes: "Family plan" }))).toMatchObject({
      notes: "Family plan",
    });
    expect(presentSubscription(aSubscription({ notes: null }))).not.toHaveProperty("notes");
  });

  it("returns exactly the fields the tools' output schema declares", () => {
    expect(Object.keys(presentSubscription(aSubscription({ notes: "x" }))).sort()).toEqual([
      "billingCycle",
      "category",
      "id",
      "name",
      "nextRenewalDate",
      "notes",
      "price",
    ]);
  });
});
