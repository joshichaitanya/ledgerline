import {
  AnalyticsResponseSchema,
  buildAnalytics,
  shiftMonth,
  TREND_MONTHS,
  toIsoDate,
} from "@subtrack/contracts";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type { Database } from "../db/client";
import { listPaymentsSince } from "../payments/repository";
import { getSettings, loadEffectiveRates } from "../settings/repository";
import { processDueRenewals } from "../subscriptions/renewals";
import { listSubscriptions } from "../subscriptions/repository";

export const analyticsRoutes: FastifyPluginAsyncZod<{
  database: Database;
  now: () => Date;
}> = async (app, { database, now }) => {
  app.get(
    "/analytics",
    {
      schema: {
        operationId: "getAnalytics",
        tags: ["analytics"],
        summary: "Spending trend, Year-to-Date, 6-month forecast and this year's expenditure",
        response: {
          200: AnalyticsResponseSchema.describe("Analytics in the primary currency"),
        },
      },
    },
    async () => {
      const today = toIsoDate(now());
      await processDueRenewals(database, today);
      // Payments needed: the trend window and the whole current year, whichever starts first.
      const trendStart = `${shiftMonth(today.slice(0, 7), -(TREND_MONTHS - 1))}-01`;
      const yearStart = `${today.slice(0, 4)}-01-01`;
      // ISO dates sort as strings: the earlier of the two.
      const since = [trendStart, yearStart].sort()[0] ?? yearStart;
      const [subscriptions, payments, settings] = await Promise.all([
        listSubscriptions(database),
        listPaymentsSince(database, since),
        getSettings(database),
      ]);
      const rates = await loadEffectiveRates(database, settings.primaryCurrency);
      return buildAnalytics({
        payments: payments.map(({ paidOn, amountMinor, currency }) => ({
          date: paidOn,
          amountMinor,
          currency,
        })),
        subscriptions,
        today,
        primary: settings.primaryCurrency,
        rates,
      });
    },
  );
};
