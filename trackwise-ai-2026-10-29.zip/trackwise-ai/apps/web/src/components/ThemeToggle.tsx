import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";
import { applyTheme, saveTheme, storedTheme, systemTheme, type Theme } from "../lib/theme";

/** Light/dark switch. Follows the OS until the user chooses; the choice is remembered. */
export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>(() =>
    document.documentElement.classList.contains("dark") ? "dark" : "light",
  );

  useEffect(() => {
    if (storedTheme()) return; // an explicit choice wins over OS changes
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const follow = () => {
      const next = systemTheme();
      applyTheme(next);
      setTheme(next);
    };
    media.addEventListener("change", follow);
    return () => media.removeEventListener("change", follow);
  }, []);

  const next: Theme = theme === "dark" ? "light" : "dark";
  const Icon = theme === "dark" ? Sun : Moon;
  return (
    <button
      type="button"
      onClick={() => {
        applyTheme(next);
        saveTheme(next);
        setTheme(next);
      }}
      aria-label={`Switch to ${next} theme`}
      title={`Switch to ${next} theme`}
      className="rounded-full p-2 text-ink-muted hover:bg-surface-muted hover:text-ink"
    >
      <Icon aria-hidden="true" className="size-5" />
    </button>
  );
}
