import { z } from "zod";

export const ComponentStatusSchema = z.enum(["ok", "down"]);

export const HealthResponseSchema = z
  .object({
    status: z.enum(["ok", "degraded"]),
    checks: z.object({
      api: ComponentStatusSchema,
      database: ComponentStatusSchema,
    }),
  })
  .meta({ id: "HealthResponse" });

export type HealthResponse = z.infer<typeof HealthResponseSchema>;
