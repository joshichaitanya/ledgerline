import type {
  CreateSubscriptionRequest,
  Subscription,
  UpdateSubscriptionRequest,
} from "@subtrack/contracts";
import { asc, eq } from "drizzle-orm";
import type { Database } from "../db/client";
import { type SubscriptionRow, subscriptions } from "../db/schema";

/** Maps a DB row to the API contract shape (Dates become ISO strings). */
export function toSubscription(row: SubscriptionRow): Subscription {
  const { renewalAnchorDate: _internal, ...fields } = row;
  return {
    ...fields,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** All subscriptions, soonest renewal first; name and id break ties so the order is stable. */
export async function listSubscriptions({ db }: Database): Promise<Subscription[]> {
  const rows = await db
    .select()
    .from(subscriptions)
    .orderBy(asc(subscriptions.nextRenewalDate), asc(subscriptions.name), asc(subscriptions.id));
  return rows.map(toSubscription);
}

export async function getSubscription(
  { db }: Database,
  id: string,
): Promise<Subscription | undefined> {
  const [row] = await db.select().from(subscriptions).where(eq(subscriptions.id, id));
  return row && toSubscription(row);
}

export async function createSubscription(
  { db }: Database,
  input: CreateSubscriptionRequest,
): Promise<Subscription> {
  const [row] = await db
    .insert(subscriptions)
    .values({ ...input, notes: input.notes ?? null, renewalAnchorDate: input.nextRenewalDate })
    .returning();
  if (!row) throw new Error("Insert returned no row");
  return toSubscription(row);
}

/** Returns undefined when no subscription has this id. */
export async function updateSubscription(
  { db }: Database,
  id: string,
  patch: UpdateSubscriptionRequest,
): Promise<Subscription | undefined> {
  const [row] = await db
    .update(subscriptions)
    // A new renewal date the user entered becomes the new anchor.
    .set(patch.nextRenewalDate ? { ...patch, renewalAnchorDate: patch.nextRenewalDate } : patch)
    .where(eq(subscriptions.id, id))
    .returning();
  return row && toSubscription(row);
}

/** Returns false when no subscription has this id. */
export async function deleteSubscription({ db }: Database, id: string): Promise<boolean> {
  const deleted = await db
    .delete(subscriptions)
    .where(eq(subscriptions.id, id))
    .returning({ id: subscriptions.id });
  return deleted.length > 0;
}
