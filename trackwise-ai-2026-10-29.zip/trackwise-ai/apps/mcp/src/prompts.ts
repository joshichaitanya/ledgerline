import { completable } from "@modelcontextprotocol/sdk/server/completable.js";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { CategorySchema } from "@subtrack/contracts";
import { z } from "zod";

/*
 * Step 4.5 — PROMPTS: reusable message templates the USER picks (think slash commands).
 * A prompt doesn't do the work itself; it returns messages that set the model up to do it,
 * here by pointing it at our tools and attaching a resource as context.
 */

/** Category names starting with what the user has typed so far. */
const suggestCategories = (typed = "") =>
  CategorySchema.options.filter((category) => category.startsWith(typed));

export function registerPrompts(server: McpServer) {
  server.registerPrompt(
    "monthly-review",
    {
      title: "Monthly spending review",
      description:
        "Review this month's subscription spending, upcoming renewals and saving opportunities.",
      // Prompt arguments are always strings. `completable` offers suggestions as the user types.
      argsSchema: {
        // SDK quirk (1.32): registration looks INSIDE `.optional()` for a completable field, but
        // the completion handler checks the OUTER field. Marking both layers satisfies both —
        // wrapping only one way silently disabled suggestions (found by the Step 4.7 tests).
        focusCategory: completable(
          completable(z.string(), suggestCategories)
            .optional()
            .describe("Optional category to look at more closely"), // shown to the user
          suggestCategories,
        ),
      },
    },
    ({ focusCategory }) => ({
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: [
              "Review my subscription spending.",
              "Use get_spending_summary for totals and categories, get_upcoming_renewals for the next 30 days, and list_subscriptions for details.",
              ...(focusCategory
                ? [`Pay special attention to the "${focusCategory}" category.`]
                : []),
              "Then give me:",
              "1. My monthly and yearly spend, and the biggest categories.",
              "2. What renews in the next 30 days.",
              "3. Up to three subscriptions I could cancel or downgrade, with the monthly saving for each.",
              "Amounts are in my primary currency; mention any currency that couldn't be converted.",
            ].join("\n"),
          },
        },
        {
          // Prompts can carry resources too: the subscription list, attached as context.
          role: "user",
          content: {
            type: "resource_link",
            uri: "trackwise://subscriptions",
            name: "All subscriptions",
            mimeType: "application/json",
          },
        },
      ],
    }),
  );
}
