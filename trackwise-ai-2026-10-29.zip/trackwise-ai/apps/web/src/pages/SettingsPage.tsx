import { useEffect, useId, useState } from "react";
import {
  type Currency,
  useDeleteExchangeRate,
  useExchangeRates,
  useSetExchangeRate,
  useSettings,
  useUpdatePrimaryCurrency,
} from "../api/settings";
import { useSummary } from "../api/summary";
import { PageHeader } from "../components/PageHeader";
import { formatDate, formatMonth } from "../lib/format";
import { currencyOptions } from "../lib/subscription-form";

const card = "space-y-4 rounded-xl border border-line bg-surface p-6";
const input =
  "rounded-md border border-line-strong bg-surface px-3 py-2 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent";
const primaryButton =
  "rounded-md bg-accent px-3 py-2 text-sm font-medium text-white hover:bg-accent-hover disabled:opacity-50";

export function SettingsPage() {
  const settings = useSettings();
  const rates = useExchangeRates();
  const summary = useSummary();

  if (settings.isPending || rates.isPending || summary.isPending) {
    return (
      <p role="status" className="text-ink-subtle">
        Loading settings…
      </p>
    );
  }
  if (settings.isError || rates.isError || summary.isError) {
    return (
      <p role="alert" className="text-danger-ink">
        Couldn't load settings.
      </p>
    );
  }

  const primary = settings.data.primaryCurrency;
  // Rows for every currency in use or already rated, except the primary itself.
  const inUse = summary.data.spendByCurrency.map((spend) => spend.currency);
  const rated = rates.data.items.map((rate) => rate.currency);
  const currencies = [...new Set([...inUse, ...rated])].filter((c) => c !== primary).sort();

  return (
    <section className="max-w-3xl space-y-6">
      <PageHeader title="Settings" description="Primary currency and exchange rates." />
      <PrimaryCurrencyCard
        primary={primary}
        candidates={[...new Set([...currencyOptions, ...inUse])] as Currency[]}
      />
      <section aria-labelledby="rates-heading" className={card}>
        <div>
          <h3 id="rates-heading" className="text-lg font-semibold">
            Exchange rates
          </h3>
          <p className="text-sm text-ink-subtle">
            How much one unit of each currency is worth in {primary}. Built-in approximate rates (
            {formatMonth(rates.data.defaultsAsOf)}) apply until you set your own. Used only to
            convert totals for display; your subscription prices never change.
          </p>
        </div>
        {currencies.length === 0 ? (
          <p className="text-sm text-ink-muted">All your subscriptions are in {primary}.</p>
        ) : (
          <ul className="divide-y divide-line">
            {currencies.map((currency) => (
              <RateRow
                key={`${primary}-${currency}`}
                currency={currency}
                primary={primary}
                rate={rates.data.items.find((item) => item.currency === currency)}
                defaultRate={rates.data.defaults.find((item) => item.currency === currency)?.rate}
                defaultsAsOf={rates.data.defaultsAsOf}
              />
            ))}
          </ul>
        )}
      </section>
    </section>
  );
}

function PrimaryCurrencyCard({
  primary,
  candidates,
}: {
  primary: Currency;
  candidates: Currency[];
}) {
  const id = useId();
  const [selected, setSelected] = useState(primary);
  const update = useUpdatePrimaryCurrency();
  useEffect(() => setSelected(primary), [primary]);

  return (
    <section aria-labelledby={`${id}-heading`} className={card}>
      <div>
        <h3 id={`${id}-heading`} className="text-lg font-semibold">
          Primary currency
        </h3>
        <p className="text-sm text-ink-subtle">
          Totals, averages and charts are shown in this currency.
        </p>
      </div>
      <form
        className="flex flex-wrap items-end gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          update.mutate(selected);
        }}
      >
        <div className="space-y-1">
          <label htmlFor={id} className="block text-sm font-medium text-ink-muted">
            Currency
          </label>
          <select
            id={id}
            value={selected}
            onChange={(event) => setSelected(event.target.value as Currency)}
            className={input}
          >
            {[...new Set([primary, ...candidates])].sort().map((currency) => (
              <option key={currency}>{currency}</option>
            ))}
          </select>
        </div>
        <button
          type="submit"
          disabled={update.isPending || selected === primary}
          className={primaryButton}
        >
          {update.isPending ? "Saving…" : "Save"}
        </button>
      </form>
      {update.error && (
        <p role="alert" className="text-sm text-danger-ink">
          {update.error.message}
        </p>
      )}
    </section>
  );
}

function RateRow({
  currency,
  primary,
  rate,
  defaultRate,
  defaultsAsOf,
}: {
  currency: Currency;
  primary: Currency;
  /** The user's own rate, if set. */
  rate: { rate: number; updatedAt: string } | undefined;
  /** The built-in approximate rate, if this currency has one. */
  defaultRate: number | undefined;
  defaultsAsOf: string;
}) {
  const id = useId();
  const effective = rate?.rate ?? defaultRate;
  const [value, setValue] = useState(effective === undefined ? "" : String(effective));
  const [invalid, setInvalid] = useState(false);
  const save = useSetExchangeRate();
  const remove = useDeleteExchangeRate();
  useEffect(() => setValue(effective === undefined ? "" : String(effective)), [effective]);

  return (
    <li className="flex flex-wrap items-center justify-between gap-3 py-3">
      <form
        className="flex flex-wrap items-center gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const parsed = Number(value);
          const ok = value.trim() !== "" && Number.isFinite(parsed) && parsed > 0;
          setInvalid(!ok);
          if (ok) save.mutate({ currency, rate: parsed });
        }}
      >
        <label htmlFor={id} className="w-16 text-sm font-medium">
          1 {currency} =
        </label>
        <input
          id={id}
          type="text"
          inputMode="decimal"
          value={value}
          onChange={(event) => setValue(event.target.value)}
          aria-invalid={invalid}
          aria-describedby={invalid ? `${id}-error` : undefined}
          placeholder="e.g. 1.08"
          className={`${input} w-32 aria-[invalid=true]:border-danger`}
        />
        <span className="text-sm text-ink-muted">{primary}</span>
        <button
          type="submit"
          disabled={save.isPending}
          className={primaryButton}
          aria-label={`Save ${currency} rate`}
        >
          Save
        </button>
        {invalid && (
          <p id={`${id}-error`} className="w-full text-sm text-danger-ink">
            Enter a number greater than zero
          </p>
        )}
      </form>
      <div className="flex items-center gap-3 text-sm">
        {rate ? (
          <>
            <span className="text-ink-subtle">
              Custom · updated {formatDate(rate.updatedAt.slice(0, 10))}
            </span>
            <button
              type="button"
              onClick={() => remove.mutate(currency)}
              className="font-medium text-danger-ink hover:underline"
              aria-label={
                defaultRate === undefined
                  ? `Remove ${currency} rate`
                  : `Reset ${currency} rate to default`
              }
            >
              {defaultRate === undefined ? "Remove" : "Reset to default"}
            </button>
          </>
        ) : defaultRate !== undefined ? (
          <span className="rounded-full bg-surface-muted px-2 py-0.5 text-xs font-medium text-ink-muted">
            Default (approx., {formatMonth(defaultsAsOf)})
          </span>
        ) : (
          <span className="rounded-full bg-warning-chip px-2 py-0.5 text-xs font-medium text-warning-ink">
            No rate — not in totals
          </span>
        )}
      </div>
    </li>
  );
}
