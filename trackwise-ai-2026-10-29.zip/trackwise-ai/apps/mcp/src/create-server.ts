import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { READ_ONLY } from "./annotations";
import { registerPrompts } from "./prompts";
import { registerResources } from "./resources";
import { registerSpendingTools } from "./tools/spending";
import { registerSubscriptionTools } from "./tools/subscriptions";

/**
 * Builds the TrackWise MCP server with every tool, resource and prompt — but connects no
 * transport. `server.ts` connects it to stdio; tests connect it to an in-memory client.
 */
export function createServer(): McpServer {
  // The server: a name + version that clients see during the `initialize` handshake.
  const server = new McpServer({ name: "trackwise", version: "0.1.0" });

  server.registerTool(
    "ping",
    {
      title: "Ping",
      annotations: READ_ONLY,
      description: "Check that the TrackWise MCP server is running. Returns 'pong'.",
      inputSchema: {}, // this tool takes no arguments
    },
    // A result is a list of content blocks. Text is the simplest kind.
    async () => ({ content: [{ type: "text", text: "pong" }] }),
  );

  // Each group of capabilities lives in its own module.
  registerSubscriptionTools(server);
  registerSpendingTools(server);
  registerResources(server);
  registerPrompts(server);

  return server;
}
