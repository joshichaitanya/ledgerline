import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { createServer } from "./create-server";

// Connect over stdio: read requests from stdin, write responses to stdout.
await createServer().connect(new StdioServerTransport());

// Log to stderr, never stdout: stdout is reserved for protocol messages.
process.stderr.write("TrackWise MCP server running on stdio\n");
