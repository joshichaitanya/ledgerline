import { expect, test, utcDateFromToday } from "./support/fixtures";

test.describe("Renewing soon", () => {
  test("highlights a subscription renewing tomorrow, but not one weeks away", async ({
    page,
    arrange,
  }) => {
    const tomorrow = await arrange.subscription({
      amountMinor: 1234,
      nextRenewalDate: utcDateFromToday(1),
    });
    const later = await arrange.subscription({ nextRenewalDate: utcDateFromToday(20) });

    await page.goto("/");

    const panel = page.getByRole("region", { name: "Renewing soon" });
    const tomorrowItem = panel.getByRole("listitem").filter({ hasText: tomorrow.name });
    await expect(tomorrowItem).toContainText("Tomorrow");
    await expect(tomorrowItem).toContainText("Due soon");
    await expect(tomorrowItem).toContainText("$12.34");

    const laterItem = panel.getByRole("listitem").filter({ hasText: later.name });
    await expect(laterItem).toContainText("In 20 days");
    await expect(laterItem).not.toContainText("Due soon");
  });

  test("rolls an overdue renewal forward instead of hiding it", async ({ page, arrange }) => {
    // A weekly plan last due 6 days ago renews again tomorrow.
    const overdue = await arrange.subscription({
      billingCycle: "weekly",
      nextRenewalDate: utcDateFromToday(-6),
    });

    await page.goto("/");

    const item = page
      .getByRole("region", { name: "Renewing soon" })
      .getByRole("listitem")
      .filter({ hasText: overdue.name });
    await expect(item).toContainText("Tomorrow");
  });
});
