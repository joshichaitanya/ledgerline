import { screen, waitFor, within } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import type { Subscription } from "../api/subscriptions";
import { aSubscription } from "../test/fixtures";
import { mockApi, requestsOf, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { SubscriptionsPage } from "./SubscriptionsPage";

const listing = (items: Subscription[]) =>
  route("get", "/subscriptions").reply(() => ({ status: 200, body: { items } }));

describe("SubscriptionsPage", () => {
  it("lists subscriptions in API order with formatted values", async () => {
    mockApi(
      listing([
        aSubscription({ name: "Netflix", notes: "Family plan" }),
        aSubscription({
          name: "Nintendo Switch Online",
          amountMinor: 2400,
          currency: "JPY",
          billingCycle: "yearly",
          category: "gaming",
          nextRenewalDate: "2027-05-16",
        }),
      ]),
    );

    renderWithQueryClient(<SubscriptionsPage />);

    const table = await screen.findByRole("table");
    const [, firstRow, secondRow] = within(table).getAllByRole("row");
    expect(firstRow).toHaveTextContent("Netflix");
    expect(firstRow).toHaveTextContent("Family plan");
    expect(firstRow).toHaveTextContent("$15.99");
    expect(firstRow).toHaveTextContent("Monthly");
    expect(firstRow).toHaveTextContent("Nov 15, 2026");
    expect(firstRow).toHaveTextContent("Streaming");
    expect(secondRow).toHaveTextContent("Nintendo Switch Online");
    expect(secondRow).toHaveTextContent("¥2,400");
    expect(secondRow).toHaveTextContent("Yearly");
    expect(secondRow).toHaveTextContent("May 16, 2027");
    expect(secondRow).toHaveTextContent("Gaming");
  });

  it("shows a loading state before data arrives", () => {
    mockApi(route("get", "/subscriptions").reply(() => new Promise(() => {})));

    renderWithQueryClient(<SubscriptionsPage />);

    expect(screen.getByRole("status")).toHaveTextContent("Loading subscriptions…");
  });

  it("shows an empty state when there are no subscriptions", async () => {
    mockApi(listing([]));

    renderWithQueryClient(<SubscriptionsPage />);

    expect(await screen.findByText("No subscriptions yet.")).toBeInTheDocument();
    expect(screen.queryByRole("table")).not.toBeInTheDocument();
  });

  it("shows an error with a working retry", async () => {
    let calls = 0;
    mockApi(
      route("get", "/subscriptions").reply(() => {
        calls += 1;
        if (calls === 1) throw new TypeError("Failed to fetch");
        return { status: 200, body: { items: [aSubscription({ name: "Spotify" })] } };
      }),
    );

    renderWithQueryClient(<SubscriptionsPage />);

    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent("Couldn't load subscriptions.");

    await userEvent.click(within(alert).getByRole("button", { name: "Retry" }));

    expect(await screen.findByRole("table")).toHaveTextContent("Spotify");
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });
});

describe("SubscriptionsPage delete", () => {
  function setup() {
    const netflix = aSubscription({ name: "Netflix" });
    const spotify = aSubscription({ name: "Spotify" });
    let items = [netflix, spotify];
    const fetchMock = mockApi(
      route("get", "/subscriptions").reply(() => ({ status: 200, body: { items } })),
      route("delete", "/subscriptions/{id}").reply(({ params }) => {
        items = items.filter((item) => item.id !== params.id);
        return { status: 204 };
      }),
    );
    renderWithQueryClient(<SubscriptionsPage />);
    return { fetchMock, netflix, user: userEvent.setup() };
  }

  it("asks for confirmation, deletes, and refreshes the list", async () => {
    const { fetchMock, netflix, user } = setup();

    await user.click(await screen.findByRole("button", { name: "Delete Netflix" }));
    const dialog = screen.getByRole("alertdialog", { name: "Delete Netflix?" });
    expect(within(dialog).getByRole("button", { name: "Cancel" })).toHaveFocus();

    await user.click(within(dialog).getByRole("button", { name: "Delete" }));

    await waitFor(() => expect(screen.queryByRole("alertdialog")).not.toBeInTheDocument());
    await waitFor(() => expect(screen.queryByText("Netflix")).not.toBeInTheDocument());
    expect(screen.getByText("Spotify")).toBeInTheDocument();
    expect(requestsOf(fetchMock)).toContain(`DELETE /subscriptions/${netflix.id}`);
  });

  it("keeps the subscription when cancelled", async () => {
    const { fetchMock, user } = setup();

    await user.click(await screen.findByRole("button", { name: "Delete Netflix" }));
    await user.keyboard("{Escape}");

    expect(screen.queryByRole("alertdialog")).not.toBeInTheDocument();
    expect(screen.getByText("Netflix")).toBeInTheDocument();
    expect(requestsOf(fetchMock).some((request) => request.startsWith("DELETE"))).toBe(false);
  });
});
