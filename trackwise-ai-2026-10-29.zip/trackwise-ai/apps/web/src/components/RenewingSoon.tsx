import { DUE_SOON_DAYS, formatMoney } from "@subtrack/contracts";
import type { components } from "../api/schema.gen";
import { billingCycleLabel, formatDate } from "../lib/format";

type UpcomingRenewals = components["schemas"]["UpcomingRenewals"];

export function relativeDay(daysUntil: number): string {
  if (daysUntil === 0) return "Today";
  if (daysUntil === 1) return "Tomorrow";
  return `In ${daysUntil} days`;
}

/**
 * Next renewal per subscription within the window. Items due within DUE_SOON_DAYS are
 * highlighted with a tint *and* a text badge, so the state never relies on colour alone.
 */
export function RenewingSoon({ renewals }: { renewals: UpcomingRenewals }) {
  return (
    <section
      aria-labelledby="renewing-soon"
      className="rounded-lg border border-line bg-surface p-5"
    >
      <h3 id="renewing-soon" className="font-semibold">
        Renewing soon
      </h3>
      <p className="mb-4 text-sm text-ink-subtle">Next {renewals.windowDays} days</p>
      {renewals.items.length === 0 ? (
        <p className="text-sm text-ink-muted">
          Nothing renews in the next {renewals.windowDays} days.
        </p>
      ) : (
        <ul className="divide-y divide-line">
          {renewals.items.map((renewal) => {
            const dueSoon = renewal.daysUntil <= DUE_SOON_DAYS;
            return (
              <li
                key={renewal.subscriptionId}
                className={`-mx-2 flex items-center justify-between gap-4 rounded-md px-2 py-3 ${dueSoon ? "bg-warning-soft" : ""}`}
              >
                <div className="min-w-0">
                  <p className="truncate font-medium text-ink">
                    {renewal.name}
                    {dueSoon && (
                      <span className="ml-2 rounded-full bg-warning-chip px-2 py-0.5 text-xs font-medium text-warning-ink">
                        Due soon
                      </span>
                    )}
                  </p>
                  <p className="text-sm text-ink-subtle">
                    <time dateTime={renewal.renewalDate}>{formatDate(renewal.renewalDate)}</time>
                    {" · "}
                    {relativeDay(renewal.daysUntil)}
                  </p>
                </div>
                <p className="whitespace-nowrap text-right tabular-nums">
                  {formatMoney(renewal.amountMinor, renewal.currency)}
                  <span className="block text-xs text-ink-subtle">
                    {billingCycleLabel(renewal.billingCycle)}
                  </span>
                </p>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
