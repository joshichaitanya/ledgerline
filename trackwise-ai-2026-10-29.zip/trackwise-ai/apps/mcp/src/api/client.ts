import createClient from "openapi-fetch";
import type { paths } from "./schema.gen";

// Where the TrackWise API runs. Overridable, e.g. when the server runs elsewhere (Phase 7).
export const API_URL = process.env.TRACKWISE_API_URL ?? "http://127.0.0.1:3000";

// Every path, parameter and response below is typed from the API's OpenAPI spec.
export const api = createClient<paths>({
  baseUrl: API_URL,
  // Resolve fetch per call, so tests can stub it.
  fetch: (request) => globalThis.fetch(request),
});
