import { screen } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { ApiError } from "../api/subscriptions";
import { emptyFormValues } from "../lib/subscription-form";
import { renderWithQueryClient } from "../test/render";
import { SubscriptionForm } from "./SubscriptionForm";

function renderForm(props: Partial<Parameters<typeof SubscriptionForm>[0]> = {}) {
  const onSubmit = vi.fn();
  renderWithQueryClient(
    <SubscriptionForm
      defaultValues={emptyFormValues}
      submitLabel="Add subscription"
      onSubmit={onSubmit}
      isSubmitting={false}
      submitError={null}
      {...props}
    />,
  );
  return { onSubmit, user: userEvent.setup() };
}

describe("SubscriptionForm", () => {
  it("shows field errors and does not submit an empty form", async () => {
    const { onSubmit, user } = renderForm();

    await user.click(screen.getByRole("button", { name: "Add subscription" }));

    expect(await screen.findByText("Name is required")).toBeInTheDocument();
    expect(screen.getByText("Enter an amount like 9.99")).toBeInTheDocument();
    expect(screen.getByText("Enter a valid date")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Name")).toHaveAccessibleDescription("Name is required");
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("submits the API request shape", async () => {
    const { onSubmit, user } = renderForm();

    await user.type(screen.getByLabelText("Name"), "Spotify");
    await user.type(screen.getByLabelText("Amount"), "11.99");
    await user.selectOptions(screen.getByLabelText("Currency"), "EUR");
    await user.selectOptions(screen.getByLabelText("Billing cycle"), "yearly");
    await user.selectOptions(screen.getByLabelText("Category"), "music");
    await user.type(screen.getByLabelText("Next renewal date"), "2026-12-01");
    await user.type(screen.getByLabelText("Notes (optional)"), "Duo plan");
    await user.click(screen.getByRole("button", { name: "Add subscription" }));

    expect(onSubmit).toHaveBeenCalledWith({
      name: "Spotify",
      amountMinor: 1199,
      currency: "EUR",
      billingCycle: "yearly",
      category: "music",
      nextRenewalDate: "2026-12-01",
      notes: "Duo plan",
    });
  });

  it("shows server validation issues", () => {
    renderForm({
      submitError: new ApiError(400, {
        error: "ValidationError",
        message: "Request validation failed",
        issues: [{ path: "currency", location: "body", message: "Unsupported currency" }],
      }),
    });

    expect(screen.getByRole("alert")).toHaveTextContent("Request validation failed");
    expect(screen.getByRole("alert")).toHaveTextContent("currency: Unsupported currency");
  });
});
