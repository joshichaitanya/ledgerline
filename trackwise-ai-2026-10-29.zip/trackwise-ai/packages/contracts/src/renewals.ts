import { z } from "zod";
import {
  type BillingCycle,
  BillingCycleSchema,
  CurrencySchema,
  type Subscription,
} from "./subscription";

// Calendar dates are "YYYY-MM-DD" strings, computed in UTC so no timezone can shift a day.

const MS_PER_DAY = 86_400_000;

function toUtcMs(isoDate: string): number {
  return Date.parse(`${isoDate}T00:00:00Z`);
}

function fromUtcMs(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

/** The UTC calendar date of an instant, e.g. "2026-10-28". */
export function toIsoDate(instant: Date): string {
  return instant.toISOString().slice(0, 10);
}

export function addDays(isoDate: string, days: number): string {
  return fromUtcMs(toUtcMs(isoDate) + days * MS_PER_DAY);
}

/** Whole days from `from` to `to` (negative if `to` is earlier). */
export function daysBetween(from: string, to: string): number {
  return Math.round((toUtcMs(to) - toUtcMs(from)) / MS_PER_DAY);
}

/** Adds calendar months, clamping to the month's last day: Jan 31 + 1 month → Feb 28/29. */
export function addMonths(isoDate: string, months: number): string {
  const [year = 0, month = 1, day = 1] = isoDate.split("-").map(Number);
  const target = new Date(0);
  // setUTCFullYear, not Date.UTC: Date.UTC maps years 0–99 to 1900–1999.
  target.setUTCFullYear(year, month - 1 + months, 1);
  const lastDay = new Date(target);
  lastDay.setUTCMonth(lastDay.getUTCMonth() + 1, 0);
  target.setUTCDate(Math.min(day, lastDay.getUTCDate()));
  return fromUtcMs(target.getTime());
}

/**
 * The `n`th renewal after the anchor date (n = 0 is the anchor itself; negative n goes back).
 * Always computed from the anchor, so month-end dates never drift (Jan 31 → Feb 28 → Mar 31).
 */
export function nthRenewal(anchor: string, cycle: BillingCycle, n: number): string {
  switch (cycle) {
    case "weekly":
      return addDays(anchor, 7 * n);
    case "monthly":
      return addMonths(anchor, n);
    case "yearly":
      return addMonths(anchor, 12 * n);
  }
}

/** Smallest n ≥ 0 whose renewal falls on or after `target`. */
export function firstRenewalIndexOnOrAfter(
  anchor: string,
  cycle: BillingCycle,
  target: string,
): number {
  if (anchor >= target) return 0;
  const daysLate = daysBetween(anchor, target);
  if (cycle === "weekly") return Math.ceil(daysLate / 7);
  const cycleDays = cycle === "monthly" ? 28 : 365;
  // Start just below the estimate (cycles can be longer than cycleDays), then step up.
  let n = Math.max(1, Math.floor(daysLate / (cycleDays + 3)));
  while (nthRenewal(anchor, cycle, n) < target) n += 1;
  return n;
}

/**
 * The first renewal on or after `today`. A stored date that has passed is rolled forward
 * by whole billing cycles: a monthly plan due Jan 31 renews Feb 28 (29 in leap years),
 * then Mar 31 — the original day is kept, never drifting to the 28th.
 */
export function advanceRenewalDate(isoDate: string, cycle: BillingCycle, today: string): string {
  return nthRenewal(isoDate, cycle, firstRenewalIndexOnOrAfter(isoDate, cycle, today));
}

/** How far back missed renewals are recorded as payments (bounds catch-up work). */
export const CATCH_UP_DAYS = 366;

/**
 * Renewals that have happened (on or before `today`) since `nextRenewalDate`, counted from the
 * anchor so month-end dates don't drift, and limited to the last CATCH_UP_DAYS. Also returns
 * the next renewal after today.
 */
export function dueRenewals(
  anchor: string,
  nextRenewalDate: string,
  cycle: BillingCycle,
  today: string,
): { paymentDates: string[]; nextRenewalDate: string } {
  const earliest = addDays(today, -CATCH_UP_DAYS);
  const from = nextRenewalDate > earliest ? nextRenewalDate : earliest;
  const paymentDates: string[] = [];
  let n = firstRenewalIndexOnOrAfter(anchor, cycle, from);
  for (
    let date = nthRenewal(anchor, cycle, n);
    date <= today;
    date = nthRenewal(anchor, cycle, ++n)
  ) {
    paymentDates.push(date);
  }
  return { paymentDates, nextRenewalDate: nthRenewal(anchor, cycle, n) };
}

/** Renewals strictly before `before` and on or after `since`, newest first (used to seed history). */
export function pastRenewals(
  anchor: string,
  cycle: BillingCycle,
  since: string,
  before: string,
): string[] {
  const dates: string[] = [];
  for (let n = -1; ; n--) {
    const date = nthRenewal(anchor, cycle, n);
    if (date < since) return dates;
    if (date < before) dates.push(date);
  }
}

export const DEFAULT_RENEWAL_WINDOW_DAYS = 30;

/** Renewals this close are highlighted as due soon. */
export const DUE_SOON_DAYS = 7;

export const UpcomingRenewalSchema = z
  .object({
    subscriptionId: z.uuid(),
    name: z.string(),
    amountMinor: z.int().positive(),
    currency: CurrencySchema,
    billingCycle: BillingCycleSchema,
    /** The next renewal on or after `asOf` (past-due stored dates are rolled forward). */
    renewalDate: z.iso.date(),
    /** 0 = today. */
    daysUntil: z.int().nonnegative(),
  })
  .meta({ id: "UpcomingRenewal" });

export const UpcomingRenewalsSchema = z
  .object({
    /** The date "today" was taken to be (UTC). */
    asOf: z.iso.date(),
    windowDays: z.int().positive(),
    /** Soonest first; at most one entry per subscription. */
    items: z.array(UpcomingRenewalSchema),
  })
  .meta({ id: "UpcomingRenewals" });

export type UpcomingRenewal = z.infer<typeof UpcomingRenewalSchema>;
export type UpcomingRenewals = z.infer<typeof UpcomingRenewalsSchema>;

type Renewable = Pick<
  Subscription,
  "id" | "name" | "amountMinor" | "currency" | "billingCycle" | "nextRenewalDate"
>;

/** Each subscription's next renewal within `windowDays` of `today` (inclusive), soonest first. */
export function upcomingRenewals(
  subscriptions: readonly Renewable[],
  today: string,
  windowDays: number,
): UpcomingRenewals {
  const items = subscriptions
    .map((subscription) => {
      const renewalDate = advanceRenewalDate(
        subscription.nextRenewalDate,
        subscription.billingCycle,
        today,
      );
      return {
        subscriptionId: subscription.id,
        name: subscription.name,
        amountMinor: subscription.amountMinor,
        currency: subscription.currency,
        billingCycle: subscription.billingCycle,
        renewalDate,
        daysUntil: daysBetween(today, renewalDate),
      };
    })
    .filter((renewal) => renewal.daysUntil <= windowDays)
    .sort((a, b) => a.daysUntil - b.daysUntil || a.name.localeCompare(b.name));

  return { asOf: today, windowDays, items };
}
