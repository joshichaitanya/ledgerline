import type { Subscription } from "../api/subscriptions";

const dateFormatter = new Intl.DateTimeFormat("en-US", {
  year: "numeric",
  month: "short",
  day: "numeric",
  timeZone: "UTC",
});

/**
 * Formats a date-only value ("2026-11-15") as "Nov 15, 2026".
 * Parsed and formatted in UTC so it never shifts a day in the viewer's timezone.
 */
export function formatDate(isoDate: string): string {
  return dateFormatter.format(new Date(`${isoDate}T00:00:00Z`));
}

const billingCycleLabels: Record<Subscription["billingCycle"], string> = {
  weekly: "Weekly",
  monthly: "Monthly",
  yearly: "Yearly",
};

export function billingCycleLabel(cycle: Subscription["billingCycle"]): string {
  return billingCycleLabels[cycle];
}

export function categoryLabel(category: Subscription["category"]): string {
  return category.charAt(0).toUpperCase() + category.slice(1);
}

const monthFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  year: "numeric",
  timeZone: "UTC",
});

/** "2026-10" → "Oct 2026". */
export function formatMonth(yearMonth: string): string {
  return monthFormatter.format(new Date(`${yearMonth}-01T00:00:00Z`));
}
