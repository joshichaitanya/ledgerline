import {
  ErrorResponseSchema,
  PaymentIdParamsSchema,
  PaymentListResponseSchema,
  PaymentSchema,
  SubscriptionIdParamsSchema,
  toIsoDate,
  UpdatePaymentRequestSchema,
} from "@subtrack/contracts";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { z } from "zod";
import type { Database } from "../db/client";
import { deletePayment, listPayments, updatePayment } from "../payments/repository";
import { processDueRenewals } from "../subscriptions/renewals";
import { getSubscription } from "../subscriptions/repository";

const paymentNotFound = { error: "NotFound", message: "Payment not found" } as const;

export const paymentRoutes: FastifyPluginAsyncZod<{ database: Database; now: () => Date }> = async (
  app,
  { database, now },
) => {
  app.get(
    "/subscriptions/:id/payments",
    {
      schema: {
        operationId: "listPayments",
        tags: ["payments"],
        summary: "Payment history of a subscription, newest first",
        params: SubscriptionIdParamsSchema,
        response: {
          200: PaymentListResponseSchema.describe("Recorded payments"),
          400: ErrorResponseSchema.describe("Malformed id"),
          404: ErrorResponseSchema.describe("No subscription has this id"),
        },
      },
    },
    async (request, reply) => {
      await processDueRenewals(database, toIsoDate(now()));
      if (!(await getSubscription(database, request.params.id))) {
        return reply.code(404).send({ error: "NotFound", message: "Subscription not found" });
      }
      return { items: await listPayments(database, request.params.id) };
    },
  );

  app.patch(
    "/payments/:id",
    {
      schema: {
        operationId: "updatePayment",
        tags: ["payments"],
        summary: "Correct a recorded payment's amount or date",
        params: PaymentIdParamsSchema,
        body: UpdatePaymentRequestSchema,
        response: {
          200: PaymentSchema.describe("The updated payment"),
          400: ErrorResponseSchema.describe("Malformed id or invalid request body"),
          404: ErrorResponseSchema.describe("No payment has this id"),
          409: ErrorResponseSchema.describe("The subscription already has a payment on that date"),
        },
      },
    },
    async (request, reply) => {
      const result = await updatePayment(database, request.params.id, request.body);
      if (result.ok) return result.payment;
      return result.reason === "not-found"
        ? reply.code(404).send(paymentNotFound)
        : reply.code(409).send({
            error: "DuplicatePaymentDate",
            message: "This subscription already has a payment on that date",
          });
    },
  );

  app.delete(
    "/payments/:id",
    {
      schema: {
        operationId: "deletePayment",
        tags: ["payments"],
        summary: "Delete a recorded payment (e.g. a skipped month)",
        params: PaymentIdParamsSchema,
        response: {
          204: z.null().describe("Deleted (no content)"),
          400: ErrorResponseSchema.describe("Malformed id"),
          404: ErrorResponseSchema.describe("No payment has this id"),
        },
      },
    },
    async (request, reply) =>
      (await deletePayment(database, request.params.id))
        ? reply.code(204).send(null)
        : reply.code(404).send(paymentNotFound),
  );
};
