import { expect, test, uniqueName } from "./support/fixtures";

test.describe("Add a subscription", () => {
  test("adds a subscription and shows it in the list", async ({ page, arrange }) => {
    const name = uniqueName("E2E Add");
    arrange.cleanUpNamed(name);

    await page.goto("/subscriptions");
    await page.getByRole("link", { name: "Add subscription" }).click();
    await expect(page).toHaveURL(/\/subscriptions\/new$/);

    await page.getByLabel("Name").fill(name);
    await page.getByLabel("Amount").fill("12.50");
    await page.getByLabel("Currency").selectOption("EUR");
    await page.getByLabel("Billing cycle").selectOption("yearly");
    await page.getByLabel("Category").selectOption("software");
    await page.getByLabel("Next renewal date").fill("2099-06-30");
    await page.getByLabel("Notes (optional)").fill("Added by E2E");
    await page.getByRole("button", { name: "Add subscription" }).click();

    await expect(page).toHaveURL(/\/subscriptions$/);
    const row = page.getByRole("row").filter({ hasText: name });
    await expect(row).toContainText("€12.50");
    await expect(row).toContainText("Yearly");
    await expect(row).toContainText("Jun 30, 2099");
    await expect(row).toContainText("Software");
    await expect(row).toContainText("Added by E2E");
  });

  test("shows validation errors and stays on the form", async ({ page }) => {
    await page.goto("/subscriptions/new");

    await page.getByLabel("Amount").fill("12.345");
    await page.getByRole("button", { name: "Add subscription" }).click();

    await expect(page.getByText("Name is required")).toBeVisible();
    await expect(page.getByText("Use at most 2 decimal places")).toBeVisible();
    await expect(page.getByText("Enter a valid date")).toBeVisible();
    await expect(page).toHaveURL(/\/subscriptions\/new$/);
  });
});
