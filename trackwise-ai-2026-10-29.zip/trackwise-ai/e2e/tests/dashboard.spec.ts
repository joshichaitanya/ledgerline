import { expect, test, uniqueName } from "./support/fixtures";

// Seed (apps/api/src/db/seed.ts): USD $1,154.99/yr, plus €119.88/yr and ¥2,400/yr, which are
// converted with the built-in default rates (€1 = $1.16, ¥1 = $0.0066):
// plus ₹15,984/yr (5 Indian services, ₹1 = $0.0114 → $182.22):
// $1,154.99 + $139.06 + $15.84 + $182.22 = $1,492.11/yr → $124.34/mo.
test.describe("Dashboard", () => {
  test("shows converted totals and the category breakdown", async ({ page }) => {
    await page.goto("/");

    const monthly = page.getByRole("region", { name: "Monthly spend" });
    await expect(monthly).toContainText("$124.34");
    await expect(monthly).not.toContainText("(no rate)");
    await expect(page.getByRole("region", { name: "Yearly spend" })).toContainText("$1,492.11");
    await expect(page.getByRole("region", { name: "Active subscriptions" })).toContainText("14");
    await expect(page.getByText(/built-in approximate defaults/)).toBeVisible();

    const categories = page.getByRole("region", { name: "Category breakdown" });
    // Streaming: Netflix, Disney+, Amazon Prime, Hotstar, SonyLIV
    await expect(categories.getByRole("listitem").first()).toContainText("Streaming");
    await expect(categories.getByRole("listitem").first()).toContainText("$30.81");
  });

  test("totals increase after adding a subscription", async ({ page, arrange }) => {
    const name = uniqueName("E2E Dashboard");
    arrange.cleanUpNamed(name);

    await page.goto("/");
    await expect(page.getByRole("region", { name: "Monthly spend" })).toContainText("$124.34");

    await page.getByRole("link", { name: "Subscriptions", exact: true }).click();
    await page.getByRole("link", { name: "Add subscription" }).click();
    await page.getByLabel("Name").fill(name);
    await page.getByLabel("Amount").fill("10");
    await page.getByLabel("Next renewal date").fill("2099-01-01");
    await page.getByRole("button", { name: "Add subscription" }).click();
    await expect(page.getByRole("row").filter({ hasText: name })).toBeVisible();

    await page
      .getByRole("navigation", { name: "Main" })
      .getByRole("link", { name: "Dashboard" })
      .click();

    // $1,492.11 + $120.00 = $1,612.11/yr → $134.34/mo
    await expect(page.getByRole("region", { name: "Monthly spend" })).toContainText("$134.34");
    await expect(page.getByRole("region", { name: "Yearly spend" })).toContainText("$1,612.11");
    await expect(page.getByRole("region", { name: "Active subscriptions" })).toContainText("15");
  });
});
