import { z } from "zod";

/** Every non-2xx API response has this shape, so clients handle errors one way. */
export const ErrorResponseSchema = z
  .object({
    /** Machine-readable code, e.g. "ValidationError", "NotFound". */
    error: z.string(),
    /** Human-readable summary. */
    message: z.string(),
    /** Present for validation errors: one entry per invalid field. */
    issues: z
      .array(
        z.object({
          /** Dotted path within `location`, e.g. "name" or "id". */
          path: z.string(),
          location: z.enum(["body", "params", "querystring", "headers"]),
          message: z.string(),
        }),
      )
      .optional(),
  })
  .meta({ id: "ErrorResponse" });

export type ErrorResponse = z.infer<typeof ErrorResponseSchema>;
