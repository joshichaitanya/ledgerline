import { AnalyticsResponseSchema } from "@subtrack/contracts";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";
import { appSettings, exchangeRates, subscriptions } from "../src/db/schema";
import { testDatabaseUrl } from "./test-database";

const database = createDatabase(testDatabaseUrl);
const app = await buildApp({ database, now: () => new Date("2026-10-28T12:00:00Z") });

async function getAnalytics() {
  const response = await app.inject({ method: "GET", url: "/analytics" });
  expect(response.statusCode).toBe(200);
  return AnalyticsResponseSchema.parse(response.json());
}

beforeEach(async () => {
  await database.db.delete(subscriptions);
  await database.db.delete(exchangeRates);
  await database.db.delete(appSettings);
});

afterAll(async () => {
  await app.close();
  await database.close();
});

describe("GET /analytics", () => {
  it("returns empty series when there is nothing to analyse", async () => {
    const analytics = await getAnalytics();

    expect(analytics).toMatchObject({ currency: "USD", asOf: "2026-10-28", yearToDateMinor: 0 });
    expect(analytics.spendingTrend).toHaveLength(12);
    expect(analytics.spendingTrend.every((month) => month.amountMinor === 0)).toBe(true);
    expect(analytics.forecast).toHaveLength(6);
    expect(analytics.monthlyExpenditure.months).toHaveLength(12);
  });

  it("derives trend and Year-to-Date from payments recorded as renewals pass", async () => {
    // Monthly $10 since Aug 15: payments recorded for Aug 15, Sep 15 and Oct 15.
    await database.db.insert(subscriptions).values({
      name: "Gym",
      amountMinor: 1000,
      currency: "USD",
      billingCycle: "monthly",
      category: "fitness",
      nextRenewalDate: "2026-08-15",
    });

    const analytics = await getAnalytics();

    expect(analytics.spendingTrend.slice(-3)).toEqual([
      { month: "2026-08", amountMinor: 1000 },
      { month: "2026-09", amountMinor: 1000 },
      { month: "2026-10", amountMinor: 1000 },
    ]);
    expect(analytics.yearToDateMinor).toBe(3000);
    expect(analytics.forecast[0]).toEqual({ month: "2026-11", amountMinor: 1000 });
    const october = analytics.monthlyExpenditure.months.find((m) => m.month === "2026-10");
    expect(october).toEqual({ month: "2026-10", amountMinor: 1000, kind: "current" });
  });

  it("converts with exchange rates and reports currencies without one", async () => {
    await database.db.insert(subscriptions).values([
      {
        name: "Disney+",
        amountMinor: 1000,
        currency: "EUR",
        billingCycle: "monthly",
        category: "streaming",
        nextRenewalDate: "2026-11-01",
      },
      {
        name: "Icelandic",
        amountMinor: 2400,
        currency: "ISK", // no built-in default
        billingCycle: "yearly",
        category: "gaming",
        nextRenewalDate: "2027-02-01",
      },
    ]);
    await app.inject({ method: "PUT", url: "/exchange-rates/EUR", payload: { rate: 1.1 } });

    const analytics = await getAnalytics();

    expect(analytics.forecast[0]).toEqual({ month: "2026-11", amountMinor: 1100 }); // €10 × 1.1
    expect(analytics.unconvertedCurrencies).toEqual(["ISK"]);
  });
});
