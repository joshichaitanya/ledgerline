import { describe, expect, it } from "vitest";
import { convertMinor, ExchangeRateSchema, rebaseRates } from "./settings";
import type { Currency } from "./subscription";

const rates = new Map<Currency, number>([
  ["EUR", 1.08],
  ["JPY", 0.0067],
  ["BHD", 2.65],
]);

describe("convertMinor", () => {
  it("leaves the primary currency unchanged", () => {
    expect(convertMinor(1599, "USD", "USD", rates)).toBe(1599);
  });

  it("converts via the rate, respecting each currency's minor unit", () => {
    expect(convertMinor(999, "EUR", "USD", rates)).toBe(1079); // €9.99 × 1.08 = $10.7892
    expect(convertMinor(2400, "JPY", "USD", rates)).toBe(1608); // ¥2400 (no decimals) × 0.0067
    // BHD 1.500 (3 decimals) × 2.65 = $3.975 exactly → rounds half up, despite float error
    expect(convertMinor(1500, "BHD", "USD", rates)).toBe(398);
  });

  it("converts into a zero-decimal primary currency", () => {
    const toYen = new Map<Currency, number>([["USD", 149.5]]);
    expect(convertMinor(1599, "USD", "JPY", toYen)).toBe(2391); // $15.99 × 149.5 = ¥2390.5
  });

  it("returns undefined, never a guess, when a rate is missing", () => {
    expect(convertMinor(1000, "GBP", "USD", rates)).toBeUndefined();
  });
});

describe("rebaseRates", () => {
  it("re-expresses every rate against the new primary currency", () => {
    const rebased = rebaseRates(rates, "USD", "EUR");

    expect(rebased).toEqual(
      new Map([
        ["USD", 0.9259259259], // 1 ÷ 1.08
        ["JPY", 0.006203703704], // 0.0067 ÷ 1.08
        ["BHD", 2.453703704], // 2.65 ÷ 1.08
      ]),
    );
  });

  it("round-trips back to the original rates", () => {
    const there = rebaseRates(rates, "USD", "EUR");
    const back = there && rebaseRates(there, "EUR", "USD");

    expect(back?.get("EUR")).toBeCloseTo(1.08, 8);
    expect(back?.get("JPY")).toBeCloseTo(0.0067, 8);
  });

  it("is impossible when the new primary has no rate", () => {
    expect(rebaseRates(rates, "USD", "GBP")).toBeUndefined();
  });
});

describe("ExchangeRateSchema", () => {
  it.each([0, -1, 2_000_000_000, Number.NaN])("rejects rate %s", (rate) => {
    expect(ExchangeRateSchema.shape.rate.safeParse(rate).success).toBe(false);
  });
});
