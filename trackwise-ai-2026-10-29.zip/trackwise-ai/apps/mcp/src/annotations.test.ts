import { describe, expect, it } from "vitest";
import { CREATES, READ_ONLY } from "./annotations";

describe("tool annotations", () => {
  it("READ_ONLY never changes anything and stays inside TrackWise", () => {
    expect(READ_ONLY).toEqual({ readOnlyHint: true, openWorldHint: false });
  });

  it("CREATES writes, without deleting anything, and isn't safe to repeat", () => {
    expect(CREATES).toEqual({
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: false,
    });
  });
});
