import { type McpServer, ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";
import { ErrorCode, McpError } from "@modelcontextprotocol/sdk/types.js";
import { formatMoney } from "@subtrack/contracts";
import { fromApi, NotFoundError, ToolError } from "./api/call";
import { api } from "./api/client";
import { presentSubscription } from "./present";

/*
 * Step 4.5 — RESOURCES: read-only data identified by a URI, like files. Unlike tools, the model
 * doesn't decide to fetch them; the client app (or the user) attaches them as context.
 *
 *   resources/list            → what fixed resources exist        (trackwise://subscriptions)
 *   resources/templates/list  → URI patterns with parameters      (trackwise://subscriptions/{id})
 *   resources/read            → the content of one URI
 */

/** JSON-RPC code the MCP spec uses for "resource not found". */
const RESOURCE_NOT_FOUND = -32002;

/**
 * Resources can't return `isError` like tools; a failure is a JSON-RPC error instead.
 * Only a real 404 is "resource not found"; anything else (e.g. the API is down) is an internal
 * error — still with the helpful message, so the client can show what to do.
 */
async function readOrFail<T>(read: () => Promise<T>): Promise<T> {
  try {
    return await read();
  } catch (error) {
    if (error instanceof NotFoundError) throw new McpError(RESOURCE_NOT_FOUND, error.message);
    if (error instanceof ToolError) throw new McpError(ErrorCode.InternalError, error.message);
    throw error;
  }
}

const json = (uri: URL, data: unknown) => ({
  contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(data, null, 2) }],
});

export function registerResources(server: McpServer) {
  // A fixed resource: one URI, always the same meaning.
  server.registerResource(
    "subscriptions",
    "trackwise://subscriptions",
    {
      title: "All subscriptions",
      description: "Every subscription with price, billing cycle, next renewal and category.",
      mimeType: "application/json",
    },
    async (uri) =>
      readOrFail(async () => {
        const data = await fromApi(api.GET("/subscriptions"));
        return json(uri, data.items.map(presentSubscription));
      }),
  );

  // A resource TEMPLATE: a URI pattern. `list` lets clients enumerate the concrete URIs, and
  // `complete` offers values for {id} as the user types.
  server.registerResource(
    "subscription",
    new ResourceTemplate("trackwise://subscriptions/{id}", {
      list: async () =>
        readOrFail(async () => {
          const data = await fromApi(api.GET("/subscriptions"));
          return {
            // Each entry gets its own title: otherwise the SDK copies the template's title
            // ("One subscription") onto every entry, and clients show 14 identical labels.
            resources: data.items.map((s) => ({
              uri: `trackwise://subscriptions/${s.id}`,
              name: s.name,
              title: s.name,
              description: `${formatMoney(s.amountMinor, s.currency)} ${s.billingCycle} (${s.category}), with payment history`,
              mimeType: "application/json",
            })),
          };
        }),
    }),
    {
      title: "One subscription",
      description: "A single subscription with its full payment history (newest first).",
      mimeType: "application/json",
    },
    async (uri, { id }) =>
      readOrFail(async () => {
        const subscriptionId = String(id);
        const notFound = `No subscription has id ${subscriptionId}.`;
        const path = { params: { path: { id: subscriptionId } } };
        const [subscription, payments] = await Promise.all([
          fromApi(api.GET("/subscriptions/{id}", path), { notFound }),
          fromApi(api.GET("/subscriptions/{id}/payments", path), { notFound }),
        ]);
        return json(uri, {
          ...presentSubscription(subscription),
          // Formatted like everywhere else: "₹1,499.00", never 149900 minor units.
          payments: payments.items.map((p) => ({
            paidOn: p.paidOn,
            amount: formatMoney(p.amountMinor, p.currency),
          })),
        });
      }),
  );
}
