import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "./client";
import type { components } from "./schema.gen";
import { ApiError } from "./subscriptions";

export type Payment = components["schemas"]["Payment"];
export type UpdatePaymentRequest = components["schemas"]["UpdatePaymentRequestInput"];

export const paymentsKey = (subscriptionId: string) =>
  ["subscriptions", subscriptionId, "payments"] as const;

export function usePayments(subscriptionId: string) {
  return useQuery({
    queryKey: paymentsKey(subscriptionId),
    queryFn: async () => {
      const { data, error, response } = await api.GET("/subscriptions/{id}/payments", {
        params: { path: { id: subscriptionId } },
      });
      if (!data) throw new ApiError(response.status, error);
      return data.items;
    },
  });
}

/** Payment edits change trends and Year-to-Date, so analytics refreshes too. */
function useInvalidatePayments(subscriptionId: string) {
  const queryClient = useQueryClient();
  return () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: paymentsKey(subscriptionId) }),
      queryClient.invalidateQueries({ queryKey: ["analytics"] }),
    ]);
}

export function useUpdatePayment(subscriptionId: string) {
  const invalidate = useInvalidatePayments(subscriptionId);
  return useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: UpdatePaymentRequest }) => {
      const { data, error, response } = await api.PATCH("/payments/{id}", {
        params: { path: { id } },
        body: patch,
      });
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
    onSuccess: invalidate,
  });
}

export function useDeletePayment(subscriptionId: string) {
  const invalidate = useInvalidatePayments(subscriptionId);
  return useMutation({
    mutationFn: async (id: string) => {
      const { error, response } = await api.DELETE("/payments/{id}", { params: { path: { id } } });
      if (!response.ok) throw new ApiError(response.status, error);
    },
    onSuccess: invalidate,
  });
}
