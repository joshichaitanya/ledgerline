# TrackWise-AI — Roadmap

# Phase 1 — Foundation

**Goal:** a single user can create, view, edit and delete subscriptions, and see a dashboard with monthly spend and upcoming renewals. Strict types end to end, no frontend/backend contract drift, tests at every layer.

**Out of scope for Phase 1:** AI assistant, MCP, RAG, Kubernetes, auth, containerising the apps (Docker is used only for Postgres for now).

---

## Architecture

pnpm monorepo:

```
subtrack-ai/
├── apps/
│   ├── api/            Fastify + TypeScript (REST, JSON)
│   └── web/            React + Vite + TypeScript
├── packages/
│   └── contracts/      Zod schemas + pure domain logic: the source of truth for API shapes
├── e2e/                Playwright tests (drive the real web + api)
├── docker-compose.yml  Postgres for local dev/test
├── biome.json, tsconfig.base.json, pnpm-workspace.yaml
└── .github/workflows/ci.yml
```

## Key decisions

| Area            | Choice                                                  | Why                                                                       |
| --------------- | ------------------------------------------------------- | ------------------------------------------------------------------------- |
| Package manager | pnpm workspaces (no Turborepo yet)                      | Simple and fast. Add orchestration only when needed.                      |
| Backend         | Fastify + `fastify-type-provider-zod`                   | Mature. Zod validates requests/responses at runtime and produces OpenAPI. |
| Database        | Postgres (Docker Compose) + Drizzle ORM, SQL migrations | Production-realistic. Postgres + pgvector suits the later RAG phase.      |
| Frontend        | React + Vite, TanStack Query, React Router              | Standard stack. TanStack Query handles server state.                      |
| Styling         | Tailwind CSS v4                                         | Clean UI without designing a CSS system.                                  |
| Lint/format     | Biome                                                   | Replaces ESLint + Prettier.                                               |
| Types           | TS `strict`, shared `tsconfig.base.json`                |                                                                           |
| Money           | Integer minor units (`amountMinor`) + ISO 4217 currency | Never floats for money.                                                   |

## Contract drift prevention (3 layers)

1. **Shared Zod schemas** in `packages/contracts`, imported by the API and the web forms, so a renamed field breaks compilation on both sides.
2. **Runtime validation:** Fastify validates every request _and response_ against the schemas.
3. **Generated OpenAPI** (`openapi.json`, committed). Web uses `openapi-typescript` + `openapi-fetch` for a typed client. CI regenerates the spec and fails if it differs from the committed file.

## Domain model

`Subscription`: `id`, `name`, `amountMinor`, `currency`, `billingCycle` (`weekly | monthly | yearly`), `nextRenewalDate`, `category`, `notes?`, `createdAt`, `updatedAt`.
No auth in Phase 1 (single user); structured so `userId` can be added later.

## Testing strategy

- **Unit (Vitest):** domain calculations, schema edge cases.
- **API integration (Vitest + Fastify `inject`):** against a real Postgres test database, no DB mocking.
- **Component (Vitest + React Testing Library):** forms and lists.
- **E2E (Playwright):** critical user journeys only, one or more per slice.
- **CI (GitHub Actions):** Biome → typecheck → unit/integration → OpenAPI drift check → E2E.

---

## Vertical slices

Each slice cuts through every layer (contracts → DB → API → OpenAPI → UI → tests) and ends with something a user can see working. Every slice is done only when **Definition of Done** holds:

> `pnpm check` (Biome + typecheck) passes · `pnpm test` passes · `pnpm e2e` passes · `openapi.json` is up to date · verification steps below work by hand.

### Slice 0 — Walking skeleton: "web talks to api talks to db"

Proves the whole pipeline end to end with the thinnest possible feature: a health indicator.

- [x] Workspace: `pnpm-workspace.yaml`, `tsconfig.base.json`, `.nvmrc` (Node 24), Biome config, root scripts (`dev`, `check`, `test`, `e2e`, `openapi:generate`, `openapi:check`)
- [x] `docker-compose.yml` with Postgres (dev + test databases)
- [x] `packages/contracts`: `HealthResponseSchema`
- [x] `apps/api`: Fastify app factory, env config (validated with Zod), Drizzle connection, `GET /health` reports API + DB status
- [x] OpenAPI generation script + drift check script
- [x] `apps/web`: Vite + React + Tailwind + TanStack Query + typed `openapi-fetch` client; app shell with header showing "API: ok / DB: ok"
- [x] Vite dev proxy `/api` → Fastify (no CORS needed in dev)
- [x] Tests: API integration test for `/health`; Playwright smoke test (page loads, status shows "ok")
- [x] CI workflow running the full Definition of Done
- [x] `README.md`: prerequisites, setup, commands

**Verify:** `pnpm install && pnpm db:up && pnpm dev` → open http://localhost:5173 → header shows API and DB healthy. Stop Postgres → status shows DB down.

### Slice 1 — View subscriptions list

- [x] Contracts: `SubscriptionSchema`, `BillingCycle`, `Currency`, money helpers (format minor units)
- [x] DB: `subscriptions` table + first Drizzle migration; seed script with sample data
- [x] API: `GET /subscriptions` (sorted by next renewal date)
- [x] Web: `/subscriptions` page with table (name, price, cycle, next renewal, category), loading, empty and error states
- [x] Tests: unit (money formatting), integration (list, empty list), component (empty state + rows), E2E (seeded data visible)

**Verify:** `pnpm db:seed` → open `/subscriptions` → seeded rows appear; `curl localhost:3000/subscriptions`.

### Slice 2 — Add a subscription

- [x] Contracts: `CreateSubscriptionRequestSchema` (name required, amount > 0, valid currency, valid date)
- [x] API: `POST /subscriptions` → 201, 400 with field errors on invalid input
- [x] Web: "Add subscription" form (react-hook-form + Zod resolver using the _shared_ schema), inline validation errors, list refreshes on success
- [x] Tests: unit (schema edge cases), integration (201 + 400 cases), component (validation messages), E2E (add → appears in list)

**Verify:** add a subscription in the UI; submit an empty form and see errors; `curl -X POST` with a bad body returns 400.

### Slice 3 — Edit a subscription

- [x] Contracts: `UpdateSubscriptionRequestSchema` (partial, at least one field)
- [x] API: `GET /subscriptions/:id`, `PATCH /subscriptions/:id` → 200 / 404 / 400
- [x] Web: edit page reusing the form component, pre-filled
- [x] Tests: integration (update, 404, invalid), E2E (edit price → list shows new price)

**Verify:** edit a subscription's price in the UI and see the list update.

### Slice 4 — Delete a subscription

- [x] API: `DELETE /subscriptions/:id` → 204 / 404
- [x] Web: delete action with confirmation dialog, list refreshes
- [x] Tests: integration (delete, 404), E2E (delete → row gone)

**Verify:** delete a subscription in the UI and see it removed after a refresh.

### Slice 5 — Dashboard: monthly spend

- [x] Contracts/domain: `toMonthlyMinor` / `toYearlyMinor`, `summarizeSpending(subs)` grouped by currency (no FX conversion in Phase 1); `SummaryResponseSchema`
- [x] API: `GET /summary` → monthly and yearly totals per currency, count, spend by category
- [x] Web: `/` dashboard with stat cards (monthly total, yearly total, active count) + spend-by-category breakdown
- [x] Tests: unit (cycle normalisation, multi-currency, rounding), integration (summary), E2E (add subscription → dashboard total increases)

**Verify:** dashboard totals match a hand calculation of the seeded data.

### Slice 6 — Dashboard: upcoming renewals

- [x] Domain: `upcomingRenewals(subs, today, days)`, `advanceRenewalDate` (roll past-due dates forward by cycle, including month-end edge cases such as 31 Jan → 28/29 Feb)
- [x] API: `GET /summary` includes renewals in the next 30 days (window configurable via query param)
- [x] Web: "Renewing soon" panel on the dashboard, highlighting items due within 7 days
- [x] Tests: unit (date edge cases with fixed "today"), integration, E2E (a subscription renewing tomorrow is shown and highlighted)

**Verify:** add a subscription renewing tomorrow and see it highlighted on the dashboard.

---

# Phase 2 — Quality & E2E

Phase 1 delivered the baseline (Playwright, one CI job, Biome recommended, OpenAPI regenerate-and-compare). Phase 2 turns each into a production-style quality gate. Each increment ends with `pnpm verify` green and a "break it on purpose" demo.

### Increment 1 — Biome as an architecture & quality gate

- [x] Stricter rules (unused imports/vars, non-null assertions, hook deps, no console outside scripts)
- [x] Import boundaries: web ↛ API/DB libs, contracts ↛ apps/frameworks, e2e ↛ app source
- [x] `biome ci` for CI (GitHub annotations)

### Increment 2 — Deeper contract-drift detection

- [x] Typed test doubles: web `mockApi` and E2E API client typed from the generated OpenAPI schema
- [x] OpenAPI lint (Redocly) + real response descriptions
- [x] Breaking-change detection (oasdiff) — `pnpm openapi:breaking`
- [x] Contract fuzzing (Schemathesis) — `pnpm contract:fuzz`; fix findings with regression tests

### Increment 3 — Playwright hardening

- [x] Fixtures with typed API client and auto-cleanup of arranged data
- [x] Accessibility scans (axe) on every page and the delete dialog
- [x] Failure-path tests (API down → error state → retry; unknown id)
- [x] Cross-browser projects (chromium, firefox, webkit, mobile); `pnpm e2e:all`
- [x] Failure diagnostics: traces, screenshots, HTML + JUnit reports

### Increment 4 — Coverage

- [x] `pnpm test:coverage` with per-project thresholds just below current actuals

### Increment 5 — CI pipeline

- [x] Parallel jobs: static, test (coverage + JUnit), e2e (browser matrix, cached browsers), contract (breaking + fuzz)
- [x] Concurrency, timeouts, caching; workflow validated locally with actionlint
- [x] README "Quality gates" section

---

# Phase 3 — UI redesign (TrackWise-AI)

From a reference screenshot (2026-10-28). Decisions: **built-in default exchange rates with custom overrides**, **automatic + editable payment history**, **Recharts** for charts; Analytics was merged into the Dashboard. User-facing name becomes TrackWise-AI; internal identifiers (`@subtrack/*` packages, `subtrack_*` databases) stay unchanged.

### Slice 3.1 — Rename, design system & app shell

- [x] Rename to **TrackWise-AI** in UI, page title, API title, README
- [x] Semantic colour tokens (CSS variables) with light + dark themes; toggle in header, follows the OS by default, remembered per browser, no flash on load
- [x] App shell: header (brand, theme toggle) + sidebar navigation with icons; collapses to a top bar on phones (Analytics/Settings links land with their slices)
- [x] Restyle existing pages on the tokens; KPI row adds **Avg per sub**
- [x] Tests: theme behaviour (component), axe + no-sideways-scroll in **both** themes (E2E), existing journeys still pass

### Slice 3.2 — Settings: primary currency & exchange rates

- [x] Settings + exchange-rate tables, API endpoints, Settings page to choose a primary currency and enter rates
- [x] Summary converts totals to the primary currency where a rate exists; amounts without a rate are listed separately (never guessed)
- [x] Tests: conversion maths (unit), endpoints (integration), set rate → dashboard total changes (E2E)

### Slice 3.3 — Payment history

- [x] Payments table; when a renewal date passes, record a payment and advance the next renewal (idempotent, catches up missed cycles)
- [x] Subscription detail page: payment history with edit/delete
- [x] Tests: catch-up/idempotency (unit + integration), edit a payment (E2E)

### Slice 3.4 — Analytics (Recharts) — merged into the Dashboard afterwards (they overlapped)

- [x] Spending trends (last 12 months, from payments), category breakdown, 6-month forecast, monthly expenditure (actual vs projected)
- [x] KPIs: Year-to-Date from payments; every chart has a data-table view and tooltips
- [x] Tests: series maths (unit), API (integration), charts render with expected values (E2E), axe

---

# Phase 4 — MCP without an LLM

Build a TypeScript MCP server and use MCP Inspector to discover and call subscription tools.

**Learning phase:** every step starts with the concept, then a small implementation, then you try it yourself in MCP Inspector before moving on.

**Architecture:** `apps/mcp` is an MCP server (official TypeScript SDK `@modelcontextprotocol/sdk`). It talks MCP (JSON-RPC 2.0) to a client over **stdio**, and calls the existing TrackWise **HTTP API** through a client typed from `openapi.json` — never the database directly, so validation, renewal processing and currency conversion are reused, and contract-drift checks cover the MCP server too.

### Step 4.1 — Hello MCP: the protocol, end to end

- [x] Concepts: client / server / transport; JSON-RPC 2.0; lifecycle `initialize` → `tools/list` → `tools/call`; capability negotiation
- [x] Scaffold `apps/mcp` (TypeScript, SDK, stdio transport) with one trivial `ping` tool
- [x] Gotcha: stdout carries protocol messages — all logging goes to stderr
- [x] **Try it:** `pnpm mcp:inspect` → Inspector UI → connect → watch the `initialize` handshake → list tools → call `ping`

### Step 4.2 — First real tool: `list_subscriptions`

- [x] Concepts: tool = name + description + **input schema** (Zod → JSON Schema) + result content
- [x] Typed API client for the MCP server, generated from `openapi.json` (added to `openapi:generate` / `openapi:check`)
- [x] Results as readable text **and** `structuredContent` (with an output schema) for programs
- [x] **Try it:** call it in Inspector against your dev data; compare the text vs structured results

### Step 4.3 — Designing tools for an AI (read-only)

- [x] Concepts: tools are read by a model — names, descriptions and parameter docs _are_ the interface; small focused tools; units the model can't misread (formatted money, ISO dates)
- [x] `get_spending_summary` (converted totals, average, paid this year, by category), `get_upcoming_renewals` (bounded `days` parameter), `get_subscription` (by id, with recent payments)
- [x] Code split by responsibility: `src/server.ts`, `src/api/{client,call}.ts`, `src/tools/{subscriptions,spending}.ts`; Biome boundary: the MCP server may not import DB libraries or app source
- [x] **Try it:** read each tool's generated JSON Schema in Inspector; try invalid inputs

### Step 4.4 — When things go wrong

- [x] Concepts: **tool errors** (`isError: true`, a message the model can act on) vs **protocol errors** (JSON-RPC error codes)
- [x] Map API down / 404 / validation errors to helpful tool errors (`fromApi` + `safely` in `src/api/call.ts`)
- [x] **Try it:** stop the API (`Ctrl-C`) and call a tool; call `get_subscription` with an unknown id

### Lessons learned so far (4.1–4.7)

- **Logs go to stderr.** Over stdio, stdout _is_ the protocol; one stray `console.log` breaks the session.
- **Check the JSON Schema a tool actually publishes**, not just the Zod you wrote: `CategorySchema` (registered with an OpenAPI id) became an unresolvable `$ref`; `z.enum(CategorySchema.options)` inlines the values.
- **Portability:** `nullable` publishes `type: ["string","null"]`, which some AI providers reject — `mcp-inspector --cli … --method tools/list --strict` catches this. We made `notes` optional instead.
- **Inspector doesn't pass your shell environment** to the server it spawns: use `-e TRACKWISE_API_URL=…`.
- **Invalid arguments are tool errors, not protocol errors** in current SDKs, so the model can read the message and retry; unknown tool names are protocol errors.
- **Format money for the model** (`$15.99`, not `1599` minor units) and include ids in text output so the model can chain tools (`list_subscriptions` → `get_subscription`).
- **Resources fail differently from tools:** no `isError` — a missing resource is a JSON-RPC error (`-32002`, "resource not found").
- **A prompt doesn't do the work**, it sets the model up: instructions that name the tools to use, plus resources attached as context.
- **Prompt arguments are always strings**; `completable()` adds suggestions (the category list) as the user types.
- **Consistency matters across primitives:** the first version of the subscription resource returned raw `amountMinor` while the tools showed formatted money — now both use one presenter.
- **Output schemas are enforced:** after moving formatting into `presentSubscription()`, it added `notes` that `list_subscriptions`' output schema didn't declare — the SDK rejected every call with `-32602` ("must NOT have additional properties"). The output schema must describe exactly what the handler returns; Step 4.7's tests will call every tool so a refactor can't silently break one.
- **Design inputs for how models actually send them:** `amount` was a string, and the first test call sent the number `149` — rejected before our code ran. It now accepts a number _or_ a string, both parsed as text by `parseMoney`.
- **Three validation layers, each with a fixable message:** the SDK checks the input schema (unknown currency), our tool checks the amount (`12.345` USD, `99.5` JPY), the API checks the contract (`2026-02-30`).
- **Annotations are hints, not security:** they let the client decide when to ask "Allow add_subscription?"; the API's validation is what protects the data.
- **Tests find what clicking doesn't:** the first test run showed prompt autocomplete had never worked — an SDK quirk (registration looks inside `.optional()`, the completion handler doesn't), invisible in Inspector because "no suggestions" looks normal.
- **Be precise about error kinds:** resources once reported _every_ failure as "not found" (-32002), including "API down". Now only a real 404 is -32002; other failures are internal errors (-32603) that keep the helpful message.

### Step 4.5 — Resources and prompts: the other two primitives

- [x] Concepts: tools = _model_ decides to call; resources = _app/user_ attaches context; prompts = _user_ picks a template
- [x] Resource `trackwise://subscriptions` and template `trackwise://subscriptions/{id}` (with `list`, so clients can enumerate concrete URIs) — `src/resources.ts`
- [x] Prompt `monthly-review` with an optional `focusCategory` argument (autocompleted via `completable`), pointing the model at the tools and attaching the subscription list as a `resource_link` — `src/prompts.ts`
- [x] Shared `presentSubscription()` (`src/present.ts`) so tools and resources describe a subscription identically
- [x] **Try it:** browse resources and render the prompt in Inspector

### Step 4.6 — A tool with side effects: `add_subscription`

- [x] Concepts: tool **annotations** (`readOnlyHint`, `destructiveHint`, `idempotentHint`, `openWorldHint`) and why hosts ask users to confirm writes — `src/annotations.ts`; every read tool is `READ_ONLY`, `add_subscription` is `CREATES`
- [x] `add_subscription`: plain inputs a model can't get wrong (decimal price + currency, YYYY-MM-DD date), converted with the shared `parseMoney`; the API's contract validation still applies; returns the created subscription
- [x] **Try it:** add a subscription from Inspector, then see it in the web app

### Step 4.7 — Testing an MCP server

- [x] Concepts: test without Inspector using the SDK's own `Client` and an in-memory transport (`InMemoryTransport.createLinkedPair()`) — same protocol, no processes, milliseconds
- [x] `createServer()` split from the stdio entry point so tests can connect it to an in-memory client
- [x] API stubbed with **typed** fetch mocks (generated from `openapi.json`), so a mock can't drift from the real API
- [x] **Client-level tests** for every tool, resource and prompt (success + failure paths, autocomplete) — `src/{tools,schemas,resources-prompts}.test.ts`
- [x] **Unit tests** for each helper — `presentSubscription`, `fromApi`, `safely`, annotations — `src/{present,annotations}.test.ts`, `src/api/call.test.ts`
- [x] **Regression tests** for every bug this phase hit: `$ref` category, nullable portability, `notes` output schema, number-vs-text `amount`, duplicate resource titles, raw minor units, completions never enabled
- [x] Runs in `pnpm test` / CI automatically; coverage gate for `apps/mcp` (≈98% lines; threshold 90%)
- [x] Gate: the server's typed API client is covered by `openapi:check`, so an API change can't silently break a tool

### Step 4.8 — (Optional) Streamable HTTP transport

- [ ] Concepts: stdio (local child process) vs Streamable HTTP (remote, many clients) — sets up Phase 7 (containers)
- [ ] Same server over HTTP; connect Inspector by URL instead of by command

**Done when:** every tool, resource and prompt works in MCP Inspector against the dev database, tests pass, and you can explain the lifecycle of a `tools/call` request.

# Phase 5 — LLM integration

Connect an AI to the MCP tools so it can answer natural-language questions about your subscriptions.

**Decisions (2026-10-29):** the whole app stays **free** — the in-app assistant uses a **local Ollama model** on your Mac (M1 Pro, 16 GB → a ~7–8B model with tool calling, e.g. Qwen 3 8B class). **A + B:** (A) connect the MCP server to Claude Code — uses your existing Claude Code plan, not the app; (B) build an **"Ask TrackWise"** assistant inside the web app. An `LlmProvider` interface keeps a paid model _possible_ later, but nothing requires one. Tests and CI use a **fake LLM** — never a real model.

**Architecture (B):**

```
Web chat ──► apps/assistant (agent loop) ──► Ollama (local model)
                  │  ▲                         │ "call get_spending_summary"
                  │  └──── tool results ◄──────┘
                  └──► MCP client ──stdio──► apps/mcp ──HTTP──► TrackWise API
```

### Step 5.1 — (A) Use TrackWise from Claude Code

- [x] Concepts: MCP **hosts** and how they start servers; config scopes (project `.mcp.json` vs user)
- [x] Register the server for this project; check it connects (`/mcp`) — `.mcp.json` at the repo root (stdio, `pnpm --dir apps/mcp exec tsx src/server.ts`); your approval is stored in `.claude/settings.local.json`. Needs a **new** `claude` session to show up.
- [x] **Try it:** tools, `@` resources and `/mcp__trackwise__monthly-review` all visible. Still worth trying: ask about your subscriptions in plain words; run `/mcp__trackwise__monthly-review`; attach `@trackwise:` resources; see Claude Code ask before `add_subscription` (the Step 4.6 annotations at work)

### Step 5.2 — A local model with Ollama

- [ ] Concepts: running a model locally — model size vs memory, quantization, context window, speed (tokens/second); what "tool calling" means for a model
- [ ] Install Ollama, pull a tool-calling model that fits 16 GB, and check it can call a tool in a hello-world request
- [ ] **Try it:** chat with the model in the terminal; watch memory use

### Step 5.3 — The assistant service and its MCP client

- [ ] Concepts: being on the **client** side of MCP — what Inspector and Claude Code do internally
- [ ] `apps/assistant` (Fastify): starts `apps/mcp` over stdio, lists its tools and converts them into the model's tool format
- [ ] **Try it:** a debug endpoint listing the tools exactly as the model will see them

### Step 5.4 — The agent loop

- [ ] Concepts: the loop — model asks for a tool → we run it via MCP → result goes back → repeat until it answers; a step limit so it can't loop forever; the **system prompt** (role, today's date, primary currency, "confirm before adding")
- [ ] `LlmProvider` interface with an **Ollama** implementation and a **fake** one for tests
- [ ] **Try it:** ask a question from the terminal and print each step (thought → tool call → result → answer)

### Step 5.5 — Streaming chat API

- [ ] Concepts: streaming responses (Server-Sent Events) so words appear as they are generated; sending "calling tool…" progress events
- [ ] `POST /chat` streams text and tool-call events; the conversation history comes with each request
- [ ] **Try it:** `curl` the endpoint and watch the stream

### Step 5.6 — Asking before changing data

- [ ] Concepts: human-in-the-loop — use the tools' annotations: read-only tools run immediately, `add_subscription` pauses for approval
- [ ] Approval events in the stream; the loop resumes after approve/deny
- [ ] **Try it:** "add YouTube Premium for ₹149 a month" → approve → it appears in the app

### Step 5.7 — "Ask TrackWise" in the web app

- [ ] Concepts: chat UI patterns — streaming text, tool activity, approval cards, starter questions
- [ ] Assistant page in the sidebar: messages, live tool chips ("Checking your spending…"), approve/deny card for writes, a **Monthly review** button that uses the MCP prompt
- [ ] **Try it:** use it for real; compare answers with the dashboard

### Step 5.8 — Testing and quality

- [ ] Unit tests: tool conversion, loop and step limit, approval flow, stream events — with the fake LLM
- [ ] Integration tests for the assistant API (fake LLM + real MCP server + test API); an E2E journey with the fake LLM (no model needed in CI)
- [ ] A small **manual quality checklist** of standard questions to run against the real local model, since a local model's answers can't be unit-tested

**Done when:** you can ask TrackWise questions in the app (and in Claude Code), it answers from your real data, asks before adding anything, everything runs locally for free, and tests pass without any model installed.

# Phase 6 — RAG

Search subscription policies and cancellation documents to answer questions with evidence.

# Phase 7 — Docker + Kubernetes

Containerize and deploy the app locally using kind.

# Phase 8 — Portfolio polish

Architecture diagrams, tests, README, demo, and GitHub documentation.

---

## Not planned yet

Auth & multi-user.
