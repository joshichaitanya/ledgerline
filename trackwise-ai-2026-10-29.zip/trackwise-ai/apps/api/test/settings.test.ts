import {
  ErrorResponseSchema,
  ExchangeRatesResponseSchema,
  SettingsSchema,
  SummaryResponseSchema,
} from "@subtrack/contracts";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";
import { appSettings, exchangeRates, subscriptions } from "../src/db/schema";
import { testDatabaseUrl } from "./test-database";

const database = createDatabase(testDatabaseUrl);
const app = await buildApp({ database });

const rates = async () =>
  ExchangeRatesResponseSchema.parse(
    (await app.inject({ method: "GET", url: "/exchange-rates" })).json(),
  );
const putRate = (currency: string, rate: number) =>
  app.inject({ method: "PUT", url: `/exchange-rates/${currency}`, payload: { rate } });
const putPrimary = (primaryCurrency: string) =>
  app.inject({ method: "PUT", url: "/settings", payload: { primaryCurrency } });

beforeEach(async () => {
  await database.db.delete(subscriptions);
  await database.db.delete(exchangeRates);
  await database.db.delete(appSettings);
});

afterAll(async () => {
  await app.close();
  await database.close();
});

describe("settings", () => {
  it("defaults the primary currency to USD", async () => {
    const response = await app.inject({ method: "GET", url: "/settings" });

    expect(SettingsSchema.parse(response.json())).toEqual({ primaryCurrency: "USD" });
  });

  it("changes the primary currency when there are no rates", async () => {
    expect((await putPrimary("EUR")).json()).toEqual({ primaryCurrency: "EUR" });
    expect((await app.inject({ method: "GET", url: "/settings" })).json()).toEqual({
      primaryCurrency: "EUR",
    });
  });

  it("re-expresses existing rates against the new primary currency", async () => {
    await putRate("EUR", 1.08);
    await putRate("JPY", 0.0067);

    const response = await putPrimary("EUR");

    expect(response.statusCode).toBe(200);
    const after = await rates();
    expect(after.primaryCurrency).toBe("EUR");
    expect(after.items.map(({ currency, rate }) => [currency, rate])).toEqual([
      ["JPY", 0.006203703704],
      ["USD", 0.9259259259],
    ]);
  });

  it("rebases custom rates through a built-in default when needed", async () => {
    await putRate("EUR", 1.1);

    const response = await putPrimary("GBP"); // GBP has no custom rate, but a default ($1.33)

    expect(response.statusCode).toBe(200);
    const after = await rates();
    // €1 = $1.10 = £(1.10 ÷ 1.33). USD isn't stored as custom: its default still applies.
    expect(after.items.map(({ currency, rate }) => [currency, rate])).toEqual([
      ["EUR", 0.8270676692],
    ]);
  });

  it("refuses (409) to switch to a currency with neither a custom nor a built-in rate", async () => {
    await putRate("EUR", 1.08);

    const response = await putPrimary("ISK");

    expect(response.statusCode).toBe(409);
    expect(ErrorResponseSchema.parse(response.json()).error).toBe("RateRequired");
    expect((await rates()).primaryCurrency).toBe("USD");
    expect((await rates()).items).toHaveLength(1);
  });
});

describe("exchange rates", () => {
  it("lists built-in defaults alongside custom rates", async () => {
    const listing = await rates();

    expect(listing.items).toEqual([]);
    expect(listing.defaultsAsOf).toBe("2026-10");
    expect(listing.defaults).toContainEqual({ currency: "EUR", rate: 1.16 });
    expect(listing.defaults.some((d) => d.currency === "USD")).toBe(false); // the primary
  });

  it("creates, updates and deletes a rate", async () => {
    expect((await putRate("EUR", 1.08)).statusCode).toBe(200);
    expect((await putRate("EUR", 1.1)).json()).toMatchObject({ currency: "EUR", rate: 1.1 });
    expect((await rates()).items).toHaveLength(1);

    const deleted = await app.inject({ method: "DELETE", url: "/exchange-rates/EUR" });
    expect(deleted.statusCode).toBe(204);
    expect((await rates()).items).toEqual([]);
  });

  it.each([
    ["the primary currency itself", "USD", 1, "PrimaryCurrencyRate"],
    ["a zero rate", "EUR", 0, "ValidationError"],
    ["an unknown currency", "XYZ", 1, "ValidationError"],
  ])("rejects %s", async (_case, currency, rate, error) => {
    const response = await putRate(currency, rate);

    expect(response.statusCode).toBe(400);
    expect(ErrorResponseSchema.parse(response.json()).error).toBe(error);
  });

  it("returns 404 when deleting a rate that doesn't exist", async () => {
    const response = await app.inject({ method: "DELETE", url: "/exchange-rates/EUR" });

    expect(response.statusCode).toBe(404);
  });
});

describe("summary conversion", () => {
  const base = {
    name: "Netflix",
    amountMinor: 1599,
    currency: "USD" as const,
    billingCycle: "monthly" as const,
    category: "streaming" as const,
    nextRenewalDate: "2099-01-01",
  };

  it("converts currencies with a rate and lists the rest separately", async () => {
    await database.db.insert(subscriptions).values([
      base,
      { ...base, name: "Disney+", amountMinor: 999, currency: "EUR" },
      // ISK is outside the built-in table: without a custom rate it can't be converted.
      { ...base, name: "Icelandic", amountMinor: 2400, currency: "ISK", billingCycle: "yearly" },
    ]);
    await putRate("EUR", 1.1);

    const summary = SummaryResponseSchema.parse(
      (await app.inject({ method: "GET", url: "/summary" })).json(),
    );

    // $15.99 + €9.99 × 1.1 ($10.99) = $26.98/mo; ISK has no rate
    expect(summary.converted).toMatchObject({
      currency: "USD",
      subscriptionCount: 2,
      monthlyMinor: 2698,
      averageMonthlyMinor: 1349,
      unconvertedCurrencies: ["ISK"],
    });
  });

  it("uses the built-in default where there is no custom rate", async () => {
    await database.db
      .insert(subscriptions)
      .values([base, { ...base, name: "Disney+", amountMinor: 999, currency: "EUR" }]);

    const summary = SummaryResponseSchema.parse(
      (await app.inject({ method: "GET", url: "/summary" })).json(),
    );

    // $191.88/yr + €119.88 × 1.16 ($139.06) = $330.94/yr → $27.58/mo
    expect(summary.converted).toMatchObject({
      subscriptionCount: 2,
      yearlyMinor: 33_094,
      monthlyMinor: 2758,
      unconvertedCurrencies: [],
    });
  });
});
