import { screen } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { Route, Routes } from "react-router";
import { describe, expect, it } from "vitest";
import { aSubscription } from "../test/fixtures";
import { mockApi, requestsOf, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { EditSubscriptionPage } from "./EditSubscriptionPage";

function renderAt(id: string) {
  renderWithQueryClient(
    <Routes>
      <Route path="/subscriptions/:id/edit" element={<EditSubscriptionPage />} />
      <Route path="/subscriptions" element={<p>Subscriptions list</p>} />
    </Routes>,
    { route: `/subscriptions/${id}/edit` },
  );
}

describe("EditSubscriptionPage", () => {
  it("pre-fills the form, saves a PATCH, then returns to the list", async () => {
    const subscription = aSubscription({ notes: "Family plan" });
    let patchBody: unknown;
    const fetchMock = mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body: subscription })),
      route("patch", "/subscriptions/{id}").reply(async ({ request }) => {
        patchBody = await request.json();
        return { status: 200, body: { ...subscription, amountMinor: 1799 } };
      }),
    );
    const user = userEvent.setup();

    renderAt(subscription.id);

    const amount = await screen.findByLabelText("Amount");
    expect(screen.getByRole("heading", { name: "Edit Netflix" })).toBeInTheDocument();
    expect(amount).toHaveValue("15.99");
    expect(screen.getByLabelText("Notes (optional)")).toHaveValue("Family plan");

    await user.clear(amount);
    await user.type(amount, "17.99");
    await user.click(screen.getByRole("button", { name: "Save changes" }));

    expect(await screen.findByText("Subscriptions list")).toBeInTheDocument();
    expect(patchBody).toMatchObject({ amountMinor: 1799, notes: "Family plan" });
    expect(requestsOf(fetchMock)).toContain(`PATCH /subscriptions/${subscription.id}`);
  });

  it("shows not found for an unknown subscription", async () => {
    const id = crypto.randomUUID();
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({
        status: 404,
        body: { error: "NotFound", message: "Subscription not found" },
      })),
    );

    renderAt(id);

    expect(await screen.findByRole("alert")).toHaveTextContent("Subscription not found.");
  });
});
