import { vi } from "vitest";
import type { paths } from "../api/schema.gen";

// Typed fetch stubs for the TrackWise API (same idea as apps/web/src/test/mock-api.ts):
// every reply is checked against the generated OpenAPI types, so a mock can't drift from the API.

type Path = keyof paths;
type Method<P extends Path> = {
  [M in keyof paths[P]]: paths[P][M] extends { responses: unknown } ? M : never;
}[keyof paths[P]] &
  string;
type Responses<P extends Path, M extends Method<P>> = paths[P][M] extends { responses: infer R }
  ? R
  : never;
type JsonBody<R> = R extends { content: { "application/json": infer Body } } ? Body : undefined;

export type Reply<P extends Path, M extends Method<P>> = {
  [S in keyof Responses<P, M>]: undefined extends JsonBody<Responses<P, M>[S]>
    ? { status: S; body?: undefined }
    : { status: S; body: JsonBody<Responses<P, M>[S]> };
}[keyof Responses<P, M>];

interface MockRoute {
  method: string;
  matches: (pathname: string) => Record<string, string> | undefined;
  handle: (context: { params: Record<string, string>; request: Request }) => Promise<Response>;
}

/** `route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body }))` */
export function route<P extends Path, M extends Method<P>>(method: M, path: P) {
  const names: string[] = [];
  const pattern = new RegExp(
    `^${String(path).replace(/\{(\w+)\}/g, (_match, name: string) => {
      names.push(name);
      return "([^/]+)";
    })}$`,
  );
  return {
    reply(
      handler: (context: {
        params: Record<string, string>;
        request: Request;
      }) => Reply<P, M> | Promise<Reply<P, M>>,
    ): MockRoute {
      return {
        method: method.toUpperCase(),
        matches: (pathname) => {
          const match = pattern.exec(pathname);
          return match
            ? Object.fromEntries(names.map((name, index) => [name, match[index + 1] ?? ""]))
            : undefined;
        },
        handle: async (context) => {
          const reply = (await handler(context)) as { status: number; body?: unknown };
          return reply.body === undefined
            ? new Response(null, { status: reply.status })
            : Response.json(reply.body, { status: reply.status });
        },
      };
    },
  };
}

/** Stubs fetch with the given routes; unmatched requests fail loudly. Returns the mock. */
export function mockApi(...routes: MockRoute[]) {
  const fetchMock = vi.fn(async (request: Request) => {
    const { pathname } = new URL(request.url);
    for (const candidate of routes) {
      const params = candidate.method === request.method && candidate.matches(pathname);
      if (params) return candidate.handle({ params, request });
    }
    throw new Error(`Unexpected request: ${request.method} ${pathname}`);
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

/** Simulates the API not running. */
export function mockApiDown() {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => {
      throw new TypeError("fetch failed");
    }),
  );
}
