import {
  convertSpending,
  ErrorResponseSchema,
  SummaryQuerySchema,
  SummaryResponseSchema,
  summarizeSpending,
  toIsoDate,
  upcomingRenewals,
} from "@subtrack/contracts";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type { Database } from "../db/client";
import { getSettings, loadEffectiveRates } from "../settings/repository";
import { processDueRenewals } from "../subscriptions/renewals";
import { listSubscriptions } from "../subscriptions/repository";

export const summaryRoutes: FastifyPluginAsyncZod<{ database: Database; now: () => Date }> = async (
  app,
  { database, now },
) => {
  app.get(
    "/summary",
    {
      schema: {
        operationId: "getSummary",
        tags: ["summary"],
        summary: "Spending totals per currency and category, plus upcoming renewals",
        querystring: SummaryQuerySchema,
        response: {
          200: SummaryResponseSchema.describe("Spending totals and upcoming renewals"),
          400: ErrorResponseSchema.describe("Invalid query parameter"),
        },
      },
    },
    // Aggregated in TypeScript: fine at personal scale, and the rules stay in one tested place.
    async (request) => {
      await processDueRenewals(database, toIsoDate(now()));
      const [subscriptions, settings] = await Promise.all([
        listSubscriptions(database),
        getSettings(database),
      ]);
      const rates = await loadEffectiveRates(database, settings.primaryCurrency);
      const spending = summarizeSpending(subscriptions);
      return {
        ...spending,
        converted: convertSpending(spending.spendByCurrency, settings.primaryCurrency, rates),
        upcomingRenewals: upcomingRenewals(
          subscriptions,
          toIsoDate(now()),
          request.query.renewalWindowDays,
        ),
      };
    },
  );
};
