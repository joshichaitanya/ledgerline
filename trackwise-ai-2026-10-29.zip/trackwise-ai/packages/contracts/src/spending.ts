import { z } from "zod";
import { DEFAULT_RENEWAL_WINDOW_DAYS, UpcomingRenewalsSchema } from "./renewals";
import { convertMinor, type RateTable } from "./settings";
import {
  type BillingCycle,
  CategorySchema,
  type Currency,
  CurrencySchema,
  type Subscription,
} from "./subscription";

/** Convention: a year has 52 billing weeks. */
export const WEEKS_PER_YEAR = 52;

/** Exact yearly cost in minor units; integer arithmetic only. */
export function toYearlyMinor(amountMinor: number, billingCycle: BillingCycle): number {
  switch (billingCycle) {
    case "weekly":
      return amountMinor * WEEKS_PER_YEAR;
    case "monthly":
      return amountMinor * 12;
    case "yearly":
      return amountMinor;
  }
}

/** Monthly equivalent in minor units, rounded to the nearest minor unit. */
export function toMonthlyMinor(amountMinor: number, billingCycle: BillingCycle): number {
  return Math.round(toYearlyMinor(amountMinor, billingCycle) / 12);
}

const count = z.int().nonnegative();
const minor = z.int().nonnegative();

export const CategorySpendSchema = z
  .object({
    category: CategorySchema,
    subscriptionCount: count,
    monthlyMinor: minor,
    yearlyMinor: minor,
  })
  .meta({ id: "CategorySpend" });

export const CurrencySpendSchema = z
  .object({
    currency: CurrencySchema,
    subscriptionCount: count,
    monthlyMinor: minor,
    yearlyMinor: minor,
    /** Highest spend first. */
    byCategory: z.array(CategorySpendSchema),
  })
  .meta({ id: "CurrencySpend" });

/** All currencies converted to the primary currency (where a rate exists) and merged. */
export const ConvertedSpendSchema = z
  .object({
    /** The primary currency. */
    currency: CurrencySchema,
    /** Subscriptions included in these totals (those in convertible currencies). */
    subscriptionCount: count,
    monthlyMinor: minor,
    yearlyMinor: minor,
    averageMonthlyMinor: minor,
    /** Highest spend first. */
    byCategory: z.array(CategorySpendSchema),
    /** Currencies with subscriptions but no exchange rate: excluded here, never guessed. */
    unconvertedCurrencies: z.array(CurrencySchema),
  })
  .meta({ id: "ConvertedSpend" });

export const SummaryResponseSchema = z
  .object({
    subscriptionCount: count,
    /** One entry per currency (no FX conversion); most subscriptions first. */
    spendByCurrency: z.array(CurrencySpendSchema),
    converted: ConvertedSpendSchema,
    upcomingRenewals: UpcomingRenewalsSchema,
  })
  .meta({ id: "SummaryResponse" });

export const SummaryQuerySchema = z.object({
  /** How many days ahead to list renewals (1–365). */
  renewalWindowDays: z.coerce
    .number()
    .int("Must be a whole number of days")
    .min(1, "Must be between 1 and 365")
    .max(365, "Must be between 1 and 365")
    .default(DEFAULT_RENEWAL_WINDOW_DAYS),
});

export type CategorySpend = z.infer<typeof CategorySpendSchema>;
export type CurrencySpend = z.infer<typeof CurrencySpendSchema>;
export type SummaryResponse = z.infer<typeof SummaryResponseSchema>;
export type ConvertedSpend = z.infer<typeof ConvertedSpendSchema>;
export type SpendingSummary = Pick<SummaryResponse, "subscriptionCount" | "spendByCurrency">;

type Spendable = Pick<Subscription, "amountMinor" | "currency" | "billingCycle" | "category">;

interface Accumulator {
  subscriptionCount: number;
  yearlyMinor: number;
}

/**
 * Totals per currency and category. Sums exact yearly amounts and derives monthly
 * figures once per total, so rounding never accumulates across subscriptions.
 */
export function summarizeSpending(subscriptions: readonly Spendable[]): SpendingSummary {
  const currencies = new Map<
    Currency,
    Accumulator & { categories: Map<CategorySpend["category"], Accumulator> }
  >();

  for (const { amountMinor, currency, billingCycle, category } of subscriptions) {
    const yearly = toYearlyMinor(amountMinor, billingCycle);
    const currencyTotal = currencies.get(currency) ?? {
      subscriptionCount: 0,
      yearlyMinor: 0,
      categories: new Map(),
    };
    const categoryTotal = currencyTotal.categories.get(category) ?? {
      subscriptionCount: 0,
      yearlyMinor: 0,
    };
    currencyTotal.subscriptionCount += 1;
    currencyTotal.yearlyMinor += yearly;
    categoryTotal.subscriptionCount += 1;
    categoryTotal.yearlyMinor += yearly;
    currencyTotal.categories.set(category, categoryTotal);
    currencies.set(currency, currencyTotal);
  }

  const spendByCurrency = [...currencies]
    .map(([currency, total]) => ({
      currency,
      subscriptionCount: total.subscriptionCount,
      ...amounts(total.yearlyMinor),
      byCategory: [...total.categories]
        .map(([category, categoryTotal]) => ({
          category,
          subscriptionCount: categoryTotal.subscriptionCount,
          ...amounts(categoryTotal.yearlyMinor),
        }))
        .sort((a, b) => b.yearlyMinor - a.yearlyMinor || a.category.localeCompare(b.category)),
    }))
    .sort(
      (a, b) => b.subscriptionCount - a.subscriptionCount || a.currency.localeCompare(b.currency),
    );

  return { subscriptionCount: subscriptions.length, spendByCurrency };
}

function amounts(yearlyMinor: number) {
  return { monthlyMinor: Math.round(yearlyMinor / 12), yearlyMinor };
}

/**
 * Merges per-currency spend into the primary currency. Yearly totals are converted (exact
 * integers in, one rounding per conversion) and monthly figures derived once per total.
 */
export function convertSpending(
  spendByCurrency: readonly CurrencySpend[],
  primary: Currency,
  rates: RateTable,
): ConvertedSpend {
  let subscriptionCount = 0;
  let yearlyMinor = 0;
  const categories = new Map<CategorySpend["category"], Accumulator>();
  const unconvertedCurrencies: Currency[] = [];

  for (const spend of spendByCurrency) {
    const yearly = convertMinor(spend.yearlyMinor, spend.currency, primary, rates);
    if (yearly === undefined) {
      unconvertedCurrencies.push(spend.currency);
      continue;
    }
    subscriptionCount += spend.subscriptionCount;
    yearlyMinor += yearly;
    for (const item of spend.byCategory) {
      const total = categories.get(item.category) ?? { subscriptionCount: 0, yearlyMinor: 0 };
      total.subscriptionCount += item.subscriptionCount;
      total.yearlyMinor += convertMinor(item.yearlyMinor, spend.currency, primary, rates) ?? 0;
      categories.set(item.category, total);
    }
  }

  const { monthlyMinor } = amounts(yearlyMinor);
  return {
    currency: primary,
    subscriptionCount,
    monthlyMinor,
    yearlyMinor,
    averageMonthlyMinor: subscriptionCount === 0 ? 0 : Math.round(monthlyMinor / subscriptionCount),
    byCategory: [...categories]
      .map(([category, total]) => ({
        category,
        subscriptionCount: total.subscriptionCount,
        ...amounts(total.yearlyMinor),
      }))
      .sort((a, b) => b.yearlyMinor - a.yearlyMinor || a.category.localeCompare(b.category)),
    unconvertedCurrencies: unconvertedCurrencies.sort(),
  };
}
