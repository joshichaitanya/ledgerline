import { CategorySchema } from "@subtrack/contracts";
import { useEffect, useState } from "react";

export interface ChartColors {
  series: string;
  current: string;
  projected: string;
  grid: string;
  axis: string;
  surface: string;
  categories: string[];
}

/** Charts draw in SVG attributes, so read the theme's CSS variables as concrete colours. */
function readColors(): ChartColors {
  const style = getComputedStyle(document.documentElement);
  const read = (name: string) => style.getPropertyValue(name).trim();
  return {
    series: read("--chart-1"),
    current: read("--chart-current"),
    projected: read("--chart-projected"),
    grid: read("--line"),
    axis: read("--ink-subtle"),
    surface: read("--surface"),
    categories: Array.from({ length: 8 }, (_, index) => read(`--cat-${index + 1}`)),
  };
}

/** Theme-aware chart colours; re-read when the theme toggles (the `dark` class on <html>). */
export function useChartColors(): ChartColors {
  const [colors, setColors] = useState(readColors);
  useEffect(() => {
    const observer = new MutationObserver(() => setColors(readColors()));
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);
  return colors;
}

const CATEGORY_SLOTS = CategorySchema.options;

/** Colour follows the category, never its rank: each category owns a fixed palette slot. */
export function categoryColor(colors: ChartColors, category: string): string {
  const slot = CATEGORY_SLOTS.indexOf(category as (typeof CATEGORY_SLOTS)[number]);
  return colors.categories[slot] ?? colors.projected;
}
