import {
  type Currency,
  type ExchangeRate,
  effectiveRates,
  type RateTable,
  rebaseRates,
  referenceRate,
  type Settings,
} from "@subtrack/contracts";
import { asc, eq } from "drizzle-orm";
import type { Database } from "../db/client";
import { appSettings, exchangeRates } from "../db/schema";

export const DEFAULT_SETTINGS: Settings = { primaryCurrency: "USD" };

export async function getSettings({ db }: Database): Promise<Settings> {
  const [row] = await db.select().from(appSettings);
  return row ? { primaryCurrency: row.primaryCurrency } : DEFAULT_SETTINGS;
}

export async function listRates({ db }: Database): Promise<ExchangeRate[]> {
  const rows = await db.select().from(exchangeRates).orderBy(asc(exchangeRates.currency));
  return rows.map((row) => ({ ...row, updatedAt: row.updatedAt.toISOString() }));
}

/** The user's own rates only. */
export async function loadRateTable(database: Database): Promise<RateTable> {
  return new Map((await listRates(database)).map((rate) => [rate.currency, rate.rate]));
}

/** What conversions use: built-in defaults, overridden by the user's own rates. */
export async function loadEffectiveRates(
  database: Database,
  primary: Currency,
): Promise<RateTable> {
  return effectiveRates(primary, await loadRateTable(database));
}

export async function setRate(
  { db }: Database,
  currency: Currency,
  rate: number,
): Promise<ExchangeRate> {
  const [row] = await db
    .insert(exchangeRates)
    .values({ currency, rate })
    .onConflictDoUpdate({ target: exchangeRates.currency, set: { rate, updatedAt: new Date() } })
    .returning();
  if (!row) throw new Error("Upsert returned no row");
  return { ...row, updatedAt: row.updatedAt.toISOString() };
}

/** Returns false when there was no rate for this currency. */
export async function deleteRate({ db }: Database, currency: Currency): Promise<boolean> {
  const deleted = await db
    .delete(exchangeRates)
    .where(eq(exchangeRates.currency, currency))
    .returning({ currency: exchangeRates.currency });
  return deleted.length > 0;
}

export type ChangePrimaryResult =
  | { ok: true; settings: Settings }
  | { ok: false; missingRate: Currency };

/**
 * Changes the primary currency and re-expresses every rate against it, atomically.
 * Fails (changing nothing) if the new primary has no rate to rebase through.
 */
export async function changePrimaryCurrency(
  database: Database,
  primaryCurrency: Currency,
): Promise<ChangePrimaryResult> {
  return database.db.transaction(async (tx) => {
    const [settingsRow] = await tx.select().from(appSettings);
    const currentPrimary = settingsRow?.primaryCurrency ?? DEFAULT_SETTINGS.primaryCurrency;
    const rates = new Map(
      (await tx.select().from(exchangeRates)).map((row) => [row.currency, row.rate]),
    );
    // Custom rates are re-expressed through the new primary's rate: the user's own if set,
    // otherwise the built-in default. Only an unknown currency with custom rates is refused.
    const viaDefault = !rates.has(primaryCurrency);
    if (viaDefault) {
      const fallback = referenceRate(primaryCurrency, currentPrimary);
      if (fallback !== undefined) rates.set(primaryCurrency, fallback);
    }
    const rebased =
      rates.size === 0 || (viaDefault && rates.size === 1 && rates.has(primaryCurrency))
        ? new Map<Currency, number>()
        : rebaseRates(rates, currentPrimary, primaryCurrency);
    if (!rebased) return { ok: false, missingRate: primaryCurrency };
    // Don't turn a default into a "custom" rate for the old primary: its default still applies.
    if (viaDefault && referenceRate(currentPrimary, primaryCurrency) !== undefined) {
      rebased.delete(currentPrimary);
    }

    await tx.delete(exchangeRates);
    if (rebased.size > 0) {
      await tx
        .insert(exchangeRates)
        .values([...rebased].map(([currency, rate]) => ({ currency, rate })));
    }
    await tx
      .insert(appSettings)
      .values({ id: true, primaryCurrency })
      .onConflictDoUpdate({ target: appSettings.id, set: { primaryCurrency } });
    return { ok: true, settings: { primaryCurrency } };
  });
}
