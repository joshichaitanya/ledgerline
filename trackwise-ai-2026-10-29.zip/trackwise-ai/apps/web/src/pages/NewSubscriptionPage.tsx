import { useNavigate } from "react-router";
import { useCreateSubscription } from "../api/subscriptions";
import { PageHeader } from "../components/PageHeader";
import { SubscriptionForm } from "../components/SubscriptionForm";
import { emptyFormValues } from "../lib/subscription-form";

export function NewSubscriptionPage() {
  const navigate = useNavigate();
  const create = useCreateSubscription();

  return (
    <section className="max-w-2xl space-y-6">
      <PageHeader title="Add subscription" description="Track a new recurring payment." />
      <SubscriptionForm
        defaultValues={emptyFormValues}
        submitLabel="Add subscription"
        onSubmit={(request) =>
          create.mutate(request, { onSuccess: () => navigate("/subscriptions") })
        }
        isSubmitting={create.isPending}
        submitError={create.error}
      />
    </section>
  );
}
