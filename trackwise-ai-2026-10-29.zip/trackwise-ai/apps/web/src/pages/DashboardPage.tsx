import { formatMoney, minorUnitDigits } from "@subtrack/contracts";
import { Info } from "lucide-react";
import { Link } from "react-router";
import { useAnalytics } from "../api/analytics";
import { type CurrencySpend, useSummary } from "../api/summary";
import {
  CategoryDonut,
  CategoryLegend,
  ChartCard,
  DataTable,
  ExpenditureBarChart,
  ExpenditureLegend,
  expenditureNote,
  MonthlyLineChart,
} from "../components/charts";
import { PageHeader } from "../components/PageHeader";
import { RenewingSoon } from "../components/RenewingSoon";
import { StatTile } from "../components/StatTile";
import { useChartColors } from "../lib/chart-colors";
import { categoryLabel, formatMonth } from "../lib/format";

export function DashboardPage() {
  return (
    <section className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="Your spending, trends and upcoming renewals at a glance."
      />
      <DashboardContent />
    </section>
  );
}

function DashboardContent() {
  const summary = useSummary();
  const analytics = useAnalytics();
  const colors = useChartColors();

  if (summary.isPending || analytics.isPending) {
    return (
      <p role="status" className="text-ink-subtle">
        Loading dashboard…
      </p>
    );
  }

  if (summary.isError || analytics.isError) {
    const isFetching = summary.isFetching || analytics.isFetching;
    return (
      <div
        role="alert"
        className="rounded-lg border border-danger-line bg-danger-soft p-4 text-danger-ink"
      >
        <p>Couldn't load the dashboard.</p>
        <button
          type="button"
          onClick={() => {
            summary.refetch();
            analytics.refetch();
          }}
          disabled={isFetching}
          className="mt-2 rounded-md bg-danger px-3 py-1.5 text-sm font-medium text-white hover:bg-danger-hover disabled:opacity-50"
        >
          {isFetching ? "Retrying…" : "Retry"}
        </button>
      </div>
    );
  }

  if (summary.data.subscriptionCount === 0) {
    return (
      <div className="rounded-lg border border-dashed border-line-strong bg-surface p-8 text-center">
        <p className="font-medium">No subscriptions yet.</p>
        <p className="mt-1 text-sm text-ink-subtle">
          <Link to="/subscriptions/new" className="text-accent-ink underline">
            Add a subscription
          </Link>{" "}
          to see your spending here.
        </p>
      </div>
    );
  }

  const { converted } = summary.data;
  const trends = analytics.data;
  const primary = converted.currency;
  const digits = minorUnitDigits(primary);
  const money = (minor: number) => formatMoney(minor, primary);
  // Currencies without an exchange rate are shown in their own currency, never guessed.
  const unconverted = summary.data.spendByCurrency.filter((spend) =>
    converted.unconvertedCurrencies.includes(spend.currency),
  );
  const missingRates = [
    ...new Set([...converted.unconvertedCurrencies, ...trends.unconvertedCurrencies]),
  ].sort();
  const usesConversion = summary.data.spendByCurrency.some(
    (spend) => spend.currency !== primary && !missingRates.includes(spend.currency),
  );
  const unconvertedLines = (pick: (spend: CurrencySpend) => number) =>
    unconverted.map((spend) => `+ ${formatMoney(pick(spend), spend.currency)} (no rate)`);

  return (
    <>
      {(usesConversion || missingRates.length > 0) && (
        <div className="flex items-start gap-2 text-sm text-ink-muted">
          <Info aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-accent-ink" />
          <p>
            {usesConversion && (
              <>
                Amounts in other currencies are converted to {primary} using exchange rates
                (built-in approximate defaults unless you set your own).{" "}
              </>
            )}
            {missingRates.length > 0 && (
              <>
                No rate for {missingRates.join(", ")}: shown separately, not included in totals or
                charts.{" "}
              </>
            )}
            <Link to="/settings" className="text-accent-ink underline">
              Manage exchange rates
            </Link>
          </p>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        <StatTile
          label="Monthly spend"
          value={money(converted.monthlyMinor)}
          secondary={unconvertedLines((spend) => spend.monthlyMinor)}
          footnote="Weekly and yearly plans converted to a monthly equivalent"
        />
        <StatTile
          label="Yearly spend"
          value={money(converted.yearlyMinor)}
          secondary={unconvertedLines((spend) => spend.yearlyMinor)}
        />
        <StatTile
          label="Year-to-date"
          value={money(trends.yearToDateMinor)}
          footnote={`Paid since Jan 1, ${trends.monthlyExpenditure.year}`}
        />
        <StatTile
          label="Active subscriptions"
          value={summary.data.subscriptionCount}
          footnote={
            <Link to="/subscriptions" className="text-accent-ink underline">
              View all
            </Link>
          }
        />
        <StatTile
          label="Avg per subscription"
          value={money(converted.averageMonthlyMinor)}
          footnote={
            unconverted.length > 0
              ? `Per month, excluding ${converted.unconvertedCurrencies.join(", ")}`
              : "Per month"
          }
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2 lg:items-start">
        <RenewingSoon renewals={summary.data.upcomingRenewals} />
        <ChartCard
          title="Category breakdown"
          description="Spending by category (monthly equivalent)"
          legend={
            <CategoryLegend categories={converted.byCategory} currency={primary} colors={colors} />
          }
          table={
            <DataTable
              caption="Monthly spending by category"
              rows={converted.byCategory.map((c) => ({
                label: categoryLabel(c.category),
                value: money(c.monthlyMinor),
              }))}
            />
          }
        >
          <CategoryDonut
            categories={converted.byCategory}
            currency={primary}
            minorDigits={digits}
            colors={colors}
          />
        </ChartCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard
          title="Spending trends"
          description="Payments per month over the last 12 months"
          table={
            <DataTable
              caption="Payments per month, last 12 months"
              rows={trends.spendingTrend.map((m) => ({
                label: formatMonth(m.month),
                value: money(m.amountMinor),
              }))}
            />
          }
        >
          <MonthlyLineChart
            series={trends.spendingTrend}
            currency={primary}
            minorDigits={digits}
            colors={colors}
          />
        </ChartCard>

        <ChartCard
          title="6-month forecast"
          description="Scheduled renewals per month, at today's prices"
          table={
            <DataTable
              caption="Forecast per month, next 6 months"
              rows={trends.forecast.map((m) => ({
                label: formatMonth(m.month),
                value: money(m.amountMinor),
              }))}
            />
          }
        >
          <MonthlyLineChart
            series={trends.forecast}
            currency={primary}
            minorDigits={digits}
            colors={colors}
            dashed
          />
        </ChartCard>
      </div>

      <ChartCard
        title="Monthly expenditure"
        description={`What you paid and what's scheduled, January to December ${trends.monthlyExpenditure.year}`}
        legend={<ExpenditureLegend colors={colors} />}
        table={
          <DataTable
            caption={`Expenditure per month, ${trends.monthlyExpenditure.year}`}
            rows={trends.monthlyExpenditure.months.map((m) => ({
              label: formatMonth(m.month),
              value: money(m.amountMinor),
              note: expenditureNote(m.kind),
            }))}
          />
        }
      >
        <ExpenditureBarChart
          months={trends.monthlyExpenditure.months}
          currency={primary}
          minorDigits={digits}
          colors={colors}
        />
      </ChartCard>
    </>
  );
}
