import { SubscriptionListResponseSchema } from "@subtrack/contracts";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";
import { type NewSubscriptionRow, subscriptions } from "../src/db/schema";
import { testDatabaseUrl } from "./test-database";

const database = createDatabase(testDatabaseUrl);
const app = await buildApp({ database });

const base: NewSubscriptionRow = {
  name: "Netflix",
  amountMinor: 1599,
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "2026-11-15",
};

beforeEach(async () => {
  await database.db.delete(subscriptions);
});

afterAll(async () => {
  await app.close();
  await database.close();
});

describe("GET /subscriptions", () => {
  it("returns an empty list when there are no subscriptions", async () => {
    const response = await app.inject({ method: "GET", url: "/subscriptions" });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({ items: [] });
  });

  it("returns subscriptions in the contract shape", async () => {
    await database.db.insert(subscriptions).values({ ...base, notes: "Family plan" });

    const response = await app.inject({ method: "GET", url: "/subscriptions" });

    expect(response.statusCode).toBe(200);
    const body = SubscriptionListResponseSchema.parse(response.json());
    expect(body.items).toEqual([
      {
        ...base,
        notes: "Family plan",
        id: expect.any(String),
        createdAt: expect.stringMatching(/Z$/),
        updatedAt: expect.stringMatching(/Z$/),
      },
    ]);
  });

  it("sorts by next renewal date, then name", async () => {
    await database.db.insert(subscriptions).values([
      { ...base, name: "Yearly thing", nextRenewalDate: "2027-01-01" },
      { ...base, name: "Spotify", nextRenewalDate: "2026-11-01" },
      { ...base, name: "Apple Music", nextRenewalDate: "2026-11-01" },
      { ...base, name: "Netflix", nextRenewalDate: "2026-11-20" },
    ]);

    const response = await app.inject({ method: "GET", url: "/subscriptions" });

    const names = SubscriptionListResponseSchema.parse(response.json()).items.map((s) => s.name);
    expect(names).toEqual(["Apple Music", "Spotify", "Netflix", "Yearly thing"]);
  });
});
