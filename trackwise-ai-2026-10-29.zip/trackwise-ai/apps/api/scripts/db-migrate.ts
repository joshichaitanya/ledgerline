import { loadConfig } from "../src/config";
import { runMigrations } from "../src/db/migrate";

const { DATABASE_URL } = loadConfig();
await runMigrations(DATABASE_URL);
console.log("Migrations applied");
