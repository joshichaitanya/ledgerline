import { expect, test } from "./support/fixtures";

const htmlIsDark = (page: import("@playwright/test").Page) =>
  page.evaluate(() => document.documentElement.classList.contains("dark"));

test.describe("Theme", () => {
  test("follows the operating system by default", async ({ page }) => {
    await page.emulateMedia({ colorScheme: "dark" });
    await page.goto("/");
    expect(await htmlIsDark(page)).toBe(true);

    // The OS change arrives as an async media-query event; poll rather than assert instantly.
    await page.emulateMedia({ colorScheme: "light" });
    await expect.poll(() => htmlIsDark(page)).toBe(false);
  });

  test("remembers an explicit choice across reloads, over the OS preference", async ({ page }) => {
    await page.emulateMedia({ colorScheme: "light" });
    await page.goto("/");

    await page.getByRole("button", { name: "Switch to dark theme" }).click();
    expect(await htmlIsDark(page)).toBe(true);

    await page.reload();
    expect(await htmlIsDark(page)).toBe(true);
    await expect(page.getByRole("button", { name: "Switch to light theme" })).toBeVisible();
  });
});
