export const testDatabaseUrl =
  process.env.TEST_DATABASE_URL ?? "postgres://subtrack:subtrack@localhost:5433/subtrack_test";
