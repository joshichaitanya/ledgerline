import { useQuery } from "@tanstack/react-query";
import { api } from "./client";
import type { components } from "./schema.gen";
import { ApiError } from "./subscriptions";

export type SummaryResponse = components["schemas"]["SummaryResponse"];
export type CurrencySpend = components["schemas"]["CurrencySpend"];

export const summaryKey = ["summary"] as const;

export function useSummary() {
  return useQuery({
    queryKey: summaryKey,
    queryFn: async () => {
      const { data, error, response } = await api.GET("/summary");
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
  });
}
