import { screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { mockApi, mockNetworkError, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { HealthStatus } from "./HealthStatus";

describe("HealthStatus", () => {
  it("shows API and database as ok when healthy", async () => {
    mockApi(
      route("get", "/health").reply(() => ({
        status: 200,
        body: { status: "ok", checks: { api: "ok", database: "ok" } },
      })),
    );

    renderWithQueryClient(<HealthStatus />);

    expect(await screen.findByText("API: ok")).toBeInTheDocument();
    expect(screen.getByText("Database: ok")).toBeInTheDocument();
  });

  it("shows the database as down when the API reports degraded", async () => {
    mockApi(
      route("get", "/health").reply(() => ({
        status: 503,
        body: { status: "degraded", checks: { api: "ok", database: "down" } },
      })),
    );

    renderWithQueryClient(<HealthStatus />);

    expect(await screen.findByText("Database: down")).toBeInTheDocument();
    expect(screen.getByText("API: ok")).toBeInTheDocument();
  });

  it("shows the API as unreachable when the request fails", async () => {
    mockNetworkError();

    renderWithQueryClient(<HealthStatus />);

    expect(await screen.findByText("API: unreachable")).toBeInTheDocument();
    expect(screen.getByText("Database: unknown")).toBeInTheDocument();
  });
});
