import { formatMoney } from "@subtrack/contracts";
import { Link } from "react-router";
import type { Subscription } from "../api/subscriptions";
import { billingCycleLabel, categoryLabel, formatDate } from "../lib/format";

interface SubscriptionsTableProps {
  subscriptions: Subscription[];
  onDelete: (subscription: Subscription) => void;
}

export function SubscriptionsTable({ subscriptions, onDelete }: SubscriptionsTableProps) {
  return (
    // `relative` keeps the sr-only (absolutely positioned) labels inside this scroll box;
    // otherwise they escape the clip and widen the whole page on phones.
    <div className="relative overflow-x-auto rounded-lg border border-line bg-surface">
      <table className="w-full text-left text-sm">
        <caption className="sr-only">Subscriptions, soonest renewal first</caption>
        <thead className="whitespace-nowrap border-b border-line bg-surface-muted text-xs uppercase text-ink-muted">
          <tr>
            <th scope="col" className="px-4 py-3 font-medium">
              Name
            </th>
            <th scope="col" className="px-4 py-3 text-right font-medium">
              Price
            </th>
            <th scope="col" className="px-4 py-3 font-medium">
              Billing cycle
            </th>
            <th scope="col" className="px-4 py-3 font-medium">
              Next renewal
            </th>
            <th scope="col" className="px-4 py-3 font-medium">
              Category
            </th>
            <th scope="col" className="px-4 py-3 text-right font-medium">
              <span className="sr-only">Actions</span>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {subscriptions.map((subscription) => (
            <tr key={subscription.id}>
              <td className="px-4 py-3">
                <Link
                  to={`/subscriptions/${subscription.id}`}
                  className="font-medium text-ink hover:text-accent-ink hover:underline"
                >
                  {subscription.name}
                </Link>
                {subscription.notes && (
                  <div className="text-xs text-ink-subtle">{subscription.notes}</div>
                )}
              </td>
              <td className="whitespace-nowrap px-4 py-3 text-right tabular-nums">
                {formatMoney(subscription.amountMinor, subscription.currency)}
              </td>
              <td className="whitespace-nowrap px-4 py-3">
                {billingCycleLabel(subscription.billingCycle)}
              </td>
              <td className="whitespace-nowrap px-4 py-3 tabular-nums">
                {formatDate(subscription.nextRenewalDate)}
              </td>
              <td className="px-4 py-3">{categoryLabel(subscription.category)}</td>
              <td className="whitespace-nowrap px-4 py-3 text-right">
                <Link
                  to={`/subscriptions/${subscription.id}/edit`}
                  aria-label={`Edit ${subscription.name}`}
                  className="rounded-md px-2 py-1 font-medium text-accent-ink hover:bg-accent-soft"
                >
                  Edit
                </Link>
                <button
                  type="button"
                  onClick={() => onDelete(subscription)}
                  aria-label={`Delete ${subscription.name}`}
                  className="ml-1 rounded-md px-2 py-1 font-medium text-danger-ink hover:bg-danger-soft"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
