import { defineConfig } from "drizzle-kit";

// Used by `pnpm db:generate` to diff src/db/schema.ts against previous migrations.
// Migrations are applied by src/db/migrate.ts, not drizzle-kit.
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  strict: true,
});
