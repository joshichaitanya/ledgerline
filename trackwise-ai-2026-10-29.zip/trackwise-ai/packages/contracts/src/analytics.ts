import { z } from "zod";
import { addDays, addMonths, firstRenewalIndexOnOrAfter, nthRenewal } from "./renewals";
import { convertMinor, type RateTable } from "./settings";
import { type BillingCycle, type Currency, CurrencySchema } from "./subscription";

export const TREND_MONTHS = 12;
export const FORECAST_MONTHS = 6;

const month = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Must be a YYYY-MM month");

export const MonthlyAmountSchema = z
  .object({ month, amountMinor: z.int().nonnegative() })
  .meta({ id: "MonthlyAmount" });

export const ExpenditureMonthSchema = MonthlyAmountSchema.extend({
  /** actual = recorded payments; projected = scheduled renewals; current = both. */
  kind: z.enum(["actual", "current", "projected"]),
}).meta({ id: "ExpenditureMonth" });

export const AnalyticsResponseSchema = z
  .object({
    /** All amounts are in this (the primary) currency. */
    currency: CurrencySchema,
    asOf: z.iso.date(),
    /** Recorded payments from Jan 1 to today. */
    yearToDateMinor: z.int().nonnegative(),
    /** Recorded payments per month, the last TREND_MONTHS months ending this month. */
    spendingTrend: z.array(MonthlyAmountSchema),
    /** Scheduled renewals per month, the next FORECAST_MONTHS months. */
    forecast: z.array(MonthlyAmountSchema),
    /** Every month of the current year: payments so far, scheduled renewals after today. */
    monthlyExpenditure: z.object({ year: z.int(), months: z.array(ExpenditureMonthSchema) }),
    /** Currencies without an exchange rate: excluded from every figure above, never guessed. */
    unconvertedCurrencies: z.array(CurrencySchema),
  })
  .meta({ id: "AnalyticsResponse" });

export type MonthlyAmount = z.infer<typeof MonthlyAmountSchema>;
export type AnalyticsResponse = z.infer<typeof AnalyticsResponseSchema>;

/** An amount of money on a date: a recorded payment or a scheduled renewal. */
export interface Charge {
  date: string;
  amountMinor: number;
  currency: Currency;
}

interface Schedulable {
  amountMinor: number;
  currency: Currency;
  billingCycle: BillingCycle;
  nextRenewalDate: string;
}

export const monthOf = (isoDate: string) => isoDate.slice(0, 7);

/** "2026-10" shifted by n months. */
export const shiftMonth = (yearMonth: string, months: number) =>
  addMonths(`${yearMonth}-01`, months).slice(0, 7);

const lastDayOf = (yearMonth: string) => addDays(`${shiftMonth(yearMonth, 1)}-01`, -1);

/** Every renewal of each subscription between `from` and `to` (inclusive), at today's price. */
export function scheduledCharges(
  subscriptions: readonly Schedulable[],
  from: string,
  to: string,
): Charge[] {
  const charges: Charge[] = [];
  for (const subscription of subscriptions) {
    const { nextRenewalDate: anchor, billingCycle } = subscription;
    for (
      let n = firstRenewalIndexOnOrAfter(anchor, billingCycle, from),
        date = nthRenewal(anchor, billingCycle, n);
      date <= to;
      date = nthRenewal(anchor, billingCycle, ++n)
    ) {
      charges.push({
        date,
        amountMinor: subscription.amountMinor,
        currency: subscription.currency,
      });
    }
  }
  return charges;
}

/**
 * Spending trend (from payments), forecast and this year's expenditure (payments up to today,
 * scheduled renewals after), all converted to the primary currency. Payments already include
 * every renewal up to today, so projections start tomorrow and nothing is counted twice.
 */
export function buildAnalytics({
  payments,
  subscriptions,
  today,
  primary,
  rates,
}: {
  payments: readonly Charge[];
  subscriptions: readonly Schedulable[];
  today: string;
  primary: Currency;
  rates: RateTable;
}): AnalyticsResponse {
  const unconverted = new Set<Currency>();
  const sumByMonth = (charges: readonly Charge[]) => {
    const totals = new Map<string, number>();
    for (const charge of charges) {
      const amount = convertMinor(charge.amountMinor, charge.currency, primary, rates);
      if (amount === undefined) {
        unconverted.add(charge.currency);
        continue;
      }
      const key = monthOf(charge.date);
      totals.set(key, (totals.get(key) ?? 0) + amount);
    }
    return totals;
  };

  const thisMonth = monthOf(today);
  const year = Number(today.slice(0, 4));
  const paid = sumByMonth(payments.filter((payment) => payment.date <= today));
  const horizon =
    [lastDayOf(shiftMonth(thisMonth, FORECAST_MONTHS)), `${year}-12-31`].sort()[1] ?? today;
  const projected = sumByMonth(scheduledCharges(subscriptions, addDays(today, 1), horizon));

  const yearToDateMinor = [...paid]
    .filter(([key]) => key.startsWith(`${year}-`))
    .reduce((sum, [, amount]) => sum + amount, 0);

  const months = Array.from({ length: 12 }, (_, index) => {
    const key = `${year}-${String(index + 1).padStart(2, "0")}`;
    const kind = key < thisMonth ? "actual" : key === thisMonth ? "current" : "projected";
    const amountMinor =
      (kind === "projected" ? 0 : (paid.get(key) ?? 0)) +
      (kind === "actual" ? 0 : (projected.get(key) ?? 0));
    return { month: key, amountMinor, kind } as const;
  });

  return {
    currency: primary,
    asOf: today,
    yearToDateMinor,
    spendingTrend: Array.from({ length: TREND_MONTHS }, (_, index) => {
      const key = shiftMonth(thisMonth, index - (TREND_MONTHS - 1));
      return { month: key, amountMinor: paid.get(key) ?? 0 };
    }),
    forecast: Array.from({ length: FORECAST_MONTHS }, (_, index) => {
      const key = shiftMonth(thisMonth, index + 1);
      return { month: key, amountMinor: projected.get(key) ?? 0 };
    }),
    monthlyExpenditure: { year, months },
    unconvertedCurrencies: [...unconverted].sort(),
  };
}
