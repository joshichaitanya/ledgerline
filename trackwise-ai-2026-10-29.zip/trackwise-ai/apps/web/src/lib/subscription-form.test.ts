import { describe, expect, it } from "vitest";
import { aSubscription } from "../test/fixtures";
import {
  emptyFormValues,
  SubscriptionFormSchema,
  type SubscriptionFormValues,
  toFormValues,
  toRequest,
} from "./subscription-form";

const filled: SubscriptionFormValues = {
  ...emptyFormValues,
  name: "Netflix",
  amount: "15.99",
  nextRenewalDate: "2026-11-15",
};

function errorsFor(values: SubscriptionFormValues) {
  const result = SubscriptionFormSchema.safeParse(values);
  return Object.fromEntries(
    (result.error?.issues ?? []).map((issue) => [issue.path.join("."), issue.message]),
  );
}

describe("SubscriptionFormSchema", () => {
  it("accepts a filled form", () => {
    expect(errorsFor(filled)).toEqual({});
  });

  it("reports every invalid field at once, including the amount", () => {
    expect(errorsFor(emptyFormValues)).toEqual({
      name: "Name is required",
      amount: "Enter an amount like 9.99",
      nextRenewalDate: "Enter a valid date",
    });
  });

  it("validates decimals against the selected currency", () => {
    expect(errorsFor({ ...filled, amount: "15.5", currency: "JPY" })).toEqual({
      amount: "JPY amounts can't have decimals",
    });
  });
});

describe("toRequest", () => {
  it("converts the amount to minor units and empty notes to null", () => {
    expect(toRequest(filled)).toEqual({
      name: "Netflix",
      amountMinor: 1599,
      currency: "USD",
      billingCycle: "monthly",
      category: "streaming",
      nextRenewalDate: "2026-11-15",
      notes: null,
    });
  });
});

describe("toFormValues", () => {
  it("round-trips a subscription through the form", () => {
    const subscription = aSubscription({ amountMinor: 2400, currency: "JPY", notes: "Family" });

    const values = toFormValues(subscription);

    expect(values.amount).toBe("2400");
    expect(values.notes).toBe("Family");
    expect(toRequest(values)).toMatchObject({
      amountMinor: 2400,
      currency: "JPY",
      notes: "Family",
    });
  });
});
