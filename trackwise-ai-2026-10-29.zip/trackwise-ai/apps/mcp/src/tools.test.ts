import { describe, expect, it } from "vitest";
import { connectClient, textOf } from "./test/connect";
import { analytics, aPayment, aSubscription, summary } from "./test/fixtures";
import { mockApi, mockApiDown, route } from "./test/mock-api";

const call = async (name: string, args: Record<string, unknown> = {}) => {
  const client = await connectClient();
  return client.callTool({ name, arguments: args });
};

describe("ping", () => {
  it("answers pong", async () => {
    expect(textOf(await call("ping"))).toBe("pong");
  });
});

describe("list_subscriptions", () => {
  const items = [
    aSubscription({ name: "Netflix", notes: "Family plan" }),
    aSubscription({
      name: "Nintendo Switch Online",
      amountMinor: 2400,
      currency: "JPY",
      billingCycle: "yearly",
      category: "gaming",
    }),
  ];

  it("formats money for the model and includes ids and notes", async () => {
    mockApi(route("get", "/subscriptions").reply(() => ({ status: 200, body: { items } })));

    const result = await call("list_subscriptions");

    // Regression: `notes` once broke the output schema (-32602 "additional properties").
    expect(result.isError).toBeFalsy();
    expect(result.structuredContent).toEqual({
      subscriptions: [
        expect.objectContaining({ name: "Netflix", price: "$15.99", notes: "Family plan" }),
        expect.objectContaining({ name: "Nintendo Switch Online", price: "¥2,400" }),
      ],
    });
    expect(textOf(result)).toContain(`Netflix (id ${items[0]?.id}): $15.99 monthly`);
  });

  it("filters by category", async () => {
    mockApi(route("get", "/subscriptions").reply(() => ({ status: 200, body: { items } })));

    const result = await call("list_subscriptions", { category: "gaming" });

    expect(textOf(result)).toContain("Nintendo Switch Online");
    expect(textOf(result)).not.toContain("Netflix");
  });
});

describe("list_subscriptions when empty", () => {
  it("says so plainly", async () => {
    mockApi(route("get", "/subscriptions").reply(() => ({ status: 200, body: { items: [] } })));

    const result = await call("list_subscriptions");

    expect(textOf(result)).toBe("No subscriptions found.");
    expect(result.structuredContent).toEqual({ subscriptions: [] });
  });
});

describe("get_subscription", () => {
  it("returns details and the most recent payments", async () => {
    const netflix = aSubscription();
    const payments = ["2026-10-15", "2026-09-15", "2026-08-15"].map((date) =>
      aPayment(netflix.id, date),
    );
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body: netflix })),
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 200,
        body: { items: payments },
      })),
    );

    const result = await call("get_subscription", { id: netflix.id, paymentLimit: 2 });

    expect(result.structuredContent).toMatchObject({
      recentPayments: [
        { paidOn: "2026-10-15", amount: "$15.99" },
        { paidOn: "2026-09-15", amount: "$15.99" },
      ],
      totalPaymentsRecorded: 3,
    });
    expect(textOf(result)).toContain("Recent payments (2 of 3)");
  });

  it("says when no payments are recorded yet", async () => {
    const netflix = aSubscription({ notes: "Family plan" });
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body: netflix })),
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 200,
        body: { items: [] },
      })),
    );

    const text = textOf(await call("get_subscription", { id: netflix.id }));

    expect(text).toContain("Notes: Family plan");
    expect(text).toContain("No payments recorded yet.");
  });

  it("tells the model how to recover from an unknown id", async () => {
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({
        status: 404,
        body: { error: "NotFound", message: "Subscription not found" },
      })),
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 404,
        body: { error: "NotFound", message: "Subscription not found" },
      })),
    );

    const result = await call("get_subscription", { id: crypto.randomUUID() });

    expect(result.isError).toBe(true);
    expect(textOf(result)).toContain("Use list_subscriptions to find valid ids");
  });

  it("rejects a malformed id before calling the API", async () => {
    const fetchMock = mockApi();

    const result = await call("get_subscription", { id: "not-a-uuid" });

    expect(result.isError).toBe(true);
    expect(fetchMock).not.toHaveBeenCalled();
  });
});

describe("get_spending_summary", () => {
  it("summarises converted totals, Year-to-Date, categories and excluded currencies", async () => {
    mockApi(
      route("get", "/summary").reply(() => ({ status: 200, body: summary })),
      route("get", "/analytics").reply(() => ({ status: 200, body: analytics })),
    );

    const text = textOf(await call("get_spending_summary"));

    expect(text).toContain("Spending in USD: $40.00/month, $480.00/year across 3 subscriptions");
    expect(text).toContain("Paid so far this year: $375.00.");
    expect(text).toContain("streaming $30.00/month (75%)");
    expect(text).toContain("Not included (no exchange rate): ISK.");
  });
});

describe("get_spending_summary with every currency converted", () => {
  it("doesn't mention excluded currencies", async () => {
    mockApi(
      route("get", "/summary").reply(() => ({
        status: 200,
        body: { ...summary, converted: { ...summary.converted, unconvertedCurrencies: [] } },
      })),
      route("get", "/analytics").reply(() => ({ status: 200, body: analytics })),
    );

    expect(textOf(await call("get_spending_summary"))).not.toContain("Not included");
  });
});

describe("get_upcoming_renewals", () => {
  it("passes the window to the API and phrases days for a reader", async () => {
    const fetchMock = mockApi(
      route("get", "/summary").reply(() => ({ status: 200, body: summary })),
    );

    const result = await call("get_upcoming_renewals", { days: 7 });

    expect(
      new URL(fetchMock.mock.calls[0]?.[0].url ?? "").searchParams.get("renewalWindowDays"),
    ).toBe("7");
    expect(textOf(result)).toBe("Netflix: $15.99 on 2026-10-30 (tomorrow)");
  });

  it.each([
    [0, "today"],
    [1, "tomorrow"],
    [12, "in 12 days"],
  ])("phrases %i days away as %s", async (daysUntil, phrase) => {
    const [first] = summary.upcomingRenewals.items;
    mockApi(
      route("get", "/summary").reply(() => ({
        status: 200,
        body: {
          ...summary,
          upcomingRenewals: {
            ...summary.upcomingRenewals,
            items: first ? [{ ...first, daysUntil }] : [],
          },
        },
      })),
    );

    expect(textOf(await call("get_upcoming_renewals"))).toContain(`(${phrase})`);
  });

  it("says when nothing renews in the window", async () => {
    mockApi(
      route("get", "/summary").reply(() => ({
        status: 200,
        body: { ...summary, upcomingRenewals: { ...summary.upcomingRenewals, items: [] } },
      })),
    );

    expect(textOf(await call("get_upcoming_renewals", { days: 7 }))).toBe(
      "Nothing renews in the next 7 days.",
    );
  });

  it("rejects an out-of-range window with a message the model can act on", async () => {
    const fetchMock = mockApi();

    const result = await call("get_upcoming_renewals", { days: 0 });

    expect(result.isError).toBe(true);
    expect(textOf(result)).toMatch(/days/);
    expect(fetchMock).not.toHaveBeenCalled();
  });
});

describe("add_subscription", () => {
  const youtube = {
    name: "YouTube Premium",
    currency: "INR",
    billingCycle: "monthly",
    category: "streaming",
    nextRenewalDate: "2026-11-05",
  };

  function acceptCreates() {
    let body: Record<string, unknown> = {};
    const fetchMock = mockApi(
      route("post", "/subscriptions").reply(async ({ request }) => {
        body = (await request.json()) as Record<string, unknown>;
        return { status: 201, body: aSubscription({ ...body, id: crypto.randomUUID() }) };
      }),
    );
    return { fetchMock, sent: () => body };
  }

  // Regression: `amount` once accepted only text, and the first real call sent the number 149.
  it.each([
    ["a number", 149, 14_900],
    ["text", "149.50", 14_950],
  ])("accepts the amount as %s and converts it to minor units", async (_kind, amount, minor) => {
    const { sent } = acceptCreates();

    const result = await call("add_subscription", { ...youtube, amount });

    expect(result.isError).toBeFalsy();
    expect(sent()).toMatchObject({ amountMinor: minor, currency: "INR", name: "YouTube Premium" });
    expect(textOf(result)).toMatch(/^Added YouTube Premium: ₹/);
  });

  it.each([
    ["too many decimals", { amount: "12.345", currency: "USD" }, "Use at most 2 decimal places"],
    ["decimals in yen", { amount: 99.5, currency: "JPY" }, "JPY amounts can't have decimals"],
  ])("rejects %s without calling the API", async (_case, overrides, message) => {
    const { fetchMock } = acceptCreates();

    const result = await call("add_subscription", { ...youtube, ...overrides });

    expect(result.isError).toBe(true);
    expect(textOf(result)).toContain(message);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("passes on the API's field errors", async () => {
    mockApi(
      route("post", "/subscriptions").reply(() => ({
        status: 400,
        body: {
          error: "ValidationError",
          message: "Request validation failed",
          issues: [{ path: "nextRenewalDate", location: "body", message: "Enter a valid date" }],
        },
      })),
    );

    const result = await call("add_subscription", {
      ...youtube,
      amount: 5,
      nextRenewalDate: "2026-02-30",
    });

    expect(result.isError).toBe(true);
    expect(textOf(result)).toContain("nextRenewalDate: Enter a valid date");
  });
});

describe("when the API is down", () => {
  it("explains the problem instead of failing silently", async () => {
    mockApiDown();

    const result = await call("list_subscriptions");

    expect(result.isError).toBe(true);
    expect(textOf(result)).toContain("The TrackWise API is not reachable");
    expect(textOf(result)).toContain("pnpm dev");
  });
});
