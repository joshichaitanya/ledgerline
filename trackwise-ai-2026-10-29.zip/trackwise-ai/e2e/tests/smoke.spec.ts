import { expect, test } from "./support/fixtures";

test("app loads and reports a healthy API and database", async ({ page }) => {
  await page.goto("/");

  await expect(page.getByRole("heading", { name: "TrackWise-AI" })).toBeVisible();
  const status = page.getByRole("status", { name: "System status" });
  await expect(status).toContainText("API: ok");
  await expect(status).toContainText("Database: ok");
});
