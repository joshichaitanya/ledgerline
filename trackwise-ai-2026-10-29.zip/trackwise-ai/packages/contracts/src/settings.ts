import { z } from "zod";
import { minorUnitDigits } from "./money";
import { type Currency, CurrencySchema } from "./subscription";

export const SettingsSchema = z
  .object({
    /** Totals, averages and charts are converted to this currency where a rate exists. */
    primaryCurrency: CurrencySchema,
  })
  .meta({ id: "Settings" });

export const UpdateSettingsRequestSchema = SettingsSchema.meta({ id: "UpdateSettingsRequest" });

/** "1 {currency} = {rate} {primaryCurrency}". Entered manually by the user. */
export const ExchangeRateSchema = z
  .object({
    currency: CurrencySchema,
    rate: z
      .number("Enter a rate")
      .positive("Rate must be greater than zero")
      .max(1_000_000_000, "Rate is too large"),
    updatedAt: z.iso.datetime(),
  })
  .meta({ id: "ExchangeRate" });

export const DefaultRateSchema = z
  .object({ currency: CurrencySchema, rate: z.number().positive() })
  .meta({ id: "DefaultRate" });

export const ExchangeRatesResponseSchema = z
  .object({
    /** All rates are expressed in this currency. */
    primaryCurrency: CurrencySchema,
    /** Your custom rates, sorted by currency code. They override the defaults. */
    items: z.array(ExchangeRateSchema),
    /** Built-in approximate rates, used wherever you haven't set your own. */
    defaults: z.array(DefaultRateSchema),
    /** When the built-in rates were last updated, e.g. "2026-10". */
    defaultsAsOf: z.string(),
  })
  .meta({ id: "ExchangeRatesResponse" });

export const SetExchangeRateRequestSchema = z
  .object({ rate: ExchangeRateSchema.shape.rate })
  .meta({ id: "SetExchangeRateRequest" });

export const CurrencyParamsSchema = z.object({ currency: CurrencySchema });

export type Settings = z.infer<typeof SettingsSchema>;
export type ExchangeRate = z.infer<typeof ExchangeRateSchema>;
export type ExchangeRatesResponse = z.infer<typeof ExchangeRatesResponseSchema>;

/** Rates keyed by currency: units of the primary currency per one unit of that currency. */
export type RateTable = ReadonlyMap<Currency, number>;

/**
 * Converts an amount between currencies via the primary-currency rate table. Returns undefined
 * when a rate is missing — callers must show such amounts separately, never guess.
 * Rounded to the target currency's minor unit (e.g. ¥ has none, BHD has three).
 */
export function convertMinor(
  amountMinor: number,
  from: Currency,
  primary: Currency,
  rates: RateTable,
): number | undefined {
  if (from === primary) return amountMinor;
  const rate = rates.get(from);
  if (rate === undefined) return undefined;
  const major = amountMinor / 10 ** minorUnitDigits(from);
  // toPrecision strips float noise first, so exact halves round correctly:
  // 1.5 × 2.65 is 3.97499999… in floating point but 3.975 in reality.
  return Math.round(Number((major * rate * 10 ** minorUnitDigits(primary)).toPrecision(12)));
}

/**
 * Re-expresses rates against a new primary currency: X→old ÷ new→old. Returns undefined if the
 * new primary has no rate (rebasing is impossible). The old primary gains the rate 1 ÷ new→old.
 */
export function rebaseRates(
  rates: RateTable,
  oldPrimary: Currency,
  newPrimary: Currency,
): Map<Currency, number> | undefined {
  if (newPrimary === oldPrimary) return new Map(rates);
  const newInOld = rates.get(newPrimary);
  if (newInOld === undefined) return undefined;
  const rebased = new Map<Currency, number>([[oldPrimary, roundRate(1 / newInOld)]]);
  for (const [currency, rate] of rates) {
    if (currency !== newPrimary) rebased.set(currency, roundRate(rate / newInOld));
  }
  return rebased;
}

/** Ten significant digits: enough precision, without float noise like 0.30000000000000004. */
export function roundRate(rate: number): number {
  return Number(rate.toPrecision(10));
}
