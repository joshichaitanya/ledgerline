import { HealthResponseSchema } from "@subtrack/contracts";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import type { Database } from "../db/client";

export const healthRoutes: FastifyPluginAsyncZod<{ database: Database }> = async (
  app,
  { database },
) => {
  app.get(
    "/health",
    {
      schema: {
        operationId: "getHealth",
        tags: ["system"],
        summary: "Report API and database health",
        response: {
          200: HealthResponseSchema.describe("API and database are healthy"),
          503: HealthResponseSchema.describe("API is up but the database is unreachable"),
        },
      },
    },
    async (_request, reply) => {
      const databaseOk = await database.ping();
      return reply.code(databaseOk ? 200 : 503).send({
        status: databaseOk ? "ok" : "degraded",
        checks: { api: "ok", database: databaseOk ? "ok" : "down" },
      });
    },
  );
};
