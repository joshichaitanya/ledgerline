import { Plus } from "lucide-react";
import { useCallback, useState } from "react";
import { Link } from "react-router";
import { type Subscription, useDeleteSubscription, useSubscriptions } from "../api/subscriptions";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { PageHeader } from "../components/PageHeader";
import { SubscriptionsTable } from "../components/SubscriptionsTable";

const addLinkClass =
  "inline-flex items-center gap-1.5 rounded-lg bg-accent px-3 py-2 text-sm font-medium text-white hover:bg-accent-hover";

export function SubscriptionsPage() {
  return (
    <section className="space-y-6">
      <PageHeader
        title="Subscriptions"
        description="Everything you pay for, soonest renewal first."
        actions={
          <Link to="/subscriptions/new" className={addLinkClass}>
            <Plus aria-hidden="true" className="size-4" />
            Add subscription
          </Link>
        }
      />
      <SubscriptionsContent />
    </section>
  );
}

function SubscriptionsContent() {
  const { data, isPending, isError, refetch, isFetching } = useSubscriptions();
  const [toDelete, setToDelete] = useState<Subscription | null>(null);
  const deleteSubscription = useDeleteSubscription();

  const closeDialog = useCallback(() => {
    setToDelete(null);
    deleteSubscription.reset();
  }, [deleteSubscription.reset]);

  if (isPending) {
    return (
      <p role="status" className="text-ink-subtle">
        Loading subscriptions…
      </p>
    );
  }

  if (isError) {
    return (
      <div
        role="alert"
        className="rounded-lg border border-danger-line bg-danger-soft p-4 text-danger-ink"
      >
        <p>Couldn't load subscriptions.</p>
        <button
          type="button"
          onClick={() => refetch()}
          disabled={isFetching}
          className="mt-2 rounded-md bg-danger px-3 py-1.5 text-sm font-medium text-white hover:bg-danger-hover disabled:opacity-50"
        >
          {isFetching ? "Retrying…" : "Retry"}
        </button>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-line-strong bg-surface p-8 text-center">
        <p className="font-medium">No subscriptions yet.</p>
        <p className="mt-1 text-sm text-ink-subtle">
          Use <span className="font-medium">Add subscription</span> to track your first one.
        </p>
      </div>
    );
  }

  return (
    <>
      <SubscriptionsTable subscriptions={data} onDelete={setToDelete} />
      {toDelete && (
        <ConfirmDialog
          title={`Delete ${toDelete.name}?`}
          description="This removes the subscription permanently."
          confirmLabel="Delete"
          onConfirm={() => deleteSubscription.mutate(toDelete.id, { onSuccess: closeDialog })}
          onCancel={closeDialog}
          isPending={deleteSubscription.isPending}
          error={deleteSubscription.error}
        />
      )}
    </>
  );
}
