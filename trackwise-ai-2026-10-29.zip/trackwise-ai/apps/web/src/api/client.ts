import createClient from "openapi-fetch";
import type { paths } from "./schema.gen";

// Typed from the generated OpenAPI schema: paths, params and bodies are checked at compile time.
export const api = createClient<paths>({
  baseUrl: new URL("/api", window.location.origin).href,
  // Resolve fetch per call so tests can stub it.
  fetch: (request) => globalThis.fetch(request),
});
