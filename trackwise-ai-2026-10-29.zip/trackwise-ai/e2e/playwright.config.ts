import { defineConfig, devices } from "@playwright/test";

const isCI = Boolean(process.env.CI);

// Dedicated ports and database, so E2E runs never touch a running dev environment.
const apiPort = 3100;
const webPort = 5174;
export const databaseUrl =
  process.env.E2E_DATABASE_URL ?? "postgres://subtrack:subtrack@localhost:5433/subtrack_e2e";

export default defineConfig({
  testDir: "./tests",
  globalSetup: "./global-setup.ts",
  // Tests share one database and some change data, so run them one at a time.
  // Each test cleans up what it creates, keeping the seeded rows intact.
  workers: 1,
  forbidOnly: isCI,
  retries: isCI ? 1 : 0,
  reporter: isCI
    ? [
        ["github"],
        ["html", { open: "never", outputFolder: "playwright-report" }],
        ["junit", { outputFile: "test-results/junit.xml" }],
      ]
    : [["list"], ["html", { open: "never", outputFolder: "playwright-report" }]],
  use: {
    baseURL: `http://127.0.0.1:${webPort}`,
    // Everything needed to debug a failure without re-running it.
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  // `pnpm e2e` runs chromium only (fast); `pnpm e2e:all` and CI run every project.
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"] } },
    { name: "firefox", use: { ...devices["Desktop Firefox"] } },
    { name: "webkit", use: { ...devices["Desktop Safari"] } },
    { name: "mobile", use: { ...devices["Pixel 7"] } },
  ],
  webServer: [
    {
      command: "pnpm --filter @subtrack/api start",
      url: `http://127.0.0.1:${apiPort}/health`,
      env: {
        HOST: "127.0.0.1",
        PORT: String(apiPort),
        DATABASE_URL: databaseUrl,
        LOG_LEVEL: "warn",
      },
      reuseExistingServer: !isCI,
    },
    {
      // Production bundle, not the dev server: tests what users would actually get.
      // `vite build` only: typechecking is `pnpm check`'s job, and it took ~25s here.
      command: "pnpm --filter @subtrack/web exec vite build && pnpm --filter @subtrack/web preview",
      url: `http://127.0.0.1:${webPort}`,
      env: { WEB_PORT: String(webPort), API_PROXY_TARGET: `http://127.0.0.1:${apiPort}` },
      // Typecheck + production build can take a while on a busy machine.
      timeout: 180_000,
      reuseExistingServer: !isCI,
    },
  ],
});
