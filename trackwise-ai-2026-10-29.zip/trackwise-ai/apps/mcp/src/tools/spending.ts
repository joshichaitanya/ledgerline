import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { formatMoney } from "@subtrack/contracts";
import { z } from "zod";
import { READ_ONLY } from "../annotations";
import { fromApi, safely } from "../api/call";
import { api } from "../api/client";

export function registerSpendingTools(server: McpServer) {
  server.registerTool(
    "get_spending_summary",
    {
      title: "Get spending summary",
      annotations: READ_ONLY,
      description:
        "The user's subscription spending: monthly and yearly totals, average per subscription, " +
        "amount paid so far this year, and a breakdown by category. Everything is converted to " +
        "the user's primary currency; currencies without an exchange rate are listed separately " +
        "and excluded from totals.",
      inputSchema: {},
      outputSchema: {
        currency: z.string().describe("Primary currency all amounts are converted to"),
        monthlyTotal: z.string(),
        yearlyTotal: z.string(),
        averagePerSubscriptionMonthly: z.string(),
        paidThisYear: z.string().describe("Recorded payments from January 1 to today"),
        activeSubscriptions: z.number(),
        byCategory: z.array(
          z.object({
            category: z.string(),
            monthly: z.string(),
            sharePercent: z.number(),
          }),
        ),
        excludedCurrencies: z
          .array(z.string())
          .describe("Currencies without an exchange rate; not included in any total"),
      },
    },
    safely(async () => {
      // Two focused endpoints: current totals (summary) and payment-based figures (analytics).
      const [summary, analytics] = await Promise.all([
        fromApi(api.GET("/summary")),
        fromApi(api.GET("/analytics")),
      ]);
      const { converted } = summary;
      const money = (minor: number) => formatMoney(minor, converted.currency);
      const totalMonthly = converted.monthlyMinor;
      const byCategory = converted.byCategory.map((c) => ({
        category: c.category,
        monthly: money(c.monthlyMinor),
        sharePercent: totalMonthly === 0 ? 0 : Math.round((100 * c.monthlyMinor) / totalMonthly),
      }));
      const excludedCurrencies = [
        ...new Set([...converted.unconvertedCurrencies, ...analytics.unconvertedCurrencies]),
      ].sort();

      const result = {
        currency: converted.currency,
        monthlyTotal: money(converted.monthlyMinor),
        yearlyTotal: money(converted.yearlyMinor),
        averagePerSubscriptionMonthly: money(converted.averageMonthlyMinor),
        paidThisYear: money(analytics.yearToDateMinor),
        activeSubscriptions: summary.subscriptionCount,
        byCategory,
        excludedCurrencies,
      };
      const text = [
        `Spending in ${result.currency}: ${result.monthlyTotal}/month, ${result.yearlyTotal}/year ` +
          `across ${result.activeSubscriptions} subscriptions (average ${result.averagePerSubscriptionMonthly}/month each).`,
        `Paid so far this year: ${result.paidThisYear}.`,
        `By category: ${byCategory.map((c) => `${c.category} ${c.monthly}/month (${c.sharePercent}%)`).join(", ")}.`,
        ...(excludedCurrencies.length > 0
          ? [`Not included (no exchange rate): ${excludedCurrencies.join(", ")}.`]
          : []),
      ].join("\n");
      return { content: [{ type: "text", text }], structuredContent: result };
    }),
  );

  server.registerTool(
    "get_upcoming_renewals",
    {
      title: "Get upcoming renewals",
      annotations: READ_ONLY,
      description:
        "Subscriptions renewing within the next N days (default 30), soonest first, with the " +
        "date, days remaining and price. Each subscription appears once, at its next renewal.",
      inputSchema: {
        // Bounds published in the schema: the client (and the AI) can see them before calling.
        days: z
          .number()
          .int()
          .min(1)
          .max(365)
          .default(30)
          .describe("How many days ahead to look (1–365)"),
      },
      outputSchema: {
        asOf: z.string().describe("Today's date used for the calculation (YYYY-MM-DD, UTC)"),
        renewals: z.array(
          z.object({
            subscriptionId: z.string(),
            name: z.string(),
            renewalDate: z.string(),
            daysUntil: z.number(),
            price: z.string(),
            billingCycle: z.string(),
          }),
        ),
      },
    },
    safely(async ({ days }) => {
      const summary = await fromApi(
        api.GET("/summary", { params: { query: { renewalWindowDays: days } } }),
      );
      const { asOf, items } = summary.upcomingRenewals;
      const renewals = items.map((r) => ({
        subscriptionId: r.subscriptionId,
        name: r.name,
        renewalDate: r.renewalDate,
        daysUntil: r.daysUntil,
        price: formatMoney(r.amountMinor, r.currency),
        billingCycle: r.billingCycle,
      }));
      const when = (n: number) => (n === 0 ? "today" : n === 1 ? "tomorrow" : `in ${n} days`);
      const text =
        renewals.length === 0
          ? `Nothing renews in the next ${days} days.`
          : renewals
              .map((r) => `${r.name}: ${r.price} on ${r.renewalDate} (${when(r.daysUntil)})`)
              .join("\n");
      return { content: [{ type: "text", text }], structuredContent: { asOf, renewals } };
    }),
  );
}
