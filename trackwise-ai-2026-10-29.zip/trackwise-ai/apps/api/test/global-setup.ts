import { runMigrations } from "../src/db/migrate";
import { testDatabaseUrl } from "./test-database";

// Runs once before all API tests: bring the test database schema up to date.
export default async function setup() {
  await runMigrations(testDatabaseUrl);
}
