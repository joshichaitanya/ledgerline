import type { ToolAnnotations } from "@modelcontextprotocol/sdk/types.js";

/*
 * Step 4.6 — tool ANNOTATIONS: hints that tell the client what kind of action a tool is, so it
 * can decide when to ask the user first (read-only tools can run quietly; writes need a "yes").
 * They're advice to the client, not security: the API's validation is what actually protects data.
 *
 *   readOnlyHint     doesn't change anything
 *   destructiveHint  may delete or overwrite existing data   (only meaningful if not read-only)
 *   idempotentHint   calling it twice has no extra effect      (only meaningful if not read-only)
 *   openWorldHint    reaches beyond this app (web, email, …)
 */

/** Looks things up in TrackWise; never changes anything. */
export const READ_ONLY: ToolAnnotations = { readOnlyHint: true, openWorldHint: false };

/** Creates something new: nothing existing is touched, but calling twice creates two. */
export const CREATES: ToolAnnotations = {
  readOnlyHint: false,
  destructiveHint: false,
  idempotentHint: false,
  openWorldHint: false,
};
