import { useQuery } from "@tanstack/react-query";
import { api } from "./client";
import type { components } from "./schema.gen";
import { ApiError } from "./subscriptions";

export type AnalyticsResponse = components["schemas"]["AnalyticsResponse"];

export function useAnalytics() {
  return useQuery({
    queryKey: ["analytics"],
    queryFn: async () => {
      const { data, error, response } = await api.GET("/analytics");
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
  });
}
