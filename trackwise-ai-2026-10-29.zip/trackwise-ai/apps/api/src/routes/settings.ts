import {
  CurrencyParamsSchema,
  defaultRates,
  ErrorResponseSchema,
  ExchangeRateSchema,
  ExchangeRatesResponseSchema,
  REFERENCE_RATES_AS_OF,
  SetExchangeRateRequestSchema,
  SettingsSchema,
  UpdateSettingsRequestSchema,
} from "@subtrack/contracts";
import type { FastifyPluginAsyncZod } from "fastify-type-provider-zod";
import { z } from "zod";
import type { Database } from "../db/client";
import {
  changePrimaryCurrency,
  deleteRate,
  getSettings,
  listRates,
  setRate,
} from "../settings/repository";

export const settingsRoutes: FastifyPluginAsyncZod<{ database: Database }> = async (
  app,
  { database },
) => {
  app.get(
    "/settings",
    {
      schema: {
        operationId: "getSettings",
        tags: ["settings"],
        summary: "Get app settings",
        response: { 200: SettingsSchema.describe("Current settings") },
      },
    },
    async () => getSettings(database),
  );

  app.put(
    "/settings",
    {
      schema: {
        operationId: "updateSettings",
        tags: ["settings"],
        summary: "Change the primary currency (exchange rates are re-expressed against it)",
        body: UpdateSettingsRequestSchema,
        response: {
          200: SettingsSchema.describe("Updated settings"),
          400: ErrorResponseSchema.describe("Invalid request body"),
          409: ErrorResponseSchema.describe(
            "The new primary currency has neither a custom nor a built-in rate, so custom rates can't be rebased",
          ),
        },
      },
    },
    async (request, reply) => {
      const result = await changePrimaryCurrency(database, request.body.primaryCurrency);
      if (result.ok) return result.settings;
      return reply.code(409).send({
        error: "RateRequired",
        message: `Add an exchange rate for ${result.missingRate} first, so existing rates can be re-expressed in ${result.missingRate}.`,
      });
    },
  );

  app.get(
    "/exchange-rates",
    {
      schema: {
        operationId: "listExchangeRates",
        tags: ["settings"],
        summary: "List custom exchange rates and the built-in defaults (primary currency per unit)",
        response: { 200: ExchangeRatesResponseSchema.describe("All rates, by currency code") },
      },
    },
    async () => {
      const { primaryCurrency } = await getSettings(database);
      return {
        primaryCurrency,
        items: await listRates(database),
        defaults: [...defaultRates(primaryCurrency)]
          .map(([currency, rate]) => ({ currency, rate }))
          .sort((a, b) => a.currency.localeCompare(b.currency)),
        defaultsAsOf: REFERENCE_RATES_AS_OF,
      };
    },
  );

  app.put(
    "/exchange-rates/:currency",
    {
      schema: {
        operationId: "setExchangeRate",
        tags: ["settings"],
        summary: "Create or update the rate for a currency",
        params: CurrencyParamsSchema,
        body: SetExchangeRateRequestSchema,
        response: {
          200: ExchangeRateSchema.describe("The saved rate"),
          400: ErrorResponseSchema.describe(
            "Invalid currency or rate, or a rate for the primary currency itself",
          ),
        },
      },
    },
    async (request, reply) => {
      const { primaryCurrency } = await getSettings(database);
      if (request.params.currency === primaryCurrency) {
        return reply.code(400).send({
          error: "PrimaryCurrencyRate",
          message: `${primaryCurrency} is the primary currency; its rate is always 1.`,
        });
      }
      return setRate(database, request.params.currency, request.body.rate);
    },
  );

  app.delete(
    "/exchange-rates/:currency",
    {
      schema: {
        operationId: "deleteExchangeRate",
        tags: ["settings"],
        summary: "Delete the rate for a currency",
        params: CurrencyParamsSchema,
        response: {
          204: z.null().describe("Deleted (no content)"),
          400: ErrorResponseSchema.describe("Invalid currency"),
          404: ErrorResponseSchema.describe("No rate is set for this currency"),
        },
      },
    },
    async (request, reply) =>
      (await deleteRate(database, request.params.currency))
        ? reply.code(204).send(null)
        : reply.code(404).send({ error: "NotFound", message: "No rate is set for this currency" }),
  );
};
