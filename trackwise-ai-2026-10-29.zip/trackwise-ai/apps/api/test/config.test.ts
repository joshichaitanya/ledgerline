import { describe, expect, it } from "vitest";
import { loadConfig } from "../src/config";

const databaseUrl = "postgres://subtrack:subtrack@localhost:5433/subtrack";

describe("loadConfig", () => {
  it("applies defaults for optional settings", () => {
    expect(loadConfig({ DATABASE_URL: databaseUrl })).toEqual({
      HOST: "127.0.0.1",
      PORT: 3000,
      LOG_LEVEL: "info",
      DATABASE_URL: databaseUrl,
    });
  });

  it("coerces PORT from the environment's string", () => {
    expect(loadConfig({ DATABASE_URL: databaseUrl, PORT: "3100" }).PORT).toBe(3100);
  });

  it("fails fast, naming every invalid setting", () => {
    expect(() => loadConfig({ PORT: "abc", LOG_LEVEL: "loud" })).toThrow(
      /Invalid environment configuration[\s\S]*PORT[\s\S]*LOG_LEVEL[\s\S]*DATABASE_URL/,
    );
  });
});
