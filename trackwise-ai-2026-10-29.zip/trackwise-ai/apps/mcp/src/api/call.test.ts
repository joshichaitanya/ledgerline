import { describe, expect, it, vi } from "vitest";
import { fromApi, NotFoundError, safely, ToolError } from "./call";
import { API_URL } from "./client";

/** Awaits a call that must fail and returns the error (fails the test if it succeeds). */
async function failure(call: Promise<unknown>): Promise<ToolError> {
  try {
    await call;
  } catch (error) {
    return error as ToolError;
  }
  throw new Error("expected the call to fail");
}

/** An openapi-fetch style result. */
const result = <T>(status: number, data?: T, error?: unknown) =>
  Promise.resolve({ data, error, response: new Response(null, { status }) });

describe("fromApi", () => {
  it("returns the data of a successful call", async () => {
    await expect(fromApi(result(200, { ok: true }))).resolves.toEqual({ ok: true });
  });

  it("explains an unreachable API, naming where it looked and what to do", async () => {
    const error = await failure(fromApi(Promise.reject(new TypeError("fetch failed"))));

    expect(error).toBeInstanceOf(ToolError);
    expect(error.message).toContain(`not reachable at ${API_URL}`);
    expect(error.message).toContain("pnpm dev");
  });

  it("uses the caller's message for a 404, as a NotFoundError", async () => {
    const error = await failure(
      fromApi(result(404, undefined, { error: "NotFound", message: "x" }), {
        notFound: "No subscription has id 123.",
      }),
    );

    expect(error).toBeInstanceOf(NotFoundError);
    expect(error.message).toBe("No subscription has id 123.");
  });

  it("lists every field problem from a 400", async () => {
    const error = await failure(
      fromApi(
        result(400, undefined, {
          error: "ValidationError",
          message: "Request validation failed",
          issues: [
            { path: "name", location: "body", message: "Name is required" },
            { path: "currency", location: "body", message: "Unsupported currency" },
          ],
        }),
      ),
    );

    expect(error.message).toBe(
      "The request was rejected — name: Name is required; currency: Unsupported currency. Fix these values and retry.",
    );
  });

  it("falls back to the HTTP status and the API's message for other failures", async () => {
    const error = await failure(
      fromApi(
        result(500, undefined, { error: "InternalServerError", message: "Something went wrong" }),
      ),
    );

    expect(error).toBeInstanceOf(ToolError);
    expect(error).not.toBeInstanceOf(NotFoundError);
    expect(error.message).toBe("The TrackWise API failed (HTTP 500: Something went wrong).");
  });

  it("reports a 404 without a caller message as a plain failure", async () => {
    const error = await failure(fromApi(result(404)));

    expect(error).not.toBeInstanceOf(NotFoundError);
    expect(error.message).toBe("The TrackWise API failed (HTTP 404).");
  });
});

describe("safely", () => {
  it("passes successful results through untouched", async () => {
    const handler = safely(async () => ({ content: [{ type: "text" as const, text: "ok" }] }));

    await expect(handler()).resolves.toEqual({ content: [{ type: "text", text: "ok" }] });
  });

  it("turns a ToolError into a tool error result the model can read", async () => {
    const handler = safely(async () => {
      throw new ToolError("No subscription has id 123.");
    });

    await expect(handler()).resolves.toEqual({
      isError: true,
      content: [{ type: "text", text: "No subscription has id 123." }],
    });
  });

  it("hides unexpected internals from the model but logs them to stderr", async () => {
    const stderr = vi.spyOn(process.stderr, "write").mockImplementation(() => true);
    const handler = safely(async () => {
      throw new Error("database password is hunter2");
    });

    const outcome = await handler();

    expect(outcome.isError).toBe(true);
    expect(JSON.stringify(outcome)).not.toContain("hunter2");
    expect(stderr).toHaveBeenCalledWith(expect.stringContaining("hunter2"));
    stderr.mockRestore();
  });
});
