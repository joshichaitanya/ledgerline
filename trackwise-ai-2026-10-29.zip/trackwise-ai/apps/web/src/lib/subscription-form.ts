import {
  BillingCycleSchema,
  CategorySchema,
  CreateSubscriptionRequestSchema,
  CurrencySchema,
  parseMoney,
  SubscriptionSchema,
  toMajorString,
} from "@subtrack/contracts";
import { z } from "zod";
import type { CreateSubscriptionRequest, Subscription } from "../api/subscriptions";

/**
 * What the form edits. Field rules and messages are reused from the shared contracts;
 * only `amount` differs: users type "15.99", the API takes 1599 minor units.
 */
export const SubscriptionFormSchema = z
  .object({
    name: CreateSubscriptionRequestSchema.shape.name,
    amount: z.string(),
    currency: CurrencySchema,
    billingCycle: BillingCycleSchema,
    category: CategorySchema,
    nextRenewalDate: CreateSubscriptionRequestSchema.shape.nextRenewalDate,
    notes: SubscriptionSchema.shape.notes.unwrap(),
  })
  .superRefine(
    (values, ctx) => {
      const currency = CurrencySchema.safeParse(values.currency).success ? values.currency : "USD";
      const parsed = parseMoney(values.amount, currency);
      if (!parsed.ok) ctx.addIssue({ code: "custom", path: ["amount"], message: parsed.error });
    },
    // Run even when other fields are invalid, so all errors show at once.
    { when: ({ value }) => typeof (value as { amount?: unknown }).amount === "string" },
  );

export type SubscriptionFormValues = z.infer<typeof SubscriptionFormSchema>;

export const currencyOptions = ["USD", "EUR", "GBP", "INR", "JPY", "CAD", "AUD", "CHF"];

export const emptyFormValues: SubscriptionFormValues = {
  name: "",
  amount: "",
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "",
  notes: "",
};

export function toFormValues(subscription: Subscription): SubscriptionFormValues {
  return {
    name: subscription.name,
    amount: toMajorString(subscription.amountMinor, subscription.currency),
    currency: subscription.currency,
    billingCycle: subscription.billingCycle,
    category: subscription.category,
    nextRenewalDate: subscription.nextRenewalDate,
    notes: subscription.notes ?? "",
  };
}

/** Converts validated form values into the API request body. */
export function toRequest(values: SubscriptionFormValues): CreateSubscriptionRequest {
  const parsed = parseMoney(values.amount, values.currency);
  if (!parsed.ok) throw new Error(`Unvalidated amount: ${parsed.error}`);
  return {
    name: values.name,
    amountMinor: parsed.amountMinor,
    currency: values.currency,
    billingCycle: values.billingCycle,
    category: values.category,
    nextRenewalDate: values.nextRenewalDate,
    notes: values.notes === "" ? null : values.notes,
  };
}
