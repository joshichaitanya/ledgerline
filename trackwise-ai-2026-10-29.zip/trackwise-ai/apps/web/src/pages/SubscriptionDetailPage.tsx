import { formatMoney } from "@subtrack/contracts";
import { Pencil } from "lucide-react";
import { Link, useParams } from "react-router";
import { ApiError, useSubscription } from "../api/subscriptions";
import { PageHeader } from "../components/PageHeader";
import { PaymentHistory } from "../components/PaymentHistory";
import { billingCycleLabel, categoryLabel, formatDate } from "../lib/format";

export function SubscriptionDetailPage() {
  const { id = "" } = useParams();
  const subscription = useSubscription(id);

  if (subscription.isPending) {
    return (
      <p role="status" className="text-ink-subtle">
        Loading subscription…
      </p>
    );
  }
  if (subscription.isError) {
    const notFound =
      subscription.error instanceof ApiError &&
      (subscription.error.status === 404 || subscription.error.status === 400);
    return (
      <div role="alert" className="space-y-2">
        <p>{notFound ? "Subscription not found." : "Couldn't load the subscription."}</p>
        <Link to="/subscriptions" className="text-accent-ink underline">
          Back to subscriptions
        </Link>
      </div>
    );
  }

  const s = subscription.data;
  const details: [string, string][] = [
    [
      "Price",
      `${formatMoney(s.amountMinor, s.currency)} ${billingCycleLabel(s.billingCycle).toLowerCase()}`,
    ],
    ["Next renewal", formatDate(s.nextRenewalDate)],
    ["Category", categoryLabel(s.category)],
  ];

  return (
    <section className="max-w-3xl space-y-6">
      <PageHeader
        title={s.name}
        description={s.notes ?? undefined}
        actions={
          <Link
            to={`/subscriptions/${s.id}/edit`}
            className="inline-flex items-center gap-1.5 rounded-lg border border-line-strong px-3 py-2 text-sm font-medium hover:bg-surface-muted"
          >
            <Pencil aria-hidden="true" className="size-4" />
            Edit subscription
          </Link>
        }
      />
      <dl className="grid gap-4 rounded-xl border border-line bg-surface p-6 sm:grid-cols-3">
        {details.map(([term, value]) => (
          <div key={term}>
            <dt className="text-sm text-ink-subtle">{term}</dt>
            <dd className="mt-1 font-medium">{value}</dd>
          </div>
        ))}
      </dl>
      <PaymentHistory subscriptionId={s.id} />
    </section>
  );
}
