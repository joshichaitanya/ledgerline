import type { Payment, UpdatePaymentRequest } from "@subtrack/contracts";
import { desc, eq, gte } from "drizzle-orm";
import type { Database } from "../db/client";
import { type PaymentRow, payments } from "../db/schema";

export function toPayment(row: PaymentRow): Payment {
  return { ...row, createdAt: row.createdAt.toISOString(), updatedAt: row.updatedAt.toISOString() };
}

/** Newest first. */
export async function listPayments({ db }: Database, subscriptionId: string): Promise<Payment[]> {
  const rows = await db
    .select()
    .from(payments)
    .where(eq(payments.subscriptionId, subscriptionId))
    .orderBy(desc(payments.paidOn));
  return rows.map(toPayment);
}

/** Every payment on or after `since`, across subscriptions (for analytics). */
export async function listPaymentsSince({ db }: Database, since: string): Promise<Payment[]> {
  const rows = await db.select().from(payments).where(gte(payments.paidOn, since));
  return rows.map(toPayment);
}

export type UpdatePaymentResult =
  | { ok: true; payment: Payment }
  | { ok: false; reason: "not-found" | "duplicate-date" };

export async function updatePayment(
  { db }: Database,
  id: string,
  patch: UpdatePaymentRequest,
): Promise<UpdatePaymentResult> {
  try {
    const [row] = await db.update(payments).set(patch).where(eq(payments.id, id)).returning();
    return row ? { ok: true, payment: toPayment(row) } : { ok: false, reason: "not-found" };
  } catch (error) {
    // 23505 = unique_violation: another payment of this subscription is on that date.
    const code = (error as { cause?: { code?: string } }).cause?.code;
    if (code === "23505") return { ok: false, reason: "duplicate-date" };
    throw error;
  }
}

/** Returns false when no payment has this id. */
export async function deletePayment({ db }: Database, id: string): Promise<boolean> {
  const deleted = await db
    .delete(payments)
    .where(eq(payments.id, id))
    .returning({ id: payments.id });
  return deleted.length > 0;
}
