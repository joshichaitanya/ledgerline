import { expect, test } from "./support/fixtures";

// Regression: an sr-only label escaped the table's scroll box and widened the page on
// phones, pushing the delete dialog off-screen. No page may scroll sideways.
for (const colorScheme of ["light", "dark"] as const) {
  test.describe(`${colorScheme} theme`, () => {
    test.use({ colorScheme });
    for (const [name, path] of [
      ["dashboard", "/"],
      ["subscriptions list", "/subscriptions"],
      ["add form", "/subscriptions/new"],
      ["settings", "/settings"],
    ] as const) {
      test(`${name} fits the viewport without horizontal scrolling`, async ({ page }) => {
        await page.goto(path);
        await page.waitForLoadState("networkidle");

        const { scrollWidth, clientWidth } = await page.evaluate(() => ({
          scrollWidth: document.documentElement.scrollWidth,
          clientWidth: document.documentElement.clientWidth,
        }));
        expect(scrollWidth, "page is wider than the viewport").toBeLessThanOrEqual(clientWidth);
      });
    }
  });
}
