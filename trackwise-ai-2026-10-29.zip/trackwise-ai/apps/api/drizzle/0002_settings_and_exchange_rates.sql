CREATE TABLE "app_settings" (
	"id" boolean PRIMARY KEY DEFAULT true NOT NULL,
	"primary_currency" char(3) NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "app_settings_single_row" CHECK ("app_settings"."id")
);
--> statement-breakpoint
CREATE TABLE "exchange_rates" (
	"currency" char(3) PRIMARY KEY NOT NULL,
	"rate" double precision NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "exchange_rates_rate_positive" CHECK ("exchange_rates"."rate" > 0)
);
