import { type QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "./client";
import type { components } from "./schema.gen";

export type Subscription = components["schemas"]["Subscription"];
export type CreateSubscriptionRequest = components["schemas"]["CreateSubscriptionRequestInput"];
export type UpdateSubscriptionRequest = components["schemas"]["UpdateSubscriptionRequestInput"];
export type ErrorResponse = components["schemas"]["ErrorResponse"];

/** A non-2xx API response, carrying the server's ErrorResponse when there is one. */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body?: ErrorResponse,
  ) {
    super(body?.message ?? `Request failed with HTTP ${status}`);
  }
}

// Detail keys start with the list key, so invalidating ["subscriptions"] refreshes both.
const subscriptionKeys = {
  all: ["subscriptions"] as const,
  detail: (id: string) => ["subscriptions", id] as const,
};

/** Any write changes the lists, the dashboard totals and the analytics. */
function invalidateAfterWrite(queryClient: QueryClient) {
  return Promise.all([
    queryClient.invalidateQueries({ queryKey: subscriptionKeys.all }),
    queryClient.invalidateQueries({ queryKey: ["summary"] }),
    queryClient.invalidateQueries({ queryKey: ["analytics"] }),
  ]);
}

export function useSubscriptions() {
  return useQuery({
    queryKey: subscriptionKeys.all,
    queryFn: async () => {
      const { data, error, response } = await api.GET("/subscriptions");
      if (!data) throw new ApiError(response.status, error);
      return data.items;
    },
  });
}

export function useSubscription(id: string) {
  return useQuery({
    queryKey: subscriptionKeys.detail(id),
    queryFn: async () => {
      const { data, error, response } = await api.GET("/subscriptions/{id}", {
        params: { path: { id } },
      });
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
    // A 404 won't fix itself; don't retry it.
    retry: (failureCount, error) =>
      !(error instanceof ApiError && error.status === 404) && failureCount < 3,
  });
}

export function useCreateSubscription() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (body: CreateSubscriptionRequest) => {
      const { data, error, response } = await api.POST("/subscriptions", { body });
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
    onSuccess: () => invalidateAfterWrite(queryClient),
  });
}

export function useUpdateSubscription(id: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (body: UpdateSubscriptionRequest) => {
      const { data, error, response } = await api.PATCH("/subscriptions/{id}", {
        params: { path: { id } },
        body,
      });
      if (!data) throw new ApiError(response.status, error);
      return data;
    },
    onSuccess: () => invalidateAfterWrite(queryClient),
  });
}

export function useDeleteSubscription() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error, response } = await api.DELETE("/subscriptions/{id}", {
        params: { path: { id } },
      });
      if (!response.ok) throw new ApiError(response.status, error);
    },
    onSuccess: () => invalidateAfterWrite(queryClient),
  });
}
