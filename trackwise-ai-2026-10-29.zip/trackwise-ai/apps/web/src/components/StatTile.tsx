import { type ReactNode, useId } from "react";

interface StatTileProps {
  label: string;
  value: ReactNode;
  /** Smaller lines under the value, e.g. other currencies. */
  secondary?: ReactNode[];
  footnote?: ReactNode;
}

/** A headline number. Exposed as a labelled region so it can be found by its label. */
export function StatTile({ label, value, secondary = [], footnote }: StatTileProps) {
  const labelId = useId();
  return (
    <section aria-labelledby={labelId} className="rounded-lg border border-line bg-surface p-5">
      <h3 id={labelId} className="text-sm font-medium text-ink-subtle">
        {label}
      </h3>
      <p className="mt-2 text-3xl font-semibold tabular-nums text-ink">{value}</p>
      {secondary.length > 0 && (
        <ul className="mt-1 space-y-0.5 text-sm tabular-nums text-ink-muted">
          {secondary.map((line, index) => (
            // biome-ignore lint/suspicious/noArrayIndexKey: static, order-stable lines
            <li key={index}>{line}</li>
          ))}
        </ul>
      )}
      {footnote && <p className="mt-3 text-xs text-ink-subtle">{footnote}</p>}
    </section>
  );
}
