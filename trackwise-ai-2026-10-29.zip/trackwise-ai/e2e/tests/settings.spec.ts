import { expect, test } from "./support/fixtures";

const nav = (page: import("@playwright/test").Page, name: string) =>
  page.getByRole("navigation", { name: "Main" }).getByRole("link", { name }).click();

// Seed totals with built-in defaults: $124.34/mo (see dashboard.spec.ts).
test.describe("Settings: exchange rates", () => {
  test("a custom rate overrides the built-in default, and can be reset", async ({
    page,
    arrange,
  }) => {
    arrange.resetSettingsAfter();

    await page.goto("/settings");
    const eur = page.getByLabel("1 EUR =");
    await expect(eur).toHaveValue("1.16");
    await expect(page.getByText("Default (approx., Oct 2026)").first()).toBeVisible();

    await eur.fill("1.1");
    await page.getByRole("button", { name: "Save EUR rate" }).click();
    await expect(page.getByRole("button", { name: "Reset EUR rate to default" })).toBeVisible();

    await nav(page, "Dashboard");
    // €119.88 × 1.1 instead of × 1.16: $1,484.92/yr → $123.74/mo
    await expect(page.getByRole("region", { name: "Monthly spend" })).toContainText("$123.74");

    await nav(page, "Settings");
    await page.getByRole("button", { name: "Reset EUR rate to default" }).click();
    await expect(page.getByLabel("1 EUR =")).toHaveValue("1.16");
    await nav(page, "Dashboard");
    await expect(page.getByRole("region", { name: "Monthly spend" })).toContainText("$124.34");
  });

  test("switching primary currency rebases custom rates", async ({ page, api, arrange }) => {
    arrange.resetSettingsAfter();
    await api.PUT("/exchange-rates/{currency}", {
      params: { path: { currency: "EUR" } },
      body: { rate: 1.25 },
    });

    await page.goto("/settings");
    await page.getByLabel("Currency", { exact: true }).selectOption("EUR");
    await page.getByRole("button", { name: "Save", exact: true }).click();

    // 1 USD = 1 ÷ 1.25 = 0.8 EUR (custom, rebased from the custom EUR rate)
    await expect(page.getByLabel("1 USD =")).toHaveValue("0.8");
    await expect(page.getByLabel("1 EUR =")).toHaveCount(0);
  });

  test("switching to a currency without a custom rate uses the built-in rates", async ({
    page,
    arrange,
  }) => {
    arrange.resetSettingsAfter();

    await page.goto("/settings");
    await page.getByLabel("Currency", { exact: true }).selectOption("GBP");
    await page.getByRole("button", { name: "Save", exact: true }).click();
    await expect(page.getByLabel("1 USD =")).toBeVisible();

    await nav(page, "Dashboard");
    // Everything converted to pounds via the built-in rates.
    await expect(page.getByRole("region", { name: "Monthly spend" })).toContainText("£93.49");
  });
});
