import { describe, expect, it } from "vitest";
import { formatMoney, minorUnitDigits, parseMoney, toMajorString } from "./money";

// Intl separates some symbols from numbers with a non-breaking space.
const normalizeSpaces = (text: string) => text.replace(/\s/g, " ");

describe("minorUnitDigits", () => {
  it.each([
    ["USD", 2],
    ["EUR", 2],
    ["JPY", 0],
    ["BHD", 3],
  ])("%s has %i decimal places", (currency, digits) => {
    expect(minorUnitDigits(currency)).toBe(digits);
  });
});

describe("formatMoney", () => {
  it("formats cents as dollars", () => {
    expect(formatMoney(1599, "USD")).toBe("$15.99");
  });

  it("formats zero-decimal currencies without dividing", () => {
    expect(formatMoney(1500, "JPY")).toBe("¥1,500");
  });

  it("formats three-decimal currencies", () => {
    expect(normalizeSpaces(formatMoney(1234, "BHD"))).toBe("BHD 1.234");
  });

  it("groups thousands for large amounts", () => {
    expect(formatMoney(123_456_789, "USD")).toBe("$1,234,567.89");
  });

  it("respects the requested locale", () => {
    expect(normalizeSpaces(formatMoney(123_456, "EUR", "de-DE"))).toBe("1.234,56 €");
  });
});

describe("toMajorString", () => {
  it.each([
    [1599, "USD", "15.99"],
    [5, "USD", "0.05"],
    [1000, "USD", "10.00"],
    [2400, "JPY", "2400"],
    [1234, "BHD", "1.234"],
  ])("%i %s → %s", (amountMinor, currency, expected) => {
    expect(toMajorString(amountMinor, currency)).toBe(expected);
  });
});

describe("parseMoney", () => {
  it.each([
    ["15.99", "USD", 1599],
    ["15.9", "USD", 1590],
    ["15", "USD", 1500],
    ["15.", "USD", 1500],
    [" 1,299.50 ", "USD", 129950],
    ["0.29", "USD", 29],
    ["2400", "JPY", 2400],
    ["10000000", "USD", 1_000_000_000],
    ["1.234", "BHD", 1234],
  ])("parses %j %s as %i", (input, currency, amountMinor) => {
    expect(parseMoney(input, currency)).toEqual({ ok: true, amountMinor });
  });

  it("avoids floating-point rounding", () => {
    // 19.99 * 100 === 1998.9999999999998 in floating point.
    expect(parseMoney("19.99", "USD")).toEqual({ ok: true, amountMinor: 1999 });
  });

  it.each([
    ["", "USD", "Enter an amount like 9.99"],
    ["abc", "USD", "Enter an amount like 9.99"],
    ["-5", "USD", "Enter an amount like 9.99"],
    ["1e3", "USD", "Enter an amount like 9.99"],
    ["15.999", "USD", "Use at most 2 decimal places"],
    ["24.5", "JPY", "JPY amounts can't have decimals"],
    ["0", "USD", "Amount must be greater than zero"],
    ["0.00", "USD", "Amount must be greater than zero"],
    ["99999999999999999", "USD", "Amount is too large"],
    ["10000000.01", "USD", "Amount is too large"],
  ])("rejects %j %s", (input, currency, error) => {
    expect(parseMoney(input, currency)).toEqual({ ok: false, error });
  });
});
