import {
  ErrorResponseSchema,
  PaymentListResponseSchema,
  PaymentSchema,
  SubscriptionListResponseSchema,
  SubscriptionSchema,
} from "@subtrack/contracts";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";
import { type NewSubscriptionRow, payments, subscriptions } from "../src/db/schema";
import { testDatabaseUrl } from "./test-database";

const database = createDatabase(testDatabaseUrl);
const appAt = (today: string) => buildApp({ database, now: () => new Date(`${today}T12:00:00Z`) });
const app = await appAt("2026-10-28");

const base: NewSubscriptionRow = {
  name: "Netflix",
  amountMinor: 1599,
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "2026-08-31",
};

async function insert(overrides: Partial<NewSubscriptionRow> = {}) {
  const [row] = await database.db
    .insert(subscriptions)
    .values({ ...base, ...overrides })
    .returning();
  if (!row) throw new Error("insert failed");
  return row;
}

async function paymentsOf(id: string, on = app) {
  const response = await on.inject({ method: "GET", url: `/subscriptions/${id}/payments` });
  return PaymentListResponseSchema.parse(response.json()).items;
}

beforeEach(async () => {
  await database.db.delete(subscriptions); // cascades to payments
});

afterAll(async () => {
  await app.close();
  await database.close();
});

describe("automatic payment recording", () => {
  it("records passed renewals and advances the next renewal date", async () => {
    const subscription = await insert();

    const list = SubscriptionListResponseSchema.parse(
      (await app.inject({ method: "GET", url: "/subscriptions" })).json(),
    );

    // Today is Oct 28: Aug 31 and Sep 30 have passed; Oct 31 keeps the 31st.
    expect(list.items[0]?.nextRenewalDate).toBe("2026-10-31");
    expect((await paymentsOf(subscription.id)).map((p) => [p.paidOn, p.amountMinor])).toEqual([
      ["2026-09-30", 1599],
      ["2026-08-31", 1599],
    ]);
  });

  it("is idempotent, including under concurrent requests", async () => {
    const subscription = await insert();

    await Promise.all(
      Array.from({ length: 5 }, () => app.inject({ method: "GET", url: "/summary" })),
    );
    await app.inject({ method: "GET", url: "/subscriptions" });

    expect(await paymentsOf(subscription.id)).toHaveLength(2);
  });

  it("stays anchored to the 31st after passing through a short month", async () => {
    const created = SubscriptionSchema.parse(
      (
        await app.inject({
          method: "POST",
          url: "/subscriptions",
          payload: { ...base, nextRenewalDate: "2027-01-31", notes: null },
        })
      ).json(),
    );
    const inFebruary = await appAt("2027-03-01");
    const inApril = await appAt("2027-04-01");

    await inFebruary.inject({ method: "GET", url: "/subscriptions" }); // Jan 31, Feb 28 pass
    await inApril.inject({ method: "GET", url: "/subscriptions" }); // Mar 31 passes

    const paidOn = (await paymentsOf(created.id, inApril)).map((p) => p.paidOn);
    expect(paidOn).toEqual(["2027-03-31", "2027-02-28", "2027-01-31"]);
    await inFebruary.close();
    await inApril.close();
  });

  it("re-anchors when the user edits the renewal date", async () => {
    const subscription = await insert({ nextRenewalDate: "2026-12-31" });

    await app.inject({
      method: "PATCH",
      url: `/subscriptions/${subscription.id}`,
      payload: { nextRenewalDate: "2026-09-15" },
    });

    expect((await paymentsOf(subscription.id)).map((p) => p.paidOn)).toEqual([
      "2026-10-15",
      "2026-09-15",
    ]);
  });

  it("records only the last year of renewals, however old the date", async () => {
    const subscription = await insert({ billingCycle: "weekly", nextRenewalDate: "2001-01-01" });

    const recorded = await paymentsOf(subscription.id);

    expect(recorded.length).toBeLessThanOrEqual(53);
    expect(recorded.every((p) => p.paidOn >= "2025-10-27")).toBe(true);
  });

  it("deletes a subscription's payments with it", async () => {
    const subscription = await insert();
    await paymentsOf(subscription.id);

    await app.inject({ method: "DELETE", url: `/subscriptions/${subscription.id}` });

    expect(await database.db.select().from(payments)).toEqual([]);
  });
});

describe("editing payments", () => {
  async function recorded() {
    const subscription = await insert();
    const [latest, earlier] = await paymentsOf(subscription.id);
    if (!latest || !earlier) throw new Error("expected two payments");
    return { subscription, latest, earlier };
  }

  it("corrects the amount of a payment", async () => {
    const { subscription, latest } = await recorded();

    const response = await app.inject({
      method: "PATCH",
      url: `/payments/${latest.id}`,
      payload: { amountMinor: 1799 },
    });

    expect(response.statusCode).toBe(200);
    expect(PaymentSchema.parse(response.json()).amountMinor).toBe(1799);
    expect((await paymentsOf(subscription.id))[0]?.amountMinor).toBe(1799);
  });

  it("refuses (409) to move a payment onto a date that already has one", async () => {
    const { latest, earlier } = await recorded();

    const response = await app.inject({
      method: "PATCH",
      url: `/payments/${latest.id}`,
      payload: { paidOn: earlier.paidOn },
    });

    expect(response.statusCode).toBe(409);
    expect(ErrorResponseSchema.parse(response.json()).error).toBe("DuplicatePaymentDate");
  });

  it("deletes a payment, and it is not recorded again", async () => {
    const { subscription, latest } = await recorded();

    const response = await app.inject({ method: "DELETE", url: `/payments/${latest.id}` });
    await app.inject({ method: "GET", url: "/summary" });

    expect(response.statusCode).toBe(204);
    expect((await paymentsOf(subscription.id)).map((p) => p.id)).not.toContain(latest.id);
  });

  it.each([
    ["PATCH", { amountMinor: 1 }],
    ["DELETE", undefined],
  ])("returns 404 for %s on an unknown payment", async (method, payload) => {
    const response = await app.inject({
      method: method as "PATCH",
      url: "/payments/00000000-0000-4000-8000-000000000000",
      ...(payload ? { payload } : {}),
    });

    expect(response.statusCode).toBe(404);
  });

  it("returns 404 for the payments of an unknown subscription", async () => {
    const response = await app.inject({
      method: "GET",
      url: "/subscriptions/00000000-0000-4000-8000-000000000000/payments",
    });

    expect(response.statusCode).toBe(404);
  });
});
