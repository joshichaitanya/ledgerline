#!/usr/bin/env bash
# Reports breaking changes between a base OpenAPI spec and the current apps/api/openapi.json,
# e.g. a removed field or endpoint, a narrowed enum, or a newly required request field.
# Fails (exit 1) on ERR-level changes. Runs oasdiff in Docker, so nothing to install.
#
#   pnpm openapi:breaking <base-openapi.json>
#
# In CI, the base is the target branch's apps/api/openapi.json.
set -euo pipefail

OASDIFF_IMAGE="tufin/oasdiff:v1.34.1"

root="$(cd "$(dirname "$0")/.." && pwd)"
# pnpm runs scripts from the repo root; resolve the argument from where the user ran pnpm.
cd "${INIT_CWD:-$PWD}"
base="${1:?usage: pnpm openapi:breaking <base-openapi.json>}"
base_abs="$(cd "$(dirname "$base")" && pwd)/$(basename "$base")"

docker run --rm \
  -v "$base_abs:/specs/base.json:ro" \
  -v "$root/apps/api/openapi.json:/specs/revision.json:ro" \
  "$OASDIFF_IMAGE" breaking /specs/base.json /specs/revision.json --fail-on ERR --color never
