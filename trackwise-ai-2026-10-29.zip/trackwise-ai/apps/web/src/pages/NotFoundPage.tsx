import { Link } from "react-router";
import { PageHeader } from "../components/PageHeader";

export function NotFoundPage() {
  return (
    <section className="space-y-4">
      <PageHeader title="Page not found" description="This page doesn't exist." />
      <Link to="/" className="text-accent-ink underline">
        Back to the dashboard
      </Link>
    </section>
  );
}
