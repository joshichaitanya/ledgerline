import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import { createServer } from "../create-server";

/**
 * A real MCP client connected to our server through an in-memory transport: the same
 * initialize → list → call protocol Inspector and Claude Code use, without processes or stdio.
 */
export async function connectClient() {
  const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
  await createServer().connect(serverTransport);
  const client = new Client({ name: "trackwise-tests", version: "1.0.0" });
  await client.connect(clientTransport);
  return client;
}

/** The text of a tool result's first content block. */
export function textOf(result: unknown): string {
  const [first] = ((result as { content?: unknown }).content ?? []) as {
    type: string;
    text?: string;
  }[];
  return first?.text ?? "";
}
