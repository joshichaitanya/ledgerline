import { describe, expect, it } from "vitest";
import {
  defaultRates,
  effectiveRates,
  REFERENCE_USD_RATES,
  referenceRate,
} from "./reference-rates";
import { CurrencySchema } from "./subscription";

describe("reference rates", () => {
  it("only uses real ISO 4217 codes with positive rates", () => {
    for (const [currency, rate] of Object.entries(REFERENCE_USD_RATES)) {
      expect(CurrencySchema.safeParse(currency).success).toBe(true);
      expect(rate).toBeGreaterThan(0);
    }
  });

  it("derives cross rates via USD", () => {
    expect(referenceRate("EUR", "USD")).toBe(1.16);
    expect(referenceRate("USD", "EUR")).toBe(0.8620689655); // 1 ÷ 1.16
    expect(referenceRate("GBP", "EUR")).toBe(1.146551724); // 1.33 ÷ 1.16
  });

  it("has no default for currencies outside the table", () => {
    expect(referenceRate("ISK", "USD")).toBeUndefined();
    expect(referenceRate("USD", "ISK")).toBeUndefined();
  });

  it("excludes the primary currency itself from the defaults", () => {
    expect(defaultRates("EUR").has("EUR")).toBe(false);
    expect(defaultRates("EUR").get("USD")).toBe(0.8620689655);
  });

  it("lets custom rates override the defaults", () => {
    const rates = effectiveRates("USD", new Map([["EUR", 1.1]]));

    expect(rates.get("EUR")).toBe(1.1); // custom
    expect(rates.get("JPY")).toBe(0.0066); // default
    expect(rates.has("ISK")).toBe(false); // neither
  });
});
