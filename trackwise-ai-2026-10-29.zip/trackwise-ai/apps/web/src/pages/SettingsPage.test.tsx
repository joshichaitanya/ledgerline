import { screen, within } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import type { SummaryResponse } from "../api/summary";
import { type MockRoute, mockApi, requestsOf, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { SettingsPage } from "./SettingsPage";

const spend = (currency: "USD" | "EUR" | "JPY" | "ISK") => ({
  currency,
  subscriptionCount: 1,
  monthlyMinor: 100,
  yearlyMinor: 1200,
  byCategory: [],
});

const summary: SummaryResponse = {
  subscriptionCount: 4,
  spendByCurrency: [spend("USD"), spend("EUR"), spend("JPY"), spend("ISK")],
  converted: {
    currency: "USD",
    subscriptionCount: 2,
    monthlyMinor: 210,
    yearlyMinor: 2520,
    averageMonthlyMinor: 105,
    byCategory: [],
    unconvertedCurrencies: ["ISK"],
  },
  upcomingRenewals: { asOf: "2026-10-28", windowDays: 30, items: [] },
};

function setup(extra: MockRoute[] = []) {
  let putBody: unknown;
  const fetchMock = mockApi(
    ...extra,
    route("get", "/settings").reply(() => ({ status: 200, body: { primaryCurrency: "USD" } })),
    route("get", "/summary").reply(() => ({ status: 200, body: summary })),
    route("get", "/exchange-rates").reply(() => ({
      status: 200,
      body: {
        primaryCurrency: "USD",
        items: [{ currency: "EUR", rate: 1.1, updatedAt: "2026-10-20T10:00:00.000Z" }],
        defaults: [
          { currency: "EUR", rate: 1.16 },
          { currency: "JPY", rate: 0.0066 },
        ],
        defaultsAsOf: "2026-10",
      },
    })),
    route("put", "/exchange-rates/{currency}").reply(async ({ params, request }) => {
      putBody = await request.json();
      return {
        status: 200,
        body: {
          currency: params.currency as "JPY",
          rate: 0.0067,
          updatedAt: "2026-10-28T10:00:00.000Z",
        },
      };
    }),
  );
  renderWithQueryClient(<SettingsPage />);
  return { fetchMock, putBody: () => putBody, user: userEvent.setup() };
}

describe("SettingsPage", () => {
  it("shows custom rates, pre-fills built-in defaults, and flags currencies with neither", async () => {
    setup();

    const rates = await screen.findByRole("region", { name: "Exchange rates" });
    // EUR: the user's own rate overrides the default.
    expect(within(rates).getByLabelText("1 EUR =")).toHaveValue("1.1");
    expect(within(rates).getByText("Custom · updated Oct 20, 2026")).toBeInTheDocument();
    // JPY: no custom rate, so the built-in default applies and is labelled as approximate.
    expect(within(rates).getByLabelText("1 JPY =")).toHaveValue("0.0066");
    expect(within(rates).getByText("Default (approx., Oct 2026)")).toBeInTheDocument();
    // ISK: outside the built-in table.
    expect(within(rates).getByLabelText("1 ISK =")).toHaveValue("");
    expect(within(rates).getByText("No rate — not in totals")).toBeInTheDocument();
    expect(within(rates).queryByLabelText("1 USD =")).not.toBeInTheDocument();
  });

  it("saves a rate", async () => {
    const { fetchMock, putBody, user } = setup();

    const jpy = await screen.findByLabelText("1 JPY =");
    await user.clear(jpy); // pre-filled with the default
    await user.type(jpy, "0.0067");
    await user.click(screen.getByRole("button", { name: "Save JPY rate" }));

    await expect.poll(() => requestsOf(fetchMock)).toContain("PUT /exchange-rates/JPY");
    expect(putBody()).toEqual({ rate: 0.0067 });
  });

  it("rejects a rate that isn't a positive number without calling the API", async () => {
    const { fetchMock, user } = setup();

    const jpy = await screen.findByLabelText("1 JPY =");
    await user.clear(jpy);
    await user.type(jpy, "-2");
    await user.click(screen.getByRole("button", { name: "Save JPY rate" }));

    expect(screen.getByText("Enter a number greater than zero")).toBeInTheDocument();
    expect(requestsOf(fetchMock)).not.toContain("PUT /exchange-rates/JPY");
  });

  it("resets a custom rate back to the default", async () => {
    const { fetchMock, user } = setup([
      route("delete", "/exchange-rates/{currency}").reply(() => ({ status: 204 })),
    ]);

    await user.click(await screen.findByRole("button", { name: "Reset EUR rate to default" }));

    await expect.poll(() => requestsOf(fetchMock)).toContain("DELETE /exchange-rates/EUR");
  });

  it("changes the primary currency, and shows the API's explanation when it's refused", async () => {
    const { fetchMock, user } = setup([
      route("put", "/settings").reply(() => ({
        status: 409,
        body: { error: "RateRequired", message: "Add an exchange rate for GBP first" },
      })),
    ]);

    const currency = await screen.findByLabelText("Currency");
    expect(screen.getByRole("button", { name: "Save" })).toBeDisabled(); // nothing changed yet
    await user.selectOptions(currency, "GBP");
    await user.click(screen.getByRole("button", { name: "Save" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Add an exchange rate for GBP first",
    );
    expect(requestsOf(fetchMock)).toContain("PUT /settings");
  });
});
