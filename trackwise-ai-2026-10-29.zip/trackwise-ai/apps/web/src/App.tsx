import { CreditCard, LayoutDashboard, type LucideIcon, Settings } from "lucide-react";
import { Navigate, NavLink, Route, Routes } from "react-router";
import { HealthStatus } from "./components/HealthStatus";
import { ThemeToggle } from "./components/ThemeToggle";
import { DashboardPage } from "./pages/DashboardPage";
import { EditSubscriptionPage } from "./pages/EditSubscriptionPage";
import { NewSubscriptionPage } from "./pages/NewSubscriptionPage";
import { NotFoundPage } from "./pages/NotFoundPage";
import { SettingsPage } from "./pages/SettingsPage";
import { SubscriptionDetailPage } from "./pages/SubscriptionDetailPage";
import { SubscriptionsPage } from "./pages/SubscriptionsPage";

const navItems: { to: string; label: string; icon: LucideIcon; end?: boolean }[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/subscriptions", label: "Subscriptions", icon: CreditCard },
  { to: "/settings", label: "Settings", icon: Settings },
];

export function App() {
  return (
    <div className="min-h-screen bg-canvas text-ink">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-4 py-3 md:px-6">
          <h1 className="bg-gradient-to-r from-indigo-500 to-violet-500 bg-clip-text text-2xl font-bold tracking-tight text-transparent">
            TrackWise-AI
          </h1>
          <div className="flex items-center gap-4">
            <HealthStatus />
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Sidebar on desktop; the same nav becomes a scrolling top bar on phones. */}
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 md:flex-row md:gap-8 md:px-6 md:py-8">
        <aside className="md:w-56 md:shrink-0">
          <nav
            aria-label="Main"
            className="flex gap-1 overflow-x-auto md:sticky md:top-8 md:flex-col"
          >
            {navItems.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-3 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium ${
                    isActive
                      ? "bg-ink text-canvas"
                      : "text-ink-muted hover:bg-surface-muted hover:text-ink"
                  }`
                }
              >
                <Icon aria-hidden="true" className="size-4" />
                {label}
              </NavLink>
            ))}
          </nav>
        </aside>

        <main className="min-w-0 flex-1">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/subscriptions" element={<SubscriptionsPage />} />
            <Route path="/subscriptions/new" element={<NewSubscriptionPage />} />
            <Route path="/subscriptions/:id" element={<SubscriptionDetailPage />} />
            <Route path="/subscriptions/:id/edit" element={<EditSubscriptionPage />} />
            {/* Analytics was merged into the Dashboard; keep old links working. */}
            <Route path="/analytics" element={<Navigate to="/" replace />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
