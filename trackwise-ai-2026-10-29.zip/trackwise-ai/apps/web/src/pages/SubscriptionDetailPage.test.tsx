import { screen } from "@testing-library/react";
import { Route, Routes } from "react-router";
import { describe, expect, it } from "vitest";
import { aSubscription } from "../test/fixtures";
import { mockApi, route } from "../test/mock-api";
import { renderWithQueryClient } from "../test/render";
import { SubscriptionDetailPage } from "./SubscriptionDetailPage";

function renderAt(id: string) {
  renderWithQueryClient(
    <Routes>
      <Route path="/subscriptions/:id" element={<SubscriptionDetailPage />} />
    </Routes>,
    { route: `/subscriptions/${id}` },
  );
}

describe("SubscriptionDetailPage", () => {
  it("shows the subscription's details, notes and payment history", async () => {
    const subscription = aSubscription({ notes: "Family plan", billingCycle: "yearly" });
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body: subscription })),
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 200,
        body: { items: [] },
      })),
    );

    renderAt(subscription.id);

    expect(await screen.findByRole("heading", { name: "Netflix" })).toBeInTheDocument();
    expect(screen.getByText("Family plan")).toBeInTheDocument();
    expect(screen.getByText("$15.99 yearly")).toBeInTheDocument();
    expect(screen.getByText("Nov 15, 2026")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Edit subscription" })).toHaveAttribute(
      "href",
      `/subscriptions/${subscription.id}/edit`,
    );
    expect(await screen.findByText(/No payments yet/)).toBeInTheDocument();
  });

  it("shows not found for an unknown id", async () => {
    const id = crypto.randomUUID();
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({
        status: 404,
        body: { error: "NotFound", message: "Subscription not found" },
      })),
    );

    renderAt(id);

    expect(await screen.findByRole("alert")).toHaveTextContent("Subscription not found.");
  });
});
