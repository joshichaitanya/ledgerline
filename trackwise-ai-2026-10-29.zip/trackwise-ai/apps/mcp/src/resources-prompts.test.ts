import { describe, expect, it } from "vitest";
import { connectClient } from "./test/connect";
import { aPayment, aSubscription } from "./test/fixtures";
import { mockApi, mockApiDown, route } from "./test/mock-api";

describe("resources", () => {
  const prime = aSubscription({
    name: "Amazon Prime",
    amountMinor: 149_900,
    currency: "INR",
    billingCycle: "yearly",
  });

  it("reads the full list as JSON, formatted for a model", async () => {
    mockApi(
      route("get", "/subscriptions").reply(() => ({ status: 200, body: { items: [prime] } })),
    );
    const client = await connectClient();

    const { contents } = await client.readResource({ uri: "trackwise://subscriptions" });

    expect(contents[0]?.mimeType).toBe("application/json");
    const [content] = contents;
    const list = JSON.parse(content && "text" in content ? content.text : "[]");
    expect(list).toEqual([expect.objectContaining({ name: "Amazon Prime", price: "₹1,499.00" })]);
  });

  it("reports the API being down as an internal error with guidance, not 'not found'", async () => {
    mockApiDown();
    const client = await connectClient();

    await expect(client.readResource({ uri: "trackwise://subscriptions" })).rejects.toMatchObject({
      code: -32603,
      message: expect.stringContaining("not reachable"),
    });
  });

  // Regression: every listed subscription once showed the template's title, "One subscription".
  it("lists the full list plus one resource per subscription, each with its own title", async () => {
    mockApi(
      route("get", "/subscriptions").reply(() => ({ status: 200, body: { items: [prime] } })),
    );
    const client = await connectClient();

    const { resources } = await client.listResources();

    expect(resources).toEqual([
      expect.objectContaining({ uri: "trackwise://subscriptions", title: "All subscriptions" }),
      expect.objectContaining({
        uri: `trackwise://subscriptions/${prime.id}`,
        title: "Amazon Prime",
        description: "₹1,499.00 yearly (streaming), with payment history",
      }),
    ]);
  });

  // Regression: payments were once returned as raw minor units (149900) instead of money.
  it("reads one subscription with its payments formatted as money", async () => {
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({ status: 200, body: prime })),
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 200,
        body: { items: [{ ...aPayment(prime.id, "2026-09-10", 149_900), currency: "INR" }] },
      })),
    );
    const client = await connectClient();

    const { contents } = await client.readResource({
      uri: `trackwise://subscriptions/${prime.id}`,
    });

    const [content] = contents;
    const data = JSON.parse(content && "text" in content ? content.text : "{}");
    expect(data).toMatchObject({ name: "Amazon Prime", price: "₹1,499.00" });
    expect(data.payments).toEqual([{ paidOn: "2026-09-10", amount: "₹1,499.00" }]);
  });

  it("reports an unknown subscription as 'resource not found' (-32002)", async () => {
    mockApi(
      route("get", "/subscriptions/{id}").reply(() => ({
        status: 404,
        body: { error: "NotFound", message: "Subscription not found" },
      })),
      route("get", "/subscriptions/{id}/payments").reply(() => ({
        status: 404,
        body: { error: "NotFound", message: "Subscription not found" },
      })),
    );
    const client = await connectClient();

    await expect(
      client.readResource({ uri: `trackwise://subscriptions/${crypto.randomUUID()}` }),
    ).rejects.toMatchObject({ code: -32002 });
  });
});

describe("prompts", () => {
  it("advertises the monthly review with a described, optional argument", async () => {
    const client = await connectClient();

    const { prompts } = await client.listPrompts();

    expect(prompts).toEqual([
      expect.objectContaining({
        name: "monthly-review",
        title: "Monthly spending review",
        arguments: [
          {
            name: "focusCategory",
            description: "Optional category to look at more closely",
            required: false,
          },
        ],
      }),
    ]);
  });

  it("fills the monthly review template with the chosen category and attaches the list", async () => {
    const client = await connectClient();

    const { messages } = await client.getPrompt({
      name: "monthly-review",
      arguments: { focusCategory: "streaming" },
    });

    expect(messages[0]?.content).toMatchObject({ type: "text" });
    expect(JSON.stringify(messages[0]?.content)).toContain(
      'Pay special attention to the \\"streaming\\" category',
    );
    expect(messages[1]?.content).toMatchObject({
      type: "resource_link",
      uri: "trackwise://subscriptions",
    });
  });

  it("leaves out the focus line when no category is chosen", async () => {
    const client = await connectClient();

    const { messages } = await client.getPrompt({ name: "monthly-review", arguments: {} });

    expect(JSON.stringify(messages[0]?.content)).not.toContain("Pay special attention");
  });

  it("autocompletes the category argument as the user types", async () => {
    const client = await connectClient();

    const { completion } = await client.complete({
      ref: { type: "ref/prompt", name: "monthly-review" },
      argument: { name: "focusCategory", value: "s" },
    });

    expect(completion.values).toEqual(["streaming", "software"]);
  });
});
