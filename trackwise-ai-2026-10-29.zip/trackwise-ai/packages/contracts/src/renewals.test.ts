import { describe, expect, it } from "vitest";
import {
  addMonths,
  advanceRenewalDate,
  daysBetween,
  dueRenewals,
  pastRenewals,
  toIsoDate,
  upcomingRenewals,
} from "./renewals";

describe("date helpers", () => {
  it("takes the UTC calendar date of an instant", () => {
    expect(toIsoDate(new Date("2026-10-28T23:30:00-05:00"))).toBe("2026-10-29");
  });

  it("counts days across months and DST changes", () => {
    expect(daysBetween("2026-10-28", "2026-11-03")).toBe(6);
    expect(daysBetween("2026-03-01", "2026-03-31")).toBe(30);
    expect(daysBetween("2026-11-03", "2026-10-28")).toBe(-6);
  });

  it.each([
    ["2027-01-31", 1, "2027-02-28"],
    ["2028-01-31", 1, "2028-02-29"],
    ["2027-01-31", 2, "2027-03-31"],
    ["2026-12-15", 1, "2027-01-15"],
    ["2028-02-29", 12, "2029-02-28"],
    ["2028-02-29", 48, "2032-02-29"],
    // Years below 100 (Date.UTC would silently map these to 1900–1999).
    ["0020-01-31", 1, "0020-02-29"],
    ["0099-12-15", 1, "0100-01-15"],
  ])("addMonths(%s, %i) → %s", (date, months, expected) => {
    expect(addMonths(date, months)).toBe(expected);
  });
});

describe("advanceRenewalDate", () => {
  const today = "2027-02-15";

  it("keeps a date that is today or later", () => {
    expect(advanceRenewalDate("2027-02-15", "monthly", today)).toBe("2027-02-15");
    expect(advanceRenewalDate("2027-03-01", "weekly", today)).toBe("2027-03-01");
  });

  it("rolls a past weekly date forward in 7-day steps", () => {
    // Feb 1 → 8 → 15 (today counts as upcoming)
    expect(advanceRenewalDate("2027-02-01", "weekly", today)).toBe("2027-02-15");
    expect(advanceRenewalDate("2027-02-02", "weekly", today)).toBe("2027-02-16");
  });

  it("clamps month-end dates to shorter months", () => {
    expect(advanceRenewalDate("2027-01-31", "monthly", today)).toBe("2027-02-28");
    expect(advanceRenewalDate("2028-01-31", "monthly", "2028-02-15")).toBe("2028-02-29");
  });

  it("does not drift: Jan 31 monthly renews on Mar 31, not Mar 28", () => {
    expect(advanceRenewalDate("2027-01-31", "monthly", "2027-03-01")).toBe("2027-03-31");
  });

  it("handles Feb 29 yearly plans", () => {
    expect(advanceRenewalDate("2028-02-29", "yearly", "2029-01-01")).toBe("2029-02-28");
    expect(advanceRenewalDate("2028-02-29", "yearly", "2031-12-31")).toBe("2032-02-29");
  });

  it("rolls dates from the distant past quickly and correctly (found by fuzzing)", () => {
    // Cross-checked with Python datetime: 733,028 days late → next multiple of 7.
    expect(advanceRenewalDate("0020-02-29", "weekly", today)).toBe("2027-02-20");
    expect(advanceRenewalDate("0020-02-29", "yearly", today)).toBe("2027-02-28");
    expect(advanceRenewalDate("0020-01-31", "monthly", today)).toBe("2027-02-28");
  });

  it("rolls dates that are years behind", () => {
    expect(advanceRenewalDate("2020-05-10", "monthly", today)).toBe("2027-03-10");
    expect(advanceRenewalDate("2020-05-10", "yearly", today)).toBe("2027-05-10");
    // 2,602 days late → next multiple of 7 is 2,604.
    expect(advanceRenewalDate("2020-01-01", "weekly", today)).toBe("2027-02-17");
  });
});

describe("upcomingRenewals", () => {
  const today = "2026-10-28";
  const sub = (
    name: string,
    nextRenewalDate: string,
    billingCycle: "weekly" | "monthly" | "yearly" = "monthly",
  ) => ({
    id: crypto.randomUUID(),
    name,
    amountMinor: 1000,
    currency: "USD" as const,
    billingCycle,
    nextRenewalDate,
  });

  it("lists renewals inside the window, soonest first, with days until", () => {
    const result = upcomingRenewals(
      [sub("Later", "2026-11-20"), sub("Today", "2026-10-28"), sub("Tomorrow", "2026-10-29")],
      today,
      30,
    );

    expect(result.asOf).toBe(today);
    expect(result.windowDays).toBe(30);
    expect(result.items.map(({ name, daysUntil }) => [name, daysUntil])).toEqual([
      ["Today", 0],
      ["Tomorrow", 1],
      ["Later", 23],
    ]);
  });

  it("includes the last day of the window and excludes the day after", () => {
    const result = upcomingRenewals(
      [sub("Edge", "2026-11-04"), sub("Outside", "2026-11-05")],
      today,
      7,
    );

    expect(result.items.map((item) => item.name)).toEqual(["Edge"]);
  });

  it("rolls past-due subscriptions forward into the window", () => {
    const result = upcomingRenewals([sub("Overdue", "2026-09-30")], today, 30);

    expect(result.items[0]).toMatchObject({ renewalDate: "2026-10-30", daysUntil: 2 });
  });

  it("lists a weekly plan once, at its next renewal", () => {
    const result = upcomingRenewals([sub("Weekly", "2026-10-30", "weekly")], today, 30);

    expect(result.items).toHaveLength(1);
    expect(result.items[0]?.renewalDate).toBe("2026-10-30");
  });

  it("breaks ties by name", () => {
    const result = upcomingRenewals([sub("B", "2026-10-30"), sub("A", "2026-10-30")], today, 30);

    expect(result.items.map((item) => item.name)).toEqual(["A", "B"]);
  });
});

describe("dueRenewals", () => {
  it("records every missed renewal up to and including today, then the next one", () => {
    expect(dueRenewals("2026-08-31", "2026-08-31", "monthly", "2026-10-31")).toEqual({
      paymentDates: ["2026-08-31", "2026-09-30", "2026-10-31"],
      nextRenewalDate: "2026-11-30",
    });
  });

  it("stays anchored to the original day across short months", () => {
    // Anchor Jan 31; stored next date already clamped to Feb 28.
    expect(dueRenewals("2027-01-31", "2027-02-28", "monthly", "2027-04-01")).toEqual({
      paymentDates: ["2027-02-28", "2027-03-31"],
      nextRenewalDate: "2027-04-30",
    });
  });

  it("does nothing for a future renewal", () => {
    expect(dueRenewals("2026-11-15", "2026-11-15", "monthly", "2026-10-28")).toEqual({
      paymentDates: [],
      nextRenewalDate: "2026-11-15",
    });
  });

  it("only catches up the last year, however old the date", () => {
    const { paymentDates, nextRenewalDate } = dueRenewals(
      "0020-02-29",
      "0020-02-29",
      "weekly",
      "2026-10-28",
    );

    expect(paymentDates.length).toBeLessThanOrEqual(53);
    expect((paymentDates[0] ?? "") >= "2025-10-27").toBe(true);
    expect(nextRenewalDate > "2026-10-28").toBe(true);
  });
});

describe("pastRenewals", () => {
  it("lists earlier renewals within the range, newest first", () => {
    expect(pastRenewals("2026-11-15", "monthly", "2026-08-01", "2026-11-15")).toEqual([
      "2026-10-15",
      "2026-09-15",
      "2026-08-15",
    ]);
  });
});
