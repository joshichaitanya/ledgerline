import { zodResolver } from "@hookform/resolvers/zod";
import { type ReactNode, useId } from "react";
import { type FieldError, useForm } from "react-hook-form";
import { Link } from "react-router";
import type { CreateSubscriptionRequest } from "../api/subscriptions";
import { ApiError } from "../api/subscriptions";
import { billingCycleLabel, categoryLabel } from "../lib/format";
import {
  currencyOptions,
  SubscriptionFormSchema,
  type SubscriptionFormValues,
  toRequest,
} from "../lib/subscription-form";

const billingCycles = ["weekly", "monthly", "yearly"] as const;
const categories = [
  "streaming",
  "music",
  "software",
  "cloud",
  "news",
  "fitness",
  "gaming",
  "other",
] as const;

interface SubscriptionFormProps {
  defaultValues: SubscriptionFormValues;
  submitLabel: string;
  onSubmit: (request: CreateSubscriptionRequest) => void;
  isSubmitting: boolean;
  submitError: Error | null;
}

export function SubscriptionForm({
  defaultValues,
  submitLabel,
  onSubmit,
  isSubmitting,
  submitError,
}: SubscriptionFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SubscriptionFormValues>({
    resolver: zodResolver(SubscriptionFormSchema),
    defaultValues,
  });
  // Keep a currency that isn't in the short list (e.g. created via the API) selectable.
  const currencies = currencyOptions.includes(defaultValues.currency)
    ? currencyOptions
    : [defaultValues.currency, ...currencyOptions];

  return (
    <form
      noValidate
      onSubmit={handleSubmit((values) => onSubmit(toRequest(values)))}
      className="space-y-5 rounded-lg border border-line bg-surface p-6"
    >
      {submitError && <SubmitError error={submitError} />}

      <Field label="Name" error={errors.name}>
        {(props) => <input type="text" {...props} {...register("name")} className={inputClass} />}
      </Field>

      <div className="grid gap-5 sm:grid-cols-[1fr_8rem]">
        <Field label="Amount" error={errors.amount}>
          {(props) => (
            <input
              type="text"
              inputMode="decimal"
              placeholder="9.99"
              {...props}
              {...register("amount")}
              className={inputClass}
            />
          )}
        </Field>
        <Field label="Currency" error={errors.currency}>
          {(props) => (
            <select {...props} {...register("currency")} className={inputClass}>
              {currencies.map((currency) => (
                <option key={currency}>{currency}</option>
              ))}
            </select>
          )}
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Billing cycle" error={errors.billingCycle}>
          {(props) => (
            <select {...props} {...register("billingCycle")} className={inputClass}>
              {billingCycles.map((cycle) => (
                <option key={cycle} value={cycle}>
                  {billingCycleLabel(cycle)}
                </option>
              ))}
            </select>
          )}
        </Field>
        <Field label="Category" error={errors.category}>
          {(props) => (
            <select {...props} {...register("category")} className={inputClass}>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {categoryLabel(category)}
                </option>
              ))}
            </select>
          )}
        </Field>
      </div>

      <Field label="Next renewal date" error={errors.nextRenewalDate}>
        {(props) => (
          <input type="date" {...props} {...register("nextRenewalDate")} className={inputClass} />
        )}
      </Field>

      <Field label="Notes (optional)" error={errors.notes}>
        {(props) => <textarea rows={3} {...props} {...register("notes")} className={inputClass} />}
      </Field>

      <div className="flex items-center gap-3">
        <button
          type="submit"
          disabled={isSubmitting}
          className="rounded-md bg-accent px-4 py-2 text-sm font-medium text-white hover:bg-accent-hover disabled:opacity-50"
        >
          {isSubmitting ? "Saving…" : submitLabel}
        </button>
        <Link to="/subscriptions" className="text-sm font-medium text-ink-muted hover:text-ink">
          Cancel
        </Link>
      </div>
    </form>
  );
}

const inputClass =
  "block w-full rounded-md border border-line-strong px-3 py-2 text-sm shadow-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent aria-[invalid=true]:border-danger";

interface ControlProps {
  id: string;
  "aria-invalid": boolean;
  "aria-describedby": string | undefined;
}

/** Label + control + error message, wired together for screen readers. */
function Field({
  label,
  error,
  children,
}: {
  label: string;
  error: FieldError | undefined;
  children: (props: ControlProps) => ReactNode;
}) {
  const id = useId();
  const errorId = `${id}-error`;
  return (
    <div className="space-y-1">
      <label htmlFor={id} className="block text-sm font-medium text-ink-muted">
        {label}
      </label>
      {children({ id, "aria-invalid": Boolean(error), "aria-describedby": error && errorId })}
      {error && (
        <p id={errorId} className="text-sm text-danger-ink">
          {error.message}
        </p>
      )}
    </div>
  );
}

function SubmitError({ error }: { error: Error }) {
  const issues = error instanceof ApiError ? (error.body?.issues ?? []) : [];
  return (
    <div
      role="alert"
      className="rounded-md border border-danger-line bg-danger-soft p-3 text-sm text-danger-ink"
    >
      <p className="font-medium">Couldn't save the subscription: {error.message}</p>
      {issues.length > 0 && (
        <ul className="mt-1 list-inside list-disc">
          {issues.map((issue) => (
            <li key={`${issue.location}.${issue.path}`}>
              {issue.path}: {issue.message}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
