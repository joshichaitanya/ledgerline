import { execSync } from "node:child_process";
import { databaseUrl } from "./playwright.config";

/**
 * Puts the E2E database into a known state before every run:
 * latest migrations, then the sample data from apps/api/src/db/seed.ts (replacing any rows).
 */
export default function globalSetup() {
  const env = { ...process.env, DATABASE_URL: databaseUrl };
  execSync("pnpm --filter @subtrack/api db:migrate", { env, stdio: "inherit" });
  execSync("pnpm --filter @subtrack/api db:seed --reset", { env, stdio: "inherit" });
}
