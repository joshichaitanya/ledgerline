import { expect, test, utcDateFromToday } from "./support/fixtures";

test.describe("Payment history", () => {
  test("records passed renewals; a payment can be corrected and deleted", async ({
    page,
    arrange,
  }) => {
    // Weekly plan due 15 days ago: renewals 15, 8 and 1 days ago have passed.
    const subscription = await arrange.subscription({
      amountMinor: 500,
      billingCycle: "weekly",
      nextRenewalDate: utcDateFromToday(-15),
    });

    await page.goto("/subscriptions");
    await page.getByRole("link", { name: subscription.name, exact: true }).click();

    await expect(page.getByRole("heading", { name: subscription.name })).toBeVisible();
    const history = page.getByRole("region", { name: "Payment history" });
    const rows = history.getByRole("row");
    await expect(rows).toHaveCount(4); // header + 3 payments
    await expect(history).toContainText("$5.00");

    // Correct the newest payment's amount.
    await history
      .getByRole("button", { name: /^Edit payment of/ })
      .first()
      .click();
    await history.getByLabel("Payment amount").fill("6.50");
    await history.getByRole("button", { name: "Save" }).click();
    await expect(rows.nth(1)).toContainText("$6.50");

    // Delete the oldest payment (a skipped week).
    await history
      .getByRole("button", { name: /^Delete payment of/ })
      .last()
      .click();
    await page.getByRole("alertdialog").getByRole("button", { name: "Delete" }).click();
    await expect(rows).toHaveCount(3);

    // It is not recorded again on reload.
    await page.reload();
    await expect(
      page.getByRole("region", { name: "Payment history" }).getByRole("row"),
    ).toHaveCount(3);
  });
});
