import {
  type CreateSubscriptionRequest,
  ErrorResponseSchema,
  SubscriptionSchema,
} from "@subtrack/contracts";
import { eq } from "drizzle-orm";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { buildApp } from "../src/app";
import { createDatabase } from "../src/db/client";
import { subscriptions } from "../src/db/schema";
import { testDatabaseUrl } from "./test-database";

const database = createDatabase(testDatabaseUrl);
const app = await buildApp({ database });

const netflix: CreateSubscriptionRequest = {
  name: "Netflix",
  amountMinor: 1599,
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "2026-11-15",
};
const missingId = "00000000-0000-4000-8000-000000000000";

async function create(body: CreateSubscriptionRequest = netflix) {
  const response = await app.inject({ method: "POST", url: "/subscriptions", payload: body });
  return SubscriptionSchema.parse(response.json());
}

function errorBody(response: { json: () => unknown }) {
  return ErrorResponseSchema.parse(response.json());
}

beforeEach(async () => {
  await database.db.delete(subscriptions);
});

afterAll(async () => {
  await app.close();
  await database.close();
});

describe("POST /subscriptions", () => {
  it("creates a subscription and returns it with server-owned fields", async () => {
    const response = await app.inject({ method: "POST", url: "/subscriptions", payload: netflix });

    expect(response.statusCode).toBe(201);
    const created = SubscriptionSchema.parse(response.json());
    expect(created).toMatchObject({ ...netflix, notes: null });

    const [stored] = await database.db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.id, created.id));
    expect(stored?.name).toBe("Netflix");
  });

  it("trims text fields", async () => {
    const created = await create({ ...netflix, name: "  Netflix  ", notes: "  4K  " });

    expect(created.name).toBe("Netflix");
    expect(created.notes).toBe("4K");
  });

  it("ignores client-supplied server fields", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/subscriptions",
      payload: { ...netflix, id: missingId, createdAt: "2000-01-01T00:00:00.000Z" },
    });

    const created = SubscriptionSchema.parse(response.json());
    expect(created.id).not.toBe(missingId);
    expect(created.createdAt).not.toBe("2000-01-01T00:00:00.000Z");
  });

  it("returns 400 with one issue per invalid field", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/subscriptions",
      payload: { ...netflix, name: "", amountMinor: -1, currency: "usd" },
    });

    expect(response.statusCode).toBe(400);
    const body = errorBody(response);
    expect(body.error).toBe("ValidationError");
    expect(body.issues).toEqual(
      expect.arrayContaining([
        { path: "name", location: "body", message: "Name is required" },
        { path: "amountMinor", location: "body", message: "Amount must be greater than zero" },
        expect.objectContaining({ path: "currency", location: "body" }),
      ]),
    );
    expect(await database.db.select().from(subscriptions)).toHaveLength(0);
  });

  it("returns 400 for malformed JSON", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/subscriptions",
      headers: { "content-type": "application/json" },
      payload: "{not json",
    });

    expect(response.statusCode).toBe(400);
    expect(errorBody(response).error).toBe("BadRequest");
  });
});

describe("GET /subscriptions/:id", () => {
  it("returns the subscription", async () => {
    const created = await create();

    const response = await app.inject({ method: "GET", url: `/subscriptions/${created.id}` });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual(created);
  });

  it("returns 404 for an unknown id", async () => {
    const response = await app.inject({ method: "GET", url: `/subscriptions/${missingId}` });

    expect(response.statusCode).toBe(404);
    expect(errorBody(response)).toEqual({ error: "NotFound", message: "Subscription not found" });
  });

  it("returns 400 for a malformed id", async () => {
    const response = await app.inject({ method: "GET", url: "/subscriptions/not-a-uuid" });

    expect(response.statusCode).toBe(400);
    expect(errorBody(response).issues).toEqual([
      { path: "id", location: "params", message: "Must be a valid UUID" },
    ]);
  });
});

describe("PATCH /subscriptions/:id", () => {
  it("updates only the provided fields and bumps updatedAt", async () => {
    const created = await create({ ...netflix, notes: "Family plan" });

    const response = await app.inject({
      method: "PATCH",
      url: `/subscriptions/${created.id}`,
      payload: { amountMinor: 1799 },
    });

    expect(response.statusCode).toBe(200);
    const updated = SubscriptionSchema.parse(response.json());
    expect(updated).toMatchObject({ ...netflix, amountMinor: 1799, notes: "Family plan" });
    expect(updated.updatedAt > created.updatedAt).toBe(true);
    expect(updated.createdAt).toBe(created.createdAt);
  });

  it("clears notes with null", async () => {
    const created = await create({ ...netflix, notes: "Family plan" });

    const response = await app.inject({
      method: "PATCH",
      url: `/subscriptions/${created.id}`,
      payload: { notes: null },
    });

    expect(SubscriptionSchema.parse(response.json()).notes).toBeNull();
  });

  it("returns 404 for an unknown id", async () => {
    const response = await app.inject({
      method: "PATCH",
      url: `/subscriptions/${missingId}`,
      payload: { amountMinor: 1799 },
    });

    expect(response.statusCode).toBe(404);
  });

  it.each([
    ["an empty body", {}],
    ["an invalid field", { billingCycle: "daily" }],
  ])("returns 400 for %s and leaves the row unchanged", async (_case, payload) => {
    const created = await create();

    const response = await app.inject({
      method: "PATCH",
      url: `/subscriptions/${created.id}`,
      payload,
    });

    expect(response.statusCode).toBe(400);
    expect(errorBody(response).error).toBe("ValidationError");
    const current = await app.inject({ method: "GET", url: `/subscriptions/${created.id}` });
    expect(current.json()).toEqual(created);
  });
});

describe("DELETE /subscriptions/:id", () => {
  it("deletes the subscription", async () => {
    const created = await create();

    const response = await app.inject({ method: "DELETE", url: `/subscriptions/${created.id}` });

    expect(response.statusCode).toBe(204);
    expect(response.body).toBe("");
    const after = await app.inject({ method: "GET", url: `/subscriptions/${created.id}` });
    expect(after.statusCode).toBe(404);
  });

  it("returns 404 for an unknown id", async () => {
    const response = await app.inject({ method: "DELETE", url: `/subscriptions/${missingId}` });

    expect(response.statusCode).toBe(404);
  });
});

describe("unknown routes", () => {
  it("return the shared error shape", async () => {
    const response = await app.inject({ method: "GET", url: "/nope" });

    expect(response.statusCode).toBe(404);
    expect(errorBody(response)).toEqual({
      error: "NotFound",
      message: "Route GET /nope not found",
    });
  });
});

// Regression tests for contract-fuzzing (Schemathesis) findings.
describe("fuzzing regressions", () => {
  it("rejects currencies outside the published ISO 4217 list (ST202: spec and API agree)", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/subscriptions",
      payload: { ...netflix, currency: "AAA" },
    });

    expect(response.statusCode).toBe(400);
    expect(errorBody(response).issues).toEqual([
      { path: "currency", location: "body", message: "Unsupported currency" },
    ]);
  });

  it("rejects amounts above the maximum instead of overflowing totals (ST101)", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/subscriptions",
      payload: { ...netflix, amountMinor: 1_000_000_001 },
    });

    expect(response.statusCode).toBe(400);
    expect(errorBody(response).issues).toEqual([
      { path: "amountMinor", location: "body", message: "Amount is too large" },
    ]);
  });

  it.each([
    ["a whitespace-only name", " ", "Name is required"],
    [
      "a name that is 101 characters before trimming",
      ` ${"*".repeat(100)}`,
      "Name must be 100 characters or fewer",
    ],
  ])(
    "rejects %s, exactly as the published schema says (ST201/ST202)",
    async (_case, name, message) => {
      const response = await app.inject({
        method: "POST",
        url: "/subscriptions",
        payload: { ...netflix, name },
      });

      expect(response.statusCode).toBe(400);
      expect(errorBody(response).issues).toEqual([{ path: "name", location: "body", message }]);
    },
  );

  it.each([
    ["name", { name: "Net\u0000flix" }],
    ["notes", { notes: "4K\u0000" }],
  ])(
    "rejects a NUL character in %s with 400, not a database 500 (ST101)",
    async (field, fields) => {
      const response = await app.inject({
        method: "POST",
        url: "/subscriptions",
        payload: { ...netflix, ...fields },
      });

      expect(response.statusCode).toBe(400);
      expect(errorBody(response).issues).toEqual([
        { path: field, location: "body", message: "Must not contain null characters" },
      ]);
    },
  );

  it("ignores a __proto__ key like any other unknown key, without polluting objects (ST202)", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/subscriptions",
      headers: { "content-type": "application/json" },
      payload: `{"__proto__": {"polluted": true}, ${JSON.stringify(netflix).slice(1)}`,
    });

    expect(response.statusCode).toBe(201);
    expect(SubscriptionSchema.parse(response.json()).name).toBe("Netflix");
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
  });

  it.each([
    ["TRACE", "/subscriptions", "GET, HEAD, POST"],
    ["PUT", `/subscriptions/${missingId}`, "DELETE, GET, HEAD, PATCH"],
    // QUERY fails body parsing before routing in Fastify; it must still be a 405.
    ["QUERY", `/subscriptions/${missingId}`, "DELETE, GET, HEAD, PATCH"],
    ["TRACE", "/summary?renewalWindowDays=30", "GET, HEAD"],
  ])("answers %s %s with 405 and an Allow header (ST204)", async (method, url, allow) => {
    const response = await app.inject({ method: method as "GET", url });

    expect(response.statusCode).toBe(405);
    expect(response.headers.allow).toBe(allow);
    expect(errorBody(response).error).toBe("MethodNotAllowed");
  });
});
