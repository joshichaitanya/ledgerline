import { eq } from "drizzle-orm";
import { afterAll, beforeEach, describe, expect, it } from "vitest";
import { createDatabase } from "../../src/db/client";
import { type NewSubscriptionRow, subscriptions } from "../../src/db/schema";
import { sampleSubscriptions, seed } from "../../src/db/seed";
import { testDatabaseUrl } from "../test-database";

const database = createDatabase(testDatabaseUrl);
const { db } = database;

const netflix: NewSubscriptionRow = {
  name: "Netflix",
  amountMinor: 1599,
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "2026-11-15",
};

/** Postgres error code of a rejected insert (drizzle wraps the driver error in `cause`). */
async function insertErrorCode(row: Record<string, unknown>): Promise<string | undefined> {
  try {
    await db.insert(subscriptions).values(row as NewSubscriptionRow);
  } catch (error) {
    return ((error as { cause?: { code?: string } }).cause ?? (error as { code?: string })).code;
  }
  return undefined;
}

beforeEach(async () => {
  await db.delete(subscriptions);
});

afterAll(async () => {
  await database.close();
});

describe("subscriptions table", () => {
  it("fills defaults and round-trips column types", async () => {
    const [row] = await db.insert(subscriptions).values(netflix).returning();

    expect(row).toMatchObject({ ...netflix, notes: null });
    expect(row?.id).toMatch(/^[0-9a-f-]{36}$/);
    expect(row?.createdAt).toBeInstanceOf(Date);
    expect(typeof row?.amountMinor).toBe("number");
    expect(row?.nextRenewalDate).toBe("2026-11-15");
  });

  it("stores the maximum amount, which is beyond the 32-bit integer range", async () => {
    const [row] = await db
      .insert(subscriptions)
      .values({ ...netflix, amountMinor: 1_000_000_000 })
      .returning();

    expect(row?.amountMinor).toBe(1_000_000_000);
  });

  it("bumps updatedAt on update", async () => {
    const [created] = await db.insert(subscriptions).values(netflix).returning();
    if (!created) throw new Error("insert returned no row");

    const [updated] = await db
      .update(subscriptions)
      .set({ name: "Netflix Premium" })
      .where(eq(subscriptions.id, created.id))
      .returning();

    expect(updated?.updatedAt.getTime()).toBeGreaterThan(created.updatedAt.getTime());
  });

  it.each([
    ["zero amount", { amountMinor: 0 }, "23514"],
    ["negative amount", { amountMinor: -1 }, "23514"],
    ["amount above the maximum", { amountMinor: 1_000_000_001 }, "23514"],
    ["lowercase currency", { currency: "usd" }, "23514"],
    ["unknown billing cycle", { billingCycle: "daily" }, "22P02"],
    ["unknown category", { category: "food" }, "22P02"],
    ["missing name", { name: null }, "23502"],
  ])("rejects %s", async (_case, overrides, expectedCode) => {
    // 23514 = check_violation, 22P02 = invalid enum value, 23502 = not_null_violation
    expect(await insertErrorCode({ ...netflix, ...overrides })).toBe(expectedCode);
  });
});

describe("seed", () => {
  it("inserts sample data into an empty table", async () => {
    await seed(database);

    const rows = await db.select().from(subscriptions);
    expect(rows).toHaveLength(sampleSubscriptions().length);
  });

  it("does not duplicate rows when run twice", async () => {
    await seed(database);
    const message = await seed(database);

    expect(message).toMatch(/skipped/);
    expect(await db.select().from(subscriptions)).toHaveLength(sampleSubscriptions().length);
  });

  it("replaces existing rows with reset", async () => {
    await db.insert(subscriptions).values({ ...netflix, name: "Custom" });

    await seed(database, { reset: true });

    const names = (await db.select().from(subscriptions)).map((row) => row.name);
    expect(names).not.toContain("Custom");
    expect(names).toHaveLength(sampleSubscriptions().length);
  });
});
