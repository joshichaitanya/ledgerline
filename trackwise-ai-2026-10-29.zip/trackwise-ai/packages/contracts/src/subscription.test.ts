import { describe, expect, it } from "vitest";
import { z } from "zod";
import { CURRENCY_CODES } from "./currencies";
import { minorUnitDigits } from "./money";
import {
  CreateSubscriptionRequestSchema,
  CurrencySchema,
  type Subscription,
  SubscriptionSchema,
  UpdateSubscriptionRequestSchema,
} from "./subscription";

const valid: Subscription = {
  id: "0b8f3a52-6a1e-4c3f-9a3e-2d1f5c7b9e10",
  name: "Netflix",
  amountMinor: 1599,
  currency: "USD",
  billingCycle: "monthly",
  category: "streaming",
  nextRenewalDate: "2026-11-15",
  notes: null,
  createdAt: "2026-10-28T12:00:00.000Z",
  updatedAt: "2026-10-28T12:00:00.000Z",
};

const parseWith = (overrides: Record<string, unknown>) =>
  SubscriptionSchema.safeParse({ ...valid, ...overrides });

describe("SubscriptionSchema", () => {
  it("accepts a valid subscription", () => {
    expect(SubscriptionSchema.parse(valid)).toEqual(valid);
  });

  it("trims the name", () => {
    expect(SubscriptionSchema.parse({ ...valid, name: "  Spotify  " }).name).toBe("Spotify");
  });

  it("accepts notes", () => {
    expect(parseWith({ notes: "Family plan" }).success).toBe(true);
  });

  it.each([
    ["empty name", { name: "" }],
    ["whitespace-only name", { name: "   " }],
    ["name over 100 characters", { name: "x".repeat(101) }],
    ["zero amount", { amountMinor: 0 }],
    ["negative amount", { amountMinor: -100 }],
    ["fractional amount", { amountMinor: 15.99 }],
    ["amount above the maximum", { amountMinor: 1_000_000_001 }],
    ["lowercase currency", { currency: "usd" }],
    ["unknown currency", { currency: "XYZ" }],
    ["unknown billing cycle", { billingCycle: "daily" }],
    ["unknown category", { category: "food" }],
    ["impossible date", { nextRenewalDate: "2026-02-30" }],
    ["datetime instead of date", { nextRenewalDate: "2026-11-15T00:00:00Z" }],
    ["notes over 500 characters", { notes: "x".repeat(501) }],
    ["non-uuid id", { id: "123" }],
  ])("rejects %s", (_case, overrides) => {
    expect(parseWith(overrides).success).toBe(false);
  });
});

describe("CreateSubscriptionRequestSchema", () => {
  const { id: _id, createdAt: _createdAt, updatedAt: _updatedAt, ...request } = valid;

  it("accepts a request without notes", () => {
    const { notes: _notes, ...withoutNotes } = request;
    expect(CreateSubscriptionRequestSchema.parse(withoutNotes)).toEqual(withoutNotes);
  });

  it("strips server-owned fields", () => {
    expect(CreateSubscriptionRequestSchema.parse(valid)).not.toHaveProperty("id");
  });

  it("returns user-facing messages", () => {
    const result = CreateSubscriptionRequestSchema.safeParse({
      ...request,
      name: " ",
      amountMinor: 0,
      nextRenewalDate: "soon",
    });
    expect(result.success).toBe(false);
    expect(result.error?.issues.map((issue) => [issue.path.join("."), issue.message])).toEqual([
      ["name", "Name is required"],
      ["amountMinor", "Amount must be greater than zero"],
      ["nextRenewalDate", "Enter a valid date"],
    ]);
  });
});

describe("UpdateSubscriptionRequestSchema", () => {
  it("accepts a partial update", () => {
    expect(UpdateSubscriptionRequestSchema.parse({ amountMinor: 1799 })).toEqual({
      amountMinor: 1799,
    });
  });

  it("accepts clearing notes", () => {
    expect(UpdateSubscriptionRequestSchema.parse({ notes: null })).toEqual({ notes: null });
  });

  it("publishes name rules that hold before trimming (maxLength, non-blank, no NUL)", () => {
    const schema = z.toJSONSchema(CreateSubscriptionRequestSchema, { io: "input" }) as {
      $defs: Record<string, { properties: Record<string, unknown> }>;
    };
    const name = schema.$defs.CreateSubscriptionRequest?.properties.name;
    expect(name).toEqual({
      type: "string",
      maxLength: 100,
      allOf: [{ pattern: "\\S" }, { pattern: "^[^\\u0000]*$" }],
    });
  });

  it("publishes the at-least-one-field rule in JSON Schema", () => {
    // Registered schemas are emitted under $defs.
    expect(JSON.stringify(z.toJSONSchema(UpdateSubscriptionRequestSchema))).toContain(
      `"minProperties":1`,
    );
  });

  it("rejects an empty update", () => {
    expect(UpdateSubscriptionRequestSchema.safeParse({}).error?.issues[0]?.message).toBe(
      "Provide at least one field to update",
    );
  });

  it("still validates provided fields", () => {
    expect(UpdateSubscriptionRequestSchema.safeParse({ currency: "usd" }).success).toBe(false);
  });
});

describe("CurrencySchema", () => {
  it("accepts every published code, and each one formats in this runtime", () => {
    for (const code of CURRENCY_CODES) {
      expect(CurrencySchema.safeParse(code).success).toBe(true);
      expect(() => minorUnitDigits(code)).not.toThrow();
    }
  });

  it.each(["AAA", "usd", "US", ""])("rejects %j", (code) => {
    expect(CurrencySchema.safeParse(code).error?.issues[0]?.message).toBe("Unsupported currency");
  });
});
