import { pastRenewals } from "@subtrack/contracts";
import { count } from "drizzle-orm";
import type { Database } from "./client";
import {
  appSettings,
  exchangeRates,
  type NewSubscriptionRow,
  payments,
  subscriptions,
} from "./schema";

/** A date `days` from today as YYYY-MM-DD, so seeded renewals always look current. */
function daysFromToday(days: number): string {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

export function sampleSubscriptions(): NewSubscriptionRow[] {
  return [
    {
      name: "Netflix",
      amountMinor: 1599,
      currency: "USD",
      billingCycle: "monthly",
      category: "streaming",
      nextRenewalDate: daysFromToday(3),
    },
    {
      name: "Spotify",
      amountMinor: 1199,
      currency: "USD",
      billingCycle: "monthly",
      category: "music",
      nextRenewalDate: daysFromToday(12),
    },
    {
      name: "GitHub Copilot",
      amountMinor: 10000,
      currency: "USD",
      billingCycle: "yearly",
      category: "software",
      nextRenewalDate: daysFromToday(140),
    },
    {
      name: "iCloud+",
      amountMinor: 299,
      currency: "USD",
      billingCycle: "monthly",
      category: "cloud",
      nextRenewalDate: daysFromToday(20),
    },
    {
      name: "The Economist",
      amountMinor: 699,
      currency: "USD",
      billingCycle: "weekly",
      category: "news",
      nextRenewalDate: daysFromToday(1),
    },
    {
      name: "Strava",
      amountMinor: 7999,
      currency: "USD",
      billingCycle: "yearly",
      category: "fitness",
      nextRenewalDate: daysFromToday(45),
    },
    {
      name: "Xbox Game Pass",
      amountMinor: 1999,
      currency: "USD",
      billingCycle: "monthly",
      category: "gaming",
      nextRenewalDate: daysFromToday(27),
      notes: "Ultimate tier",
    },
    {
      name: "Disney+",
      amountMinor: 999,
      currency: "EUR",
      billingCycle: "monthly",
      category: "streaming",
      nextRenewalDate: daysFromToday(8),
      notes: "Shared with family",
    },
    {
      name: "Nintendo Switch Online",
      amountMinor: 2400,
      currency: "JPY",
      billingCycle: "yearly",
      category: "gaming",
      nextRenewalDate: daysFromToday(200),
    },
    // Indian services, priced in INR (approximate list prices). Converted to the primary
    // currency with the built-in default rate unless the user sets their own.
    {
      name: "Airtel Xstream Fiber",
      amountMinor: 79_900,
      currency: "INR",
      billingCycle: "monthly",
      category: "other", // broadband: no utilities/internet category yet
      nextRenewalDate: daysFromToday(5),
      notes: "100 Mbps broadband",
    },
    {
      name: "Amazon Prime",
      amountMinor: 149_900,
      currency: "INR",
      billingCycle: "yearly",
      category: "streaming",
      nextRenewalDate: daysFromToday(60),
      notes: "Prime Video + free delivery",
    },
    {
      name: "Hotstar",
      amountMinor: 89_900,
      currency: "INR",
      billingCycle: "yearly",
      category: "streaming",
      nextRenewalDate: daysFromToday(95),
    },
    {
      name: "SonyLIV",
      amountMinor: 99_900,
      currency: "INR",
      billingCycle: "yearly",
      category: "streaming",
      nextRenewalDate: daysFromToday(170),
    },
    {
      name: "PS Plus",
      amountMinor: 299_900,
      currency: "INR",
      billingCycle: "yearly",
      category: "gaming",
      nextRenewalDate: daysFromToday(230),
      notes: "PlayStation Plus Essential",
    },
  ];
}

/**
 * Inserts sample data. Only touches an empty table unless `reset` is set,
 * so running it twice never duplicates rows or silently deletes your data.
 */
export async function seed({ db }: Database, { reset = false } = {}): Promise<string> {
  if (reset) {
    await db.delete(subscriptions);
    await db.delete(exchangeRates);
    await db.delete(appSettings);
  } else {
    const [row] = await db.select({ total: count() }).from(subscriptions);
    const total = row?.total ?? 0;
    if (total > 0) {
      return `subscriptions already has ${total} rows; skipped (use --reset to replace them)`;
    }
  }
  const inserted = await db.insert(subscriptions).values(sampleSubscriptions()).returning();

  // A year of payment history, so trends and Year-to-Date have real data from the start.
  const today = new Date().toISOString().slice(0, 10);
  const history = inserted.flatMap((subscription) =>
    pastRenewals(
      subscription.nextRenewalDate,
      subscription.billingCycle,
      daysFromToday(-365),
      today,
    ).map((paidOn) => ({
      subscriptionId: subscription.id,
      paidOn,
      amountMinor: subscription.amountMinor,
      currency: subscription.currency,
    })),
  );
  if (history.length > 0) await db.insert(payments).values(history);
  return `Inserted ${inserted.length} subscriptions and ${history.length} past payments`;
}
