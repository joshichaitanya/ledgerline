import { describe, expect, it } from "vitest";
import { billingCycleLabel, categoryLabel, formatDate } from "./format";

describe("formatDate", () => {
  it("formats a date-only value", () => {
    expect(formatDate("2026-11-15")).toBe("Nov 15, 2026");
  });

  it("does not shift the day at year boundaries", () => {
    // Parsed as local time, this would show Dec 31 in timezones west of UTC.
    expect(formatDate("2027-01-01")).toBe("Jan 1, 2027");
  });
});

describe("labels", () => {
  it("labels billing cycles", () => {
    expect(billingCycleLabel("weekly")).toBe("Weekly");
    expect(billingCycleLabel("yearly")).toBe("Yearly");
  });

  it("capitalises categories", () => {
    expect(categoryLabel("streaming")).toBe("Streaming");
  });
});
