import swagger from "@fastify/swagger";
import Fastify, { type FastifyServerOptions } from "fastify";
import {
  jsonSchemaTransform,
  jsonSchemaTransformObject,
  serializerCompiler,
  validatorCompiler,
  type ZodTypeProvider,
} from "fastify-type-provider-zod";
import type { Database } from "./db/client";
import { registerErrorHandling } from "./errors";
import { analyticsRoutes } from "./routes/analytics";
import { healthRoutes } from "./routes/health";
import { paymentRoutes } from "./routes/payments";
import { settingsRoutes } from "./routes/settings";
import { subscriptionRoutes } from "./routes/subscriptions";
import { summaryRoutes } from "./routes/summary";

export interface AppDependencies {
  database: Database;
  logger?: FastifyServerOptions["logger"];
  /** Current time; injectable so tests can pin "today". */
  now?: () => Date;
}

/** Builds the app without listening, so tests can drive it with `app.inject()`. */
export async function buildApp({
  database,
  logger = false,
  now = () => new Date(),
}: AppDependencies) {
  const app = Fastify({
    logger,
    // Strip `__proto__` / `constructor.prototype` keys from JSON bodies (prototype-pollution
    // protection) instead of rejecting the request, matching how other unknown keys are ignored.
    onProtoPoisoning: "remove",
    onConstructorPoisoning: "remove",
  }).withTypeProvider<ZodTypeProvider>();

  // Zod schemas validate requests and serialize (and check) responses.
  app.setValidatorCompiler(validatorCompiler);
  app.setSerializerCompiler(serializerCompiler);

  await app.register(swagger, {
    openapi: {
      openapi: "3.1.0",
      info: {
        title: "TrackWise-AI API",
        version: "0.1.0",
        description:
          "Track subscriptions, spending and renewals. Amounts are integer minor units (e.g. cents).",
      },
      servers: [
        { url: "http://localhost:3000", description: "Local API (direct)" },
        { url: "http://localhost:5173/api", description: "Local API via the web dev server proxy" },
      ],
      tags: [
        { name: "system", description: "Health and diagnostics" },
        { name: "subscriptions", description: "Create, read, update and delete subscriptions" },
        { name: "summary", description: "Spending totals and upcoming renewals" },
        { name: "settings", description: "Primary currency and exchange rates" },
        { name: "payments", description: "Recorded payment history" },
        { name: "analytics", description: "Spending trends, forecasts and expenditure" },
      ],
      // No authentication yet (single user, Phase 1). Declared explicitly rather than omitted.
      security: [],
    },
    transform: jsonSchemaTransform,
    // Emits schemas registered with `.meta({ id })` as reusable `components.schemas`.
    transformObject: jsonSchemaTransformObject,
  });

  registerErrorHandling(app);

  await app.register(healthRoutes, { database });
  await app.register(subscriptionRoutes, { database, now });
  await app.register(paymentRoutes, { database, now });
  await app.register(analyticsRoutes, { database, now });
  await app.register(summaryRoutes, { database, now });
  await app.register(settingsRoutes, { database });

  return app;
}
