import { z } from "zod";
import { CurrencySchema, MAX_AMOUNT_MINOR } from "./subscription";

/**
 * A recorded payment. Created automatically when a renewal date passes, at the subscription's
 * price on that day; editable afterwards (e.g. a price change or a skipped month).
 */
export const PaymentSchema = z
  .object({
    id: z.uuid(),
    subscriptionId: z.uuid(),
    paidOn: z.iso.date(),
    amountMinor: z
      .int("Amount must be a whole number of minor units")
      .positive("Amount must be greater than zero")
      .max(MAX_AMOUNT_MINOR, "Amount is too large"),
    /** The subscription's currency at the time of payment. */
    currency: CurrencySchema,
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
  })
  .meta({ id: "Payment" });

export const PaymentListResponseSchema = z
  .object({
    /** Newest first. */
    items: z.array(PaymentSchema),
  })
  .meta({ id: "PaymentListResponse" });

export const UpdatePaymentRequestSchema = z
  .object({
    amountMinor: PaymentSchema.shape.amountMinor,
    paidOn: z.iso.date("Enter a valid date"),
  })
  .partial()
  .refine((patch) => Object.keys(patch).length > 0, "Provide at least one field to update")
  .meta({ id: "UpdatePaymentRequest", minProperties: 1 });

export const PaymentIdParamsSchema = z.object({ id: z.uuid("Must be a valid UUID") });

export type Payment = z.infer<typeof PaymentSchema>;
export type UpdatePaymentRequest = z.infer<typeof UpdatePaymentRequestSchema>;
