import {
  BillingCycleSchema,
  CategorySchema,
  type Currency,
  MAX_AMOUNT_MINOR,
} from "@subtrack/contracts";
import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  char,
  check,
  date,
  doublePrecision,
  index,
  pgEnum,
  pgTable,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";

// Enum values come from the contracts, so the DB and API can't disagree on them.
export const billingCycleEnum = pgEnum("billing_cycle", BillingCycleSchema.enum);
export const categoryEnum = pgEnum("category", CategorySchema.enum);

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    // bigint so the full safe-integer range allowed by the contract fits.
    amountMinor: bigint("amount_minor", { mode: "number" }).notNull(),
    // Only codes from the contract get stored (validated by the API, format-checked below).
    currency: char("currency", { length: 3 }).$type<Currency>().notNull(),
    billingCycle: billingCycleEnum("billing_cycle").notNull(),
    category: categoryEnum("category").notNull(),
    nextRenewalDate: date("next_renewal_date", { mode: "string" }).notNull(),
    // Internal: the date renewals are counted from, so month-end dates don't drift once
    // nextRenewalDate is advanced (Jan 31 → Feb 28 → Mar 31). Null = nextRenewalDate.
    renewalAnchorDate: date("renewal_anchor_date", { mode: "string" }),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    // Last line of defence: the API validates first, but the DB never stores bad money.
    check(
      "subscriptions_amount_minor_range",
      sql`${table.amountMinor} between 1 and ${sql.raw(String(MAX_AMOUNT_MINOR))}`,
    ),
    check("subscriptions_currency_format", sql`${table.currency} ~ '^[A-Z]{3}$'`),
    index("subscriptions_next_renewal_date_idx").on(table.nextRenewalDate),
  ],
);

export type SubscriptionRow = typeof subscriptions.$inferSelect;
export type NewSubscriptionRow = typeof subscriptions.$inferInsert;

/** Single-row table (the check keeps it that way); missing row = defaults. */
export const appSettings = pgTable(
  "app_settings",
  {
    id: boolean("id").primaryKey().default(true),
    primaryCurrency: char("primary_currency", { length: 3 }).$type<Currency>().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [check("app_settings_single_row", sql`${table.id}`)],
);

/** "1 {currency} = {rate} {primary currency}", entered manually. */
export const exchangeRates = pgTable(
  "exchange_rates",
  {
    currency: char("currency", { length: 3 }).$type<Currency>().primaryKey(),
    // A display-time conversion factor, so double precision is appropriate (never stored money).
    rate: doublePrecision("rate").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [check("exchange_rates_rate_positive", sql`${table.rate} > 0`)],
);

/** Recorded payments: created automatically as renewals pass, editable by the user. */
export const payments = pgTable(
  "payments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    subscriptionId: uuid("subscription_id")
      .notNull()
      .references(() => subscriptions.id, { onDelete: "cascade" }),
    paidOn: date("paid_on", { mode: "string" }).notNull(),
    amountMinor: bigint("amount_minor", { mode: "number" }).notNull(),
    currency: char("currency", { length: 3 }).$type<Currency>().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    // One payment per renewal: makes recording idempotent under concurrent requests.
    unique("payments_subscription_paid_on_unique").on(table.subscriptionId, table.paidOn),
    check(
      "payments_amount_minor_range",
      sql`${table.amountMinor} between 1 and ${sql.raw(String(MAX_AMOUNT_MINOR))}`,
    ),
    index("payments_paid_on_idx").on(table.paidOn),
  ],
);

export type PaymentRow = typeof payments.$inferSelect;
