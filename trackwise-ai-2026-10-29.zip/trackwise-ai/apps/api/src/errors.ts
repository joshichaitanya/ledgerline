import type { ErrorResponse } from "@subtrack/contracts";
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import {
  hasZodFastifySchemaValidationErrors,
  isResponseSerializationError,
} from "fastify-type-provider-zod";

type IssueLocation = NonNullable<ErrorResponse["issues"]>[number]["location"];

/** Maps every error to the shared ErrorResponse shape; internals are logged, never leaked. */
export function registerErrorHandling(app: FastifyInstance) {
  // Remember every route so an unknown *method* on a known *path* gets 405, not 404.
  const routes: { method: string; pattern: RegExp }[] = [];
  app.addHook("onRoute", (route) => {
    const pattern = new RegExp(`^${route.url.replace(/:[^/]+/g, "[^/]+")}/?$`);
    for (const method of [route.method].flat()) {
      routes.push({ method: method.toUpperCase(), pattern });
    }
  });

  /** Replies 405 + Allow if the path exists under other methods; otherwise returns undefined. */
  function methodNotAllowed(request: FastifyRequest, reply: FastifyReply) {
    const path = request.url.split("?")[0] ?? request.url;
    const allowed = [
      ...new Set(routes.filter((route) => route.pattern.test(path)).map((route) => route.method)),
    ].sort();
    if (allowed.length === 0) return undefined;
    return reply
      .code(405)
      .header("allow", allowed.join(", "))
      .send({
        error: "MethodNotAllowed",
        message: `${request.method} is not allowed on ${path}`,
      } satisfies ErrorResponse);
  }

  app.setErrorHandler((error, request, reply) => {
    if (hasZodFastifySchemaValidationErrors(error)) {
      const location = (error.validationContext ?? "body") as IssueLocation;
      return reply.code(400).send({
        error: "ValidationError",
        message: "Request validation failed",
        issues: error.validation.map((issue) => ({
          path: issue.instancePath.slice(1).replaceAll("/", "."),
          location,
          message: issue.message ?? "Invalid value",
        })),
      } satisfies ErrorResponse);
    }

    if (isResponseSerializationError(error)) {
      request.log.error({ err: error, issues: error.cause.issues }, "response violates schema");
      return reply.code(500).send(internalError());
    }

    // Fastify's own client errors, e.g. malformed JSON. Mapped to stable codes so the
    // contract doesn't expose framework internals like FST_ERR_CTP_INVALID_JSON_BODY.
    const statusCode = (error as { statusCode?: number }).statusCode ?? 500;
    if (statusCode >= 400 && statusCode < 500) {
      // Some methods (e.g. QUERY) fail body parsing before routing; still answer 405 for them.
      if (!request.routeOptions.url) {
        const handled = methodNotAllowed(request, reply);
        if (handled) return handled;
      }
      return reply.code(statusCode).send({
        error: clientErrorCodes[statusCode] ?? "ClientError",
        message: (error as Error).message,
      } satisfies ErrorResponse);
    }

    request.log.error({ err: error }, "unhandled error");
    return reply.code(500).send(internalError());
  });

  app.setNotFoundHandler((request, reply) => {
    return (
      methodNotAllowed(request, reply) ??
      reply.code(404).send({
        error: "NotFound",
        message: `Route ${request.method} ${request.url} not found`,
      } satisfies ErrorResponse)
    );
  });
}

const clientErrorCodes: Record<number, string> = {
  400: "BadRequest",
  413: "PayloadTooLarge",
  415: "UnsupportedMediaType",
};

function internalError(): ErrorResponse {
  return { error: "InternalServerError", message: "Something went wrong" };
}
