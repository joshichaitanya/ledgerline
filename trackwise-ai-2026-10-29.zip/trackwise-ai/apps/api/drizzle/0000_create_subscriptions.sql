CREATE TYPE "public"."billing_cycle" AS ENUM('weekly', 'monthly', 'yearly');--> statement-breakpoint
CREATE TYPE "public"."category" AS ENUM('streaming', 'music', 'software', 'cloud', 'news', 'fitness', 'gaming', 'other');--> statement-breakpoint
CREATE TABLE "subscriptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"amount_minor" bigint NOT NULL,
	"currency" char(3) NOT NULL,
	"billing_cycle" "billing_cycle" NOT NULL,
	"category" "category" NOT NULL,
	"next_renewal_date" date NOT NULL,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "subscriptions_amount_minor_positive" CHECK ("subscriptions"."amount_minor" > 0),
	CONSTRAINT "subscriptions_currency_format" CHECK ("subscriptions"."currency" ~ '^[A-Z]{3}$')
);
--> statement-breakpoint
CREATE INDEX "subscriptions_next_renewal_date_idx" ON "subscriptions" USING btree ("next_renewal_date");