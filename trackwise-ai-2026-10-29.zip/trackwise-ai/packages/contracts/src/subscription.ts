import { z } from "zod";
import { CURRENCY_CODES } from "./currencies";

export const BillingCycleSchema = z
  .enum(["weekly", "monthly", "yearly"], { error: "Choose a billing cycle" })
  .meta({ id: "BillingCycle" });

/** ISO 4217 code, e.g. "USD". The full list is published in the spec as an enum. */
export const CurrencySchema = z
  .enum(CURRENCY_CODES, { error: "Unsupported currency" })
  .meta({ id: "Currency" });

export const CategorySchema = z
  .enum(["streaming", "music", "software", "cloud", "news", "fitness", "gaming", "other"], {
    error: "Choose a category",
  })
  .meta({ id: "Category" });

/**
 * Largest price per billing cycle, in minor units ($10M, or ¥1B for zero-decimal currencies).
 * Keeps yearly totals far inside JavaScript's safe-integer range (found by contract fuzzing).
 */
export const MAX_AMOUNT_MINOR = 1_000_000_000;

/** Postgres `text` can't store NUL (U+0000); reject it up front instead of failing in the DB. */
// biome-ignore lint/suspicious/noControlCharactersInRegex: matching NUL is the point of this rule.
const NO_NUL = /^[^\u0000]*$/;
const NO_NUL_MESSAGE = "Must not contain null characters";

// Field rules shared by the response and request schemas. Messages are user-facing:
// the API returns them in validation errors and the web form shows them as-is.
const fields = {
  // Checks run in order. Length and "not blank" are checked on the raw input, *then* the value
  // is trimmed, so the published JSON Schema (maxLength, pattern) matches behaviour exactly.
  // (Found by contract fuzzing: trimming first let 101-char input through and rejected " ".)
  name: z
    .string()
    .max(100, "Name must be 100 characters or fewer")
    .regex(/\S/, "Name is required")
    .regex(NO_NUL, NO_NUL_MESSAGE)
    .trim(),
  /** Price per billing cycle in the currency's minor unit (e.g. cents). Never a float. */
  amountMinor: z
    .int("Amount must be a whole number of minor units")
    .positive("Amount must be greater than zero")
    .max(MAX_AMOUNT_MINOR, "Amount is too large"),
  currency: CurrencySchema,
  billingCycle: BillingCycleSchema,
  category: CategorySchema,
  /** Calendar date (YYYY-MM-DD) with no time or timezone. */
  nextRenewalDate: z.iso.date("Enter a valid date"),
  notes: z
    .string()
    .max(500, "Notes must be 500 characters or fewer")
    .regex(NO_NUL, NO_NUL_MESSAGE)
    .trim()
    .nullable(),
};

export const SubscriptionSchema = z
  .object({
    id: z.uuid(),
    ...fields,
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
  })
  .meta({ id: "Subscription" });

/** Wrapped in an object so pagination or totals can be added without a breaking change. */
export const SubscriptionListResponseSchema = z
  .object({ items: z.array(SubscriptionSchema) })
  .meta({ id: "SubscriptionListResponse" });

/** Body of POST /subscriptions. The server owns id and timestamps; notes may be omitted. */
export const CreateSubscriptionRequestSchema = z
  .object({ ...fields, notes: fields.notes.optional() })
  .meta({ id: "CreateSubscriptionRequest" });

/** Body of PATCH /subscriptions/:id. Any subset of fields, but at least one. */
export const UpdateSubscriptionRequestSchema = CreateSubscriptionRequestSchema.partial()
  .refine((patch) => Object.keys(patch).length > 0, "Provide at least one field to update")
  // Refinements can't be expressed in OpenAPI, so publish the same rule as JSON Schema.
  .meta({ id: "UpdateSubscriptionRequest", minProperties: 1 });

export const SubscriptionIdParamsSchema = z.object({ id: z.uuid("Must be a valid UUID") });

export type BillingCycle = z.infer<typeof BillingCycleSchema>;
export type Currency = z.infer<typeof CurrencySchema>;
export type Category = z.infer<typeof CategorySchema>;
export type Subscription = z.infer<typeof SubscriptionSchema>;
export type SubscriptionListResponse = z.infer<typeof SubscriptionListResponseSchema>;
export type CreateSubscriptionRequest = z.infer<typeof CreateSubscriptionRequestSchema>;
export type UpdateSubscriptionRequest = z.infer<typeof UpdateSubscriptionRequestSchema>;
