import type { Subscription } from "../api/subscriptions";

export function aSubscription(overrides: Partial<Subscription> = {}): Subscription {
  return {
    id: crypto.randomUUID(),
    name: "Netflix",
    amountMinor: 1599,
    currency: "USD",
    billingCycle: "monthly",
    category: "streaming",
    nextRenewalDate: "2026-11-15",
    notes: null,
    createdAt: "2026-10-28T12:00:00.000Z",
    updatedAt: "2026-10-28T12:00:00.000Z",
    ...overrides,
  };
}
