import { expect, test } from "./support/fixtures";

test.describe("Delete a subscription", () => {
  test("deletes after confirmation", async ({ page, arrange, api }) => {
    const subscription = await arrange.subscription();

    await page.goto("/subscriptions");
    const row = page.getByRole("row").filter({ hasText: subscription.name });
    await expect(row).toBeVisible();

    await page.getByRole("button", { name: `Delete ${subscription.name}` }).click();
    const dialog = page.getByRole("alertdialog", { name: `Delete ${subscription.name}?` });
    await dialog.getByRole("button", { name: "Delete" }).click();

    await expect(dialog).toBeHidden();
    await expect(row).toHaveCount(0);
    const { response } = await api.GET("/subscriptions/{id}", {
      params: { path: { id: subscription.id } },
    });
    expect(response.status).toBe(404);
  });

  test("keeps the subscription when cancelled", async ({ page, arrange }) => {
    const subscription = await arrange.subscription();

    await page.goto("/subscriptions");
    await page.getByRole("button", { name: `Delete ${subscription.name}` }).click();
    await page.getByRole("alertdialog").getByRole("button", { name: "Cancel" }).click();

    await expect(page.getByRole("alertdialog")).toBeHidden();
    await expect(page.getByRole("row").filter({ hasText: subscription.name })).toBeVisible();
  });
});
