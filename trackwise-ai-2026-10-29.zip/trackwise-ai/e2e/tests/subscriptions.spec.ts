import { expect, test } from "./support/fixtures";

// Expectations mirror the sample data in apps/api/src/db/seed.ts, loaded by global-setup.ts.
test.describe("Subscriptions list", () => {
  test("shows seeded subscriptions, soonest renewal first", async ({ page }) => {
    await page.goto("/");
    await page
      .getByRole("navigation", { name: "Main" })
      .getByRole("link", { name: "Subscriptions" })
      .click();

    await expect(page).toHaveURL(/\/subscriptions$/);
    await expect(page.getByRole("heading", { name: "Subscriptions" })).toBeVisible();

    const rows = page.getByRole("table").locator("tbody tr");
    await expect(rows).toHaveCount(14);
    await expect(rows.first()).toContainText("The Economist");
    await expect(rows.first()).toContainText("$6.99");
    await expect(rows.first()).toContainText("Weekly");
    await expect(rows.last()).toContainText("PS Plus");
    await expect(rows.last()).toContainText("₹2,999.00");
    await expect(rows.last()).toContainText("¥2,400");

    const disney = rows.filter({ hasText: "Disney+" });
    await expect(disney).toContainText("€9.99");
    await expect(disney).toContainText("Shared with family");
  });

  test("loads directly from a deep link", async ({ page }) => {
    await page.goto("/subscriptions");

    await expect(page.getByRole("table").locator("tbody tr")).toHaveCount(14);
  });
});
