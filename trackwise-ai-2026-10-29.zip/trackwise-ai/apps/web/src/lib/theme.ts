export type Theme = "light" | "dark";

/** localStorage key; the inline script in index.html reads the same key before first paint. */
export const THEME_STORAGE_KEY = "trackwise-theme";

/** The saved choice, or undefined to follow the operating system. */
export function storedTheme(): Theme | undefined {
  try {
    const value = localStorage.getItem(THEME_STORAGE_KEY);
    return value === "light" || value === "dark" ? value : undefined;
  } catch {
    return undefined; // storage blocked (e.g. some private modes)
  }
}

export function systemTheme(): Theme {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function applyTheme(theme: Theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
}

export function saveTheme(theme: Theme) {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
    // Not persisted; the choice still applies for this page view.
  }
}
