import { MAX_AMOUNT_MINOR } from "./subscription";

/** Decimal places of a currency's minor unit: USD 2, JPY 0, BHD 3. */
export function minorUnitDigits(currency: string): number {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).resolvedOptions()
    .maximumFractionDigits as number;
}

/** Formats an amount in minor units for display, e.g. `formatMoney(1599, "USD")` → "$15.99". */
export function formatMoney(amountMinor: number, currency: string, locale = "en-US"): string {
  const amount = amountMinor / 10 ** minorUnitDigits(currency);
  return new Intl.NumberFormat(locale, { style: "currency", currency }).format(amount);
}

/** Minor units as a plain decimal string for inputs, e.g. `(1599, "USD")` → "15.99". */
export function toMajorString(amountMinor: number, currency: string): string {
  const digits = minorUnitDigits(currency);
  if (digits === 0) return String(amountMinor);
  const padded = String(amountMinor).padStart(digits + 1, "0");
  return `${padded.slice(0, -digits)}.${padded.slice(-digits)}`;
}

export type ParseMoneyResult = { ok: true; amountMinor: number } | { ok: false; error: string };

/**
 * Parses user input like "15.99" or "1,299.5" into minor units using string arithmetic,
 * so there are no floating-point rounding errors (0.1 + 0.2 problems).
 */
export function parseMoney(input: string, currency: string): ParseMoneyResult {
  const normalized = input.trim().replaceAll(",", "");
  const match = /^(\d+)(?:\.(\d*))?$/.exec(normalized);
  if (!match) return { ok: false, error: "Enter an amount like 9.99" };

  const [, whole = "", fraction = ""] = match;
  const digits = minorUnitDigits(currency);
  if (fraction.length > digits) {
    return {
      ok: false,
      error:
        digits === 0
          ? `${currency} amounts can't have decimals`
          : `Use at most ${digits} decimal places`,
    };
  }

  const amountMinor = Number(whole + fraction.padEnd(digits, "0"));
  if (!Number.isSafeInteger(amountMinor) || amountMinor > MAX_AMOUNT_MINOR) {
    return { ok: false, error: "Amount is too large" };
  }
  if (amountMinor <= 0) return { ok: false, error: "Amount must be greater than zero" };
  return { ok: true, amountMinor };
}
