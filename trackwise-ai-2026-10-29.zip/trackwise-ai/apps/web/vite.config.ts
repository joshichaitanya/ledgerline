import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const port = Number(process.env.WEB_PORT ?? 5173);
const apiTarget = process.env.API_PROXY_TARGET ?? "http://127.0.0.1:3000";

// The browser only ever talks to its own origin; `/api/*` is forwarded to Fastify.
// This avoids CORS and mirrors how a reverse proxy will route traffic in production.
const proxy = {
  "/api": { target: apiTarget, rewrite: (path: string) => path.replace(/^\/api/, "") },
};

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { port, strictPort: true, proxy },
  preview: { port, strictPort: true, proxy },
});
